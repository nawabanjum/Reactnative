// In App.js in a new project
import 'react-native-gesture-handler';
import React, { useEffect } from "react";
import { View, Text, Image, Alert, SafeAreaView, TouchableOpacity, StyleSheet, Linking, Share } from 'react-native';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import Icon from "react-native-vector-icons/AntDesign";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {
  createDrawerNavigator, DrawerActions, DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from '@react-navigation/drawer';
import { Appbar, IconButton } from 'react-native-paper';
import AsyncStorage from '@react-native-community/async-storage';
import styles from './Components/Common/CommonStyles';
import { HeaderColor, HeaderIconsColor, HeaderTitleColor } from './Components/Common/StaticColors';

//Screens
// import {Home,GoldenWordsCat,GoldenWords,Login,
//   Poetry,PoetryCat,PoetryDetail,GoldenWordDetail,Register,
//   ForgotPassword,HandiCraftDetail,HandiCrafts,HandiCraftsCat,
//   FunnySms,FunnySmsCat,FunnySmsDetail,AddGoldenWord} from './Components/Screens';

import Home from './Components/Screens/Home';
import Login from './Components/Screens/Login';
import Register from './Components/Screens/Register';
import ForgotPassword from './Components/Screens/ForgotPassword';
import Profile from './Components/Screens/Profile';
import WhatsNew from './Components/Screens/WhatsNew';
import WhatsNewDetail from './Components/Screens/WhatsNewDetail';
import UpdateProfile from './Components/Screens/UpdateProfile';
import SubmitFeedback from './Components/Screens/SubmitFeedback';
import NavigationBars from './Components/Screens/NavigationBars';
import Search from './Components/Screens/Search';
import ChangePassword from './Components/Screens/ChangePassword';
import Members from './Components/Screens/Members';
import MembersProfile from './Components/Screens/MembersProfile';
import FacebookPage from './Components/Screens/FacebookPage';
import { adUnitId } from './Components/Common/IDs';
////////////////////////////////////////
import DonateGoods from './Components/Screens/DonateGoods';
import AboutUs from './Components/Screens/AboutUs';
import PrivacyPolicy from './Components/Screens/PrivacyPolicy';
import DonationsPolicy from './Components/Screens/DonationsPolicy';
import ProductList from './Components/Screens/ProductList';
import ProductByCategory from './Components/Screens/ProductByCategory';
import ProductDetails from './Components/Screens/ProductDetails';
import ThankYou from './Components/Screens/ThankYou';
import ContactDetails from './Components/Screens/ContactDetails';
import ThankYou2 from './Components/Screens/ThankYou2';
import ArchiveProducts from './Components/Screens/ArchiveProducts';
import CanDonate from './Components/Screens/CanDonate';

////////////////////////////////////////////
import ContactUs from './Components/Screens/ContactUs';


/////////////////////////Interstitial Ads/////////////
import {
  InterstitialAd,
  TestIds,
  AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
  adUnitId,
  {
    requestNonPersonalizedAdsOnly: true,
    keywords: ['fashion', 'clothing'],
  }
);
/////////////////////////end/////////////////


const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();
const HeaderTitleSize = 14;
//const login = await AsyncStorage.getItem('Logged_UserId');
function HomeTabs() {

  return (
    <Tab.Navigator>
      <Tab.Screen name="HomeStack" component={HomeStack} options={{
        tabBarLabel: 'Home',
        tabBarIcon: ({ color, size }) => (

          <Icon name='home' color={color} size={size} />
        ),
      }} />
      {global.LoginDetail == null || global.LoginDetail == undefined || global.LoginDetail.Users_ID == 7 ?
        <Tab.Screen name="LoginStack" component={LoginStack} options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => (

            <Icon name='user' color={color} size={size} />
          ),
        }} />
        :
        <Tab.Screen name="ProfileStack" component={ProfileStack} options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, size }) => (

            <Icon name='user' color={color} size={size} />
          ),
        }} />
      }
      <Tab.Screen name="CategoryStack" component={CategoryStack} options={{
        tabBarLabel: 'Categories',
        tabBarIcon: ({ color, size }) => (

          <Icon name='layout' color={color} size={size} />
        ),
      }} />
      {/* <Tab.Screen name="PoetryStack" component={PoetryStack} options={{
        tabBarLabel: 'Poetry',
        tabBarIcon: ({ color, size }) => (

          <Icon name='dingding-o' color={color} size={size} />
        ),
      }} /> */}

      {/* {global.LoginDetail == null || global.LoginDetail == undefined ?
        <Tab.Screen name="Login" component={Login} options={{
          tabBarLabel: 'Post',
          tabBarIcon: ({ color, size }) => (

            <Icon name='plussquare' color={color} size={size} />
          ),
        }} />
        : */}

      <Tab.Screen name="ContactStack" component={ContactStack} options={{
        tabBarLabel: 'Contact us ',
        tabBarIcon: ({ color, size }) => (

          <Icon name='contacts' color={color} size={size} />
        ),
      }} />


      {/* <Tab.Screen name="NewStack" component={NewStack} options={{
        tabBarLabel: "What's New",
        tabBarIcon: ({ color, size }) => (

          <Icon name='dingding' color={color} size={size} />
        ),
      }} /> */}
      <Tab.Screen name="AboutStack" component={AboutStack} options={{
        tabBarLabel: 'About us',
        tabBarIcon: ({ color, size }) => (

          <Icon name='exception1' color={color} size={size} />
        ),
      }} />


      {/* <Tab.Screen name="DrawerStack" component={DrawerStack}

        options={{
          tabBarLabel: 'More',
          tabBarOnPress: ({ navigation }) => {
            //your code and other stuff 
            navigation.openDrawer();
          },
          tabBarIcon: ({ color, size }) => (

            <Icon name='layout' color={color} size={size} />
          ),
        }}
      /> */}
    </Tab.Navigator>
  );
}
function HomeStack() {


  const navigation = useNavigation();

  const onShare = async () => {
    try {
      const result = await Share.share({
        message: 'App Url'
        ,
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };
  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle,
      // headerLeft: () => (
      //   <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
      // ),
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <IconButton size={20} icon="magnify" color={HeaderIconsColor} ></IconButton>
          <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

        </View>
      )
    }}>
      <Stack.Screen name="Home" component={Home} options={{
        headerTitleStyle: { height: 40, marginBottom: 10 }, title: (<Image onPress={() => navigation.navigate('Home')} source={require('./Components/Icons/logo.png')}></Image>),
        // headerLeft: () => (
        //   <IconButton icon="bell-circle-outline" color={HeaderIconsColor} onPress={() => navigation.navigate("WhatsNew")}></IconButton>
        // ),
        headerRight: () => (
          <View style={{ flexDirection: "row" }}>
            <IconButton size={15} icon="magnify" color={HeaderIconsColor} ></IconButton>
            {/* <IconButton size={20} icon="star-half-full" color={HeaderIconsColor} onPress={() => {
              if (global.LoginDetail == null || global.LoginDetail == undefined || global.LoginDetail.Users_ID == 7) {
                navigation.navigate('LoginStack');
              } else {
                navigation.navigate('Rewards');
              }
            }}></IconButton> */}
            {/* <IconButton size={15} icon="share-variant" color={HeaderIconsColor} onPress={() => Alert.alert('', 'Coming Soon')}></IconButton>
            <IconButton size={15} icon="star-half-full" color={HeaderIconsColor} onPress={() => Alert.alert('', 'Coming Soon')}></IconButton>
            <IconButton size={15} icon="bell-circle-outline" color={HeaderIconsColor} onPress={() => navigation.navigate("WhatsNew")}></IconButton> */}
            <IconButton size={15} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

          </View>
        )
      }} />
      {/* <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicy} options={{ title: 'Privacy Policy' }} />
      <Stack.Screen name="CanDonate" component={CanDonate} options={{ title: 'What I can Donate?' }} />
      <Stack.Screen name="DonationsPolicy" component={DonationsPolicy} options={{ title: 'Donations Policy' }} /> */}
      <Stack.Screen name="ProductByCategory" component={ProductByCategory} options={{ title: 'Search Items' }} />
      <Stack.Screen name="ProductDetails" component={ProductDetails} options={{ title: false, headerTransparent: true }} />
      <Stack.Screen name="ContactDetails" component={ContactDetails} options={{ title: 'Contact Details', }} />
      <Stack.Screen name="ThankYou2" component={ThankYou2} options={{ title: 'Thanks', }} />
      <Stack.Screen name="ArchiveProducts" component={ArchiveProducts} options={{ title: 'Archive List', }} />
      <Stack.Screen name="SubmitFeedback" component={SubmitFeedback} options={{ title: 'Feedback and Suggestions' }} />
      <Stack.Screen name="WhatsNewDetail" component={WhatsNewDetail} options={{ title: 'News Details' }} />
      <Stack.Screen name="NavigationBars" component={NavigationBars} options={{ title: 'Menu' }} />
      <Stack.Screen name="NewStack" component={NewStack} options={{ headerShown: false }} />
      <Stack.Screen name="ProfileStack" component={ProfileStack} options={{ headerShown: false }} />
      <Stack.Screen name="Login" component={Login} options={{ title: 'Sign in' }} />
      <Stack.Screen name="Search" component={Search} options={{ title: 'Search' }} />
      <Stack.Screen name="FacebookPage" component={FacebookPage} options={{ title: 'Facebook' }} />
      <Stack.Screen name="WhatsNew" component={WhatsNew} options={{ title: "News", }} />


    </Stack.Navigator>
  );
}
function ProfileStack() {
  const navigation = useNavigation();
  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle,

      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <IconButton size={20} icon="magnify" color={HeaderIconsColor} onPress={() => navigation.navigate('ProductListStack')}></IconButton>
          <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

        </View>
      )
    }}>
      <Stack.Screen name="Profile" component={Profile} options={{
        title: 'Profile',
        headerLeft: () => (
          <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
        ),
      }} />
      <Stack.Screen name="UpdateProfile" component={UpdateProfile} options={{ title: 'Update Profile' }} />
      <Stack.Screen name="ChangePassword" component={ChangePassword} options={{ title: 'Change Password' }} />
    </Stack.Navigator>
  );
}
function LoginStack() {
  const navigation = useNavigation();
  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle
    }}>
      <Stack.Screen name="Login" component={Login} options={{
        title: 'Sign in',
        headerLeft: () => (
          <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
        ),
        headerRight: () => (
          <View style={{ flexDirection: "row" }}>
            <IconButton size={20} icon="magnify" color={HeaderIconsColor} onPress={() => navigation.navigate('ProductListStack')}></IconButton>
            <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

          </View>
        )
      }} />

    </Stack.Navigator>
  );
}

function CategoryStack() {
  const navigation = useNavigation();

  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle,
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <IconButton size={20} icon="magnify" color={HeaderIconsColor} ></IconButton>
          <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

        </View>
      )
    }}>
      {/* <Stack.Screen name="Profile" component={Profile} options={{ headerTitleStyle: { height: 40, alignSelf: 'center' }, title: (<Image source={require('./Components/Icons/logo3.png')}></Image>) }} /> */}
      <Stack.Screen name="ProductList" component={ProductList} options={{
        title: 'Categories',
        headerLeft: () => (
          <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
        ),
      }} />

    </Stack.Navigator>
  );
}
function NewStack() {
  const navigation = useNavigation();
  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle,
      headerLeft: () => (
        <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
      ),
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <IconButton size={20} icon="magnify" color={HeaderIconsColor} ></IconButton>
          <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

        </View>
      )
    }}>
      <Stack.Screen name="WhatsNew" component={WhatsNew} options={{
        headerTitleStyle: styles.HeaderTitleStyle,
        title: "News",
        headerLeft: () => (
          <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
        ),
      }} />
      <Stack.Screen name="WhatsNewDetail" component={WhatsNewDetail} options={{ title: 'News Details' }} />


    </Stack.Navigator>
  );
}

function ContactStack() {
  const navigation = useNavigation();

  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle,
      headerLeft: () => (
        <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
      ),
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <IconButton size={20} icon="magnify" color={HeaderIconsColor} ></IconButton>
          <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

        </View>
      )
    }}>
      <Stack.Screen name="ContactUs" component={ContactUs} options={{
        title: 'Contact Us',
        headerLeft: () => (
          <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
        ),
      }} />

    </Stack.Navigator>
  );
}
function AboutStack() {
  const navigation = useNavigation();

  return (
    <Stack.Navigator screenOptions={{
      headerTintColor: HeaderTitleColor,
      headerStyle: { backgroundColor: HeaderColor },
      headerTitleStyle: styles.HeaderTitleStyle,
      headerLeft: () => (
        <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
      ),
      headerRight: () => (
        <View style={{ flexDirection: "row" }}>
          <IconButton size={20} icon="magnify" color={HeaderIconsColor} ></IconButton>
          <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigation.navigate('NavigationBars')}></IconButton>

        </View>
      )
    }}>
      <Stack.Screen name="AboutUs" component={AboutUs} options={{
        title: 'About Us',
        headerLeft: () => (
          <IconButton icon="home" color={HeaderIconsColor} onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}></IconButton>
        ),
      }} />

    </Stack.Navigator>
  );
}

function App() {
  const navigationRef = React.createRef();

  function navigate(name, params) {
    navigationRef.current?.navigate(name, params);
  }
  return (
    <NavigationContainer ref={navigationRef}>

      <Stack.Navigator
        screenOptions={{
          headerTintColor: HeaderTitleColor,
          headerStyle: { backgroundColor: HeaderColor },
          headerTitleStyle: styles.HeaderTitleStyle,
          headerRight: () => (
            <View style={{ flexDirection: "row" }}>
              <IconButton size={20} icon="magnify" color={HeaderIconsColor}></IconButton>
              <IconButton size={20} icon="dots-vertical" color={HeaderIconsColor} onPress={() => navigate('NavigationBars')}></IconButton>

            </View>
          )
        }}>
        <Stack.Screen name="HomeTabs" component={HomeTabs} options={{ headerShown: false }} />
        <Stack.Screen name="Login" component={Login} options={{ title: 'Sign in' }} />
        <Stack.Screen name="Register" component={Register} options={{ title: 'Sign Up' }} />
        <Stack.Screen name="ForgotPassword" component={ForgotPassword} options={{ title: 'Forgot Password' }} />


      </Stack.Navigator>

    </NavigationContainer>
  );
};

export default App;

const React = require("react-native");

const { StyleSheet } = React;

export default {
    Detailbtn:{ 
        fontSize: 12 ,
        color:'orange'
        },
};
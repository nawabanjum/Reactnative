import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';

 export const BASE_URL = "http://fun2fresh.com/";
///////////Test Ads

export const bannerAdUnitId = __DEV__ ? TestIds.BANNER : "3244x3343xx88";
export const adUnitId = __DEV__ ? TestIds.INTERSTITIAL :'xx-app-xxx-53466582654/658645965';

////////Fun2Fresh Officaial

// export const bannerAdUnitId = "ca-app-pub-6621683539093538/5448424144";   //Banner Ads

// export const adUnitId = 'ca-app-pub-6621683539093538/7178091178';      //Interstial Ads


//////Golden Words Collections

// export const bannerAdUnitId = 'ca-app-pub-6621683539093538/3784496833';    //Banner Ads

//  export const adUnitId = 'ca-app-pub-6621683539093538/8462108448';  //Interstial Ads



 ////////Poetry Collections

//export const bannerAdUnitId = 'ca-app-pub-6621683539093538/7887393373';    //Banner Ads

 //export const adUnitId = 'ca-app-pub-6621683539093538/7504249992';  //Interstial Ads


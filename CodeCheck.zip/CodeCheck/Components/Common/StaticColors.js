export const HeaderColor='white';
export const HeaderIconsColor='#2088dd';
export const HeaderTitleColor='#2088dd';
export const LoaderColor='#2088dd';
export const CommonColor='#2088dd';



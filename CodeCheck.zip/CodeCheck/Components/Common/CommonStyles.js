import {  HeaderTitleColor } from '../Common/StaticColors';


const React = require("react-native");

const { StyleSheet } = React;

export default {

    HeaderTitleStyle: {
        fontSize:14,color:HeaderTitleColor
    },    
    LoaderStyle: {
        position: 'absolute',
        alignSelf: 'center',
        zIndex: 1,
        paddingTop: 10
    },
    TextInput:{
        height: 40, borderColor: 'lightgray', borderWidth: 1, marginVertical: 0, paddingLeft: 15,borderRadius:20
    },
    HomeCard:{
        borderWidth: 1, borderRadius: 10, borderColor: 'lightgrey', margin: 5, borderRightWidth: 10,backgroundColor:'white' 
    },
    CreateIcon: {
        color: "#2088dd", alignSelf: 'flex-end', padding: 20
    },
    Detailbtn: {
        fontSize: 14,
        color: 'orange'
    },
    NextPrebtn: {
        fontSize: 14,
        color: '#06d253'
    },
    SmsText:{
        textAlign:'center'
    },
    SmsContainer:{
        backgroundColor:'rgba(0.5, 0.25, 0, 0.2)',borderRadius:50,paddingBottom:10
    },
    DetailTitle:{
        flex: 1, fontSize: 12 ,textAlign:'center'
    },
    HomeTitle:{
        color: 'orange', paddingTop: 20,fontSize:12,flex:1,textAlign:'center'
    },
    HomeSubTitle:{
        fontSize: 9, color: 'grey', textAlign: 'center',flex:1, color: '#A0A0A0',paddingLeft:5,paddingTop:0
    },
    HomeItemCount:{
        color: 'orange', padding: 15, textAlign: 'right',fontSize:12
    },
    DetailCat:{
        fontSize:8,color:'grey'
    },AddnewBtn:{
        borderRadius: 45, width: 100, alignSelf: 'flex-end', margin: 5, height: 30
    },
    PikerContainer:{
        flex: 1, borderWidth: 1, borderColor: 'grey', borderRadius: 10, backgroundColor: 'white' 
    },
    headerTitle:{
        fontSize: 14
    },
    YouMayAlsoLike_Background:{
        flexDirection: 'row', padding: 5,backgroundColor:'lightgrey'
    },
    YouMayAlsoLike_Title:{
        fontWeight: 'bold', color: 'orange', textAlign: 'center'
    },
    detailsCommentText:{
        fontSize:10,textAlign:'center',backgroundColor:'white',padding:10
    },
    HeadingsTitle:{
        color: "white", fontSize: 12, fontWeight: "bold", textAlign: "center", flex: 1, alignSelf: 'center',paddingVertical:5 
    },
    HeadingBackgroundImage:{
        flex: 1, resizeMode: "cover", justifyContent: "center", borderTopLeftRadius: 20
    },
    labelStyle:{
         margin: 10, marginBottom: 5,fontSize:12,color:'grey'
    },
    DateTimeLabels:{
        flex: 1, color: 'grey', fontSize: 12
    },
    DateTimePikerStyle:{
        paddingVertical: 10, height: 40, fontSize: 12,
                                    borderRadius: 5,
                                    borderWidth: 1,
                                    borderColor: '#eaeaea',
                                    // marginRight: 15,
                                    marginTop: 0,
                                    textAlign: 'center',
                                    backgroundColor: 'white'
    },
    PikerStyle:{
        height: 40, width: 'auto', flex: 1
    },
    ProductCardsTitle:{
        fontSize: 12,color:'grey',textAlign:'center'
    },
    ProductCardsPrice:{
        fontSize: 12,fontWeight:'bold',padding:5,textAlign:'center'
    },
    ProductCardsImage:{
        flex: 1, height: 160, margin: 5 
    },
    SubCat_Title:{
        fontSize:12
    }
};
//#eaebe8
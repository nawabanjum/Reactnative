// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect, useRef } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert, TextInput, StyleSheet } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Card, Title, Paragraph, } from 'react-native-paper';
import Icon from "react-native-vector-icons/AntDesign";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ListItem, Avatar, Button } from 'react-native-elements';
import styles from '../Common/CommonStyles';
import { BASE_URL } from '../Common/Urls';
import Editor from '../Editor';
import {
    actions,
    defaultActions,
    RichEditor,
    RichToolbar,
} from "react-native-pell-rich-editor";
import HTMLView from "react-native-htmlview";
import { bannerAdUnitId,adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
function WhatsNewDetail({ route }) {
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [Remarks, SetRemarks] = useState('');
    const [isLoading, SetLoading] = useState(false);
    const { Id } = route.params;


    ////////////////Editor///////////////////
    const strikethrough = require("../Icons/lock.png"); //icon for strikethrough
    const video = require("../Icons/lock.png"); //icon for Addvideo
    const RichText = useRef(); //reference to the RichEditor component
    const [article, setArticle] = useState("");

    // this function will be called when the editor has been initialized
    function editorInitializedCallback() {
        RichText.current?.registerToolbar(function (items) {
            // items contain all the actions that are currently active
            // console.log(
            //     "Toolbar click, selected items (insert end callback):",
            //     items
            // );
        });
    }

    // Callback after height change
    function handleHeightChange(height) {
        // console.log("editor height change:", height);
    }

    function onPressAddImage() {
        // you can easily add images from your gallery
        RichText.current?.insertImage(
            "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/100px-React-icon.svg.png"
        );
    }

    function insertVideo() {
        // you can easily add videos from your gallery
        RichText.current?.insertVideo(
            "https://mdn.github.io/learning-area/html/multimedia-and-embedding/video-and-audio-content/rabbit320.mp4"
        );
    }

    ////////////////////////////////////////end///////////////////////////////////////
    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
           // DisplayAds()
            SetLoading(true);
            var url = BASE_URL + "ApiCommon/GetWhatsNewById?Id=" + Id;
            axios.post(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
        });
        return unsubscribe;

    }, [navigation])

    let upload = async () => {
        //Check if any file is selected or not
        if (Remarks.trim() == '')
            Alert.alert('Validation', "Comments can not be empty.")

        else {
            SetLoading(true);
            //If file selected then create FormData
            // const fileToUpload = singleFile;
            // const UsersId = global.LoginDetail.Users_ID;
            const formData = new FormData();

            formData.append('ParentId', 0);
            formData.append('WhatsNewId', Data.WhatsNewId);
            formData.append('Comments', Remarks);

            if (global.LoginDetail == null || global.LoginDetail == undefined) {
                formData.append('UserId', 7867);
            } else {
                formData.append('PostedByUserId', global.LoginDetail.Users_ID);
            }
            const model={
                ParentId:0,
                WhatsNewId:Data.WhatsNewId,
                Comments:Remarks,
                PostedByUserId:global.LoginDetail.Users_ID
            }
            //console.log('formData : ' + JSON.stringify(model));

            axios({
                url: BASE_URL + 'ApiCommon/AddWhatsNew',
                method: 'POST',
                data: formData,
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'multipart/form-data'
                },
            })
                .then(function (response) {
                    Alert.alert("Success", "Remarks submitted",);
                    navigation.goBack();
                    SetLoading(false);
                })
                .catch(function (response) {
                    Alert.alert("Error", "Upload failed");
                    SetLoading(false);
                });


        }
        // else{
        // alert("Please Select file.");
        // }
    };
    const ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem containerStyle={{ borderRadius: 20, marginVertical: 5, marginHorizontal: 10 }} underlayColor='white' bottomDivider
                // onPress={() => navigation.navigate("HandiCrafts",{CatId:item.HandiCraftCat_Id})}
                key={index}>
                <Avatar rounded size={25} source={{ uri: 'http://' + item.Picture }} />
                <ListItem.Content>
                    {/* <ListItem.Title>{item.PostedDateTime}</ListItem.Title> */}
                    <ListItem.Subtitle style={{ fontSize: 10 }}>{item.Comments}</ListItem.Subtitle>
                </ListItem.Content>
            </ListItem>

        );
    };
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    return (
        <SafeAreaView style={{ flex: 1, padding: 5 }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <ScrollView>
                {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
                <ListItem containerStyle={{ borderRadius: 20, paddingVertical: 5, marginVertical: 5 }} underlayColor='white' bottomDivider
                >
                    <Avatar rounded size={30} source={{ uri: 'http://' + Data.Picture }} />
                    <ListItem.Content>
                        <ListItem.Title style={{ fontSize: 12 }}>{Data.Comments}</ListItem.Title>
                        <View style={{ flexDirection: 'row' }}>
                            <ListItem.Subtitle style={{ flex: 1, fontSize: 10 }}>{Data.UserName}</ListItem.Subtitle>
                            <ListItem.Subtitle style={{ fontSize: 8 }}> {Data.PostedDateTime}</ListItem.Subtitle>
                        </View>
                    </ListItem.Content>
                </ListItem>
                {Data.whatsNews != null || Data.whatsNews != undefined ?
                    Data.whatsNews.map((item, index) =>
                        <ListItem containerStyle={{ borderRadius: 20, marginVertical: 5, marginHorizontal: 10 }} underlayColor='white' bottomDivider
                            key={index}>
                            <Avatar rounded size={25} source={{ uri: 'http://' + item.Picture }} />
                            <ListItem.Content>
                                <ListItem.Subtitle style={{ fontSize: 10 }}>{item.Comments}</ListItem.Subtitle>
                            </ListItem.Content>
                        </ListItem>
                    )
                    // <FlatList
                    //     data={Data.whatsNews}
                    //     keyExtractor={(item, index) => index.toString()}     //has to be unique   
                    //     renderItem={ItemView} //method to render the data in the way you want using styling u need
                    // />
                    :
                    <Text>No Comments</Text>
                }

                <View style={{ padding: 10, paddingBottom: 20 }}>
                    <Card>
                        <View >
                            {/* <RichEditor
                            disabled={false}
                            // containerStyle={EditorStyle.editor}
                            containerStyle={{ borderWidth: 1 ,overflow:'scroll'}}
                            ref={RichText}
                            // style={EditorStyle.rich}
                            style={{ minHeight: 80 ,maxHeight:200,overflow:'scroll'}}
                            placeholder={"Start Writing Here"}
                            onChange={(text) => setArticle(text)}
                            editorInitializedCallback={editorInitializedCallback}
                            onHeightChange={handleHeightChange}
                            scrollEnabled={true}
                            
                        />
                        <RichToolbar
                            // style={[EditorStyle.richBar]}
                            editor={RichText}
                            disabled={false}
                            iconTint={"orange"}
                            selectedIconTint={"grey"}
                            disabledIconTint={"grey"}
                            onPressAddImage={onPressAddImage}
                            iconSize={20}
                            actions={[
                                "insertVideo",
                                ...defaultActions,
                                actions.setStrikethrough,
                                actions.heading1,
                            ]}
                            // map icons for self made actions
                            iconMap={{
                                [actions.heading1]: ({ tintColor }) => (
                                    <Text style={[EditorStyle.tib, { color: tintColor }]}>H1</Text>
                                ),
                                [actions.setStrikethrough]: strikethrough,
                                ["insertVideo"]: video,
                            }}
                            insertVideo={insertVideo}
                        /> */}
                            <TextInput
                                style={[styles.TextInput,{margin:10,marginVertical:5}]}
                                onChangeText={(text) => SetRemarks(text)}
                                placeholder='Share your thoughts'

                                value={Remarks}
                            />
                            <Button containerStyle={{ borderRadius: 20, height: 40, marginVertical: 5,marginHorizontal:10 }}
                                onPress={() => {
                                    if (global.LoginDetail == null || global.LoginDetail == undefined) {
                                        navigation.navigate("SubmitGuest");
                                    } else {
                                        upload();
                                    }
                                }}
                                title="Submit"
                            // disabled={(FirstName == '' || LastName == '' || email == '' || password == '' || ConfirmPassword == '') ? true : false}

                            />
                            {/* <TextInput
                            style={{ height: 40, borderColor: 'gray', borderWidth: 1, flex: 2, marginVertical: 15, paddingLeft: 15 }}
                            onChangeText={(text) => SetRemarks(text)}
                            placeholder='Share your thoughts'

                        //value={value}
                        />
                        
                        <Icon style={{ marginVertical: 16 }}
                            size={35}
                            raised
                            name='plussquare'
                            color='#2088dd'
                            onPress={() => {
                                if (global.LoginDetail == null || global.LoginDetail == undefined) {
                                    navigation.navigate("SubmitGuest");
                                } else {
                                    upload();
                                }
                            }}
                        /> */}
                        </View>

                    </Card>

                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default WhatsNewDetail;


const EditorStyle = StyleSheet.create({
    /********************************/
    /* styles for html tags */
    a: {
        fontWeight: "bold",
        color: "purple",
    },
    div: {
        fontFamily: "monospace",
    },
    p: {
        fontSize: 30,
    },
    /*******************************/
    container: {
        flex: 1,
        marginTop: 40,
        backgroundColor: "#F5FCFF",
    },
    editor: {
        backgroundColor: "black",
        borderColor: "black",
        borderWidth: 1,
    },
    rich: {
        minHeight: 100,
        // maxHeight:150,
        flex: 1,
    },
    richBar: {
        height: 50,
        backgroundColor: "#F5FCFF",
    },
    text: {
        fontWeight: "bold",
        fontSize: 20,
    },
    tib: {
        textAlign: "center",
        color: "#515156",
    },
});
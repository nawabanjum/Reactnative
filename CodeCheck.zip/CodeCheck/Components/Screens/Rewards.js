// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Card, Title, Paragraph, DataTable } from 'react-native-paper';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ListItem, Avatar, Button } from 'react-native-elements';
import styles from '../Common/CommonStyles';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId, adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
/////////////////////////////////////////////////////////////
function Reward() {
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [UserData, setUserData] = useState([]);
    const [email, Setemail] = useState('');
    const [Name, SetName] = useState('');
    const [Phone, SetPhone] = useState('');

    const [Comment, SetComment] = useState('');
    const [isLoading, SetLoading] = useState(false);
    var sum = Data.reduce((accumulator, current) => accumulator + current.RewardsPoints, 0);
    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
            SetLoading(true);
            DisplayAds();
            var url = BASE_URL + "ApiCommon/RewardsListByUserId?userId=" + global.LoginDetail.Users_ID;
            //console.log(url)
            axios.post(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
            axios.post(
                BASE_URL + "ApiCommon/GetUserById?Id=" + global.LoginDetail.Users_ID
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setUserData(response.data.Data)


                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                })
        });
        return unsubscribe;

    }, [navigation])
    function submit() {
        // let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        // if (Name == '' || Phone == '' || Comment == '') {
        //     Alert.alert("", "All fields are required.");
        //     // Setemail( text )
        //     return false;
        // } else
        //     if (reg.test(email) === false) {
        //         Alert.alert("", "Please enter valid Email");
        //         // Setemail( text )
        //         return false;
        //     }
        SetLoading(true);

        const model = {

            FeedBack_ID: 0,
            Name: UserData.FirstName + UserData.LastName,
            Email: UserData.Email,
            Phone: UserData.MobileNumber,
            Comments: 'User ID:' + UserData.Users_ID + ' User Name:' + UserData.FirstName + UserData.LastName + ' Email:' + UserData.Email + ' Phone No.' + UserData.MobileNumber,

        };
        //console.log('Sending data : ' + JSON.stringify(model));
        try {
            axios.post(BASE_URL + 'ApiCommon/SuggestionsAndFeedback', { model: model })

                .then(response => {
                    //console.log(response.data.Message)
                    SetLoading(false);
                    Alert.alert('', "Your claim request has been submitted successfully! Your cash will send in a while.");
                    //  navigation.navigate('Home');
                }, (error) => {
                    SetLoading(false);
                });
        } catch (error) {
            // handle error
            SetLoading(false);
            Alert.alert("Internal Server Error", error.message)

        }
    }
    const ItemView = ({ item, index }) => {
        return (

            <View style={{ flex: 1 }}>
                <Card style={{ borderRadius: 5 }} key={index}>
                    <DataTable.Row >
                        <DataTable.Cell>{new Date(item.EntryDate).getDate()}/{new Date(item.EntryDate).getMonth() + 1}/{new Date(item.EntryDate).getFullYear()}</DataTable.Cell>
                        <DataTable.Cell>{item.RewardType}</DataTable.Cell>
                        <DataTable.Cell numeric color='red' style={{ color: 'red' }}>{item.RewardsPoints}</DataTable.Cell>
                    </DataTable.Row>
                    {/* <Card.Content style={{ alignItems: 'flex-end' }}>
                    <Paragraph style={{ color: 'grey', fontSize: 10 }}>{item.EntryDate}</Paragraph>
                </Card.Content> */}
                </Card>
            </View>
        );
    };
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    return (
        <SafeAreaView style={{ flex: 1, padding: 4 }}>
            <ScrollView>
                <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                />
                <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
                <View style={{ padding: 5 }}>
                    <Card style={{ borderRadius: 20, backgroundColor: 'orange', height: 50 }} >
                        <Text style={{ color: 'white', fontSize: 14, padding: 13, fontWeight: 'bold', textAlign: 'center' }}>You have {parseInt(sum)} Reward points.</Text>

                    </Card>
                </View>
                <View style={{ padding: 5 }}>
                    <Card style={{ borderRadius: 20, backgroundColor: 'orange', height: 50 }} >
                        <Text style={{ color: 'white', fontSize: 12, padding: 13, fontWeight: 'bold', textAlign: 'center' }}>You can claim if you have minimum 500 points.</Text>

                    </Card>
                </View>
                <Button containerStyle={{ borderRadius: 20, height: 40, marginVertical: 10, marginHorizontal: 10 }} onPress={() => submit()}
                    title="Claim Your Reward"
                    disabled={(parseInt(sum) < 500) ? true : false}

                />
                <Card style={styles.YouMayAlsoLike_Background}>
                    <Text style={styles.YouMayAlsoLike_Title}>My Rewards History</Text>
                </Card>
                <FlatList
                    data={Data}
                    keyExtractor={(item, index) => index.toString()}     //has to be unique   
                    renderItem={ItemView} //method to render the data in the way you want using styling u need
                />
            </ScrollView>
        </SafeAreaView>
    );
}

export default Reward;
// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Card, Title, Paragraph } from 'react-native-paper';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ListItem, Avatar, Button } from 'react-native-elements';
import styles from '../Common/CommonStyles';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId,adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
/////////////////////////////////////////////////////////////

function Search() {
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [GWData, SetGWData] = useState([]);
    const [P_Data, SetP_Data] = useState([]);
    const [HC_Data, SetHC_Data] = useState([]);
    const [FunData, SetFunData] = useState([]);
    let [ID, setID] = useState();
    const [Remarks, SetRemarks] = useState('');
    const [isLoading, SetLoading] = useState(false);
    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
            DisplayAds();
           
        });
        return unsubscribe;

    }, [navigation]);
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    const Submit = () => {

        if(Remarks.trim() == '')
        {
          Alert.alert("", "Please type something!")
          return false;
        }
        SetLoading(true);
        var url = BASE_URL + "ApiCommon/SearchCategories?text=" + Remarks;
        axios.post(
            url
        )
            .then(response => {
                SetLoading(false);
                if (response.data == null) {
                    Alert.alert('Alert', "No Record Found ")
                }
                else {
                    SetLoading(false);
                    setData(response.data.Data)
                    SetGWData(response.data.Data.goldenWordsModels)
                    SetP_Data(response.data.Data.poetryModels)
                    SetHC_Data(response.data.Data.handiCraftsModels)
                    SetFunData(response.data.Data.ApiNextPreFunnySms)
                    //console.log(response.data.Data)

                }
            }).catch((error) => {
                SetLoading(false);
                Alert.alert("Internal Server Error", error.message)
            });
    }


    const Handi_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate("HandiCraftDetail", { CatId: item.HandiCraftCat_Id, Id: item.HandiCraftId })} key={index}>
                <Avatar rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Golden_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate("GoldenWordDetail", { CatId: item.QuotationCategoryId, Id: item.QuotationId })} key={index}>
                <Avatar rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Poetry_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate("PoetryDetail", { CatId: item.PoetryTypeId, Id: item.PoetryId })} key={index}>
                <Avatar rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Sms_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate('FunnySmsDetail', { CatId: item.JokeCategoryId, Id: item.JokeId })} key={index}>
                <Avatar rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Footer = () => {
        return (
            <Card>
                <Button buttonStyle={[styles.AddnewBtn, { alignSelf: 'center' }]}
                    titleStyle={{ fontSize: 12 }} 
                    iconRight={true}
                    type='clear'
                    icon={
                        <Icon
                            name="sync"
                            size={14}
                            color="#2088dd"
                        />

                    } title="LOADING  " />
            </Card>
        )
    }
    return (
        <SafeAreaView style={{ flex: 1, padding: 4 }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <BannerAd
                unitId={bannerAdUnitId}
                size={BannerAdSize.ADAPTIVE_BANNER}
                requestOptions={{
                    requestNonPersonalizedAdsOnly: true,
                }}
            />
            <Card>
                <View style={{ flexDirection: 'row', padding: 5 }}>
                    <TextInput
                        style={[styles.TextInput, { flex: 1, marginVertical: 15 }]}
                        onChangeText={(text) => SetRemarks(text)}
                        placeholder='Search here..'

                        value={Remarks}
                    />
                    <Icon style={{ marginVertical: 11 }}
                        size={45}
                        raised
                        name='search-circle'
                        color='#2088dd'
                        onPress={() => Submit()}
                    />
                </View>

            </Card>
            <ScrollView>
                {P_Data.length != 0 ?
                    <View>
                        <Card style={styles.YouMayAlsoLike_Background}>
                            <Text style={styles.YouMayAlsoLike_Title}>Results for Poetry</Text>
                        </Card>
                        <FlatList
                            data={P_Data}
                            keyExtractor={(item, index) => index.toString()}     //has to be unique   
                            renderItem={Poetry_ItemView} //method to render the data in the way you want using styling u need
                            initialNumToRender={1}
                            windowSize={1}
                            ListFooterComponent={Footer}
                        />
                    </View>

                    :
                    <View></View>}
                {GWData.length != 0 ?
                    <View>
                        <Card style={styles.YouMayAlsoLike_Background}>
                            <Text style={styles.YouMayAlsoLike_Title}>Results for golden words</Text>
                        </Card>
                        <FlatList
                            data={GWData}
                            keyExtractor={(item, index) => index.toString()}     //has to be unique   
                            renderItem={Golden_ItemView} //method to render the data in the way you want using styling u need
                            initialNumToRender={1}
                            windowSize={1}
                            ListFooterComponent={Footer}
                        />
                    </View>

                    :
                    <View></View>}
                {HC_Data.length != 0 ?
                    <View>
                        <Card style={styles.YouMayAlsoLike_Background}>
                            <Text style={styles.YouMayAlsoLike_Title}>Results for handi Crafts</Text>
                        </Card>
                        <FlatList
                            data={HC_Data}
                            keyExtractor={(item, index) => index.toString()}     //has to be unique   
                            renderItem={Handi_ItemView} //method to render the data in the way you want using styling u need
                            initialNumToRender={1}
                            windowSize={1}
                            ListFooterComponent={Footer}
                        />
                    </View>

                    :
                    <View></View>}
                {FunData.length != 0 ?
                    <View>
                        <Card style={styles.YouMayAlsoLike_Background}>
                            <Text style={styles.YouMayAlsoLike_Title}>Results for Fun</Text>
                        </Card>
                        <FlatList
                            data={FunData}
                            keyExtractor={(item, index) => index.toString()}     //has to be unique   
                            renderItem={Sms_ItemView} //method to render the data in the way you want using styling u need
                            initialNumToRender={1}
                            windowSize={1}
                            ListFooterComponent={Footer}
                        />
                    </View>

                    :
                    <View></View>}
            </ScrollView>
        </SafeAreaView>
    );
}

export default Search;
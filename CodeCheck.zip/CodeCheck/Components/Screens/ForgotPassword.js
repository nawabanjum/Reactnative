// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput, ActivityIndicator } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import styles from '../Common/CommonStyles';
//import { TextInput } from 'react-native-paper';
////Ads
import {
  TestIds,
  BannerAd,
  BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
  adUnitId,
  {
    requestNonPersonalizedAdsOnly: true,
    keywords: ['fashion', 'clothing'],
  }
);
import { bannerAdUnitId, adUnitId } from '../Common/IDs';
function ForgotPassword() {
  const [email, Setemail] = useState('');
  const [isLoading, SetLoading] = useState(false);

  const navigation = useNavigation();
  // useEffect(() => {
  //   const eventListener = interstitial.onAdEvent(type => {
  //     if (type === AdEventType.LOADED) {

  //       interstitial.show();
  //     }
  //   });

  //   // Start loading the interstitial straight away
  //   interstitial.load();

  //   // Unsubscribe from events on unmount
  //   return () => {
  //     eventListener();
  //   };
  // }, []);


  function submit() {
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (reg.test(email) === false) {
      Alert.alert("Invalid credentials", "Email is Not Valid");
      // Setemail( text )
      return false;
    }
    SetLoading(true);


    try {
      axios.post(BASE_URL + 'ApiAccount/UserForgetPassword?Email=' + email)

        .then(response => {
          //console.log(response.data.Message)
          SetLoading(false);
          Alert.alert('', response.data.Message);
          // navigation.navigate('Login');
        }, (error) => {
          SetLoading(false);
          // console.log(error);
        });
    } catch (error) {
      // handle error
      SetLoading(false);
      Alert.alert("Internal Server Error", error.message)

    }
  }
  return (
    <SafeAreaView style={{ flex: 1, padding: 10, backgroundColor: 'white' }}>
      <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
      <ScrollView>
        <View style={{ paddingTop: 50 }}>
          {/* <Image style={{ height: 100, width: 200, alignSelf: 'center', marginBottom: 50 }} source={require('../Icons/logo.png')}></Image> */}

          <TextInput
            style={styles.TextInput}
            onChangeText={(text) => Setemail(text)}
            placeholder='Email'

          //value={value}
          />
          <Button containerStyle={{ borderRadius: 20, height: 40, marginTop: 15 }} onPress={() => submit()}
            title="Send My Password"
            disabled={(email == '') ? true : false}
          />
          <Button containerStyle={{ borderRadius: 20, height: 40, marginTop: 20 }}
            title="Back" onPress={() => navigation.goBack()}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

export default ForgotPassword;
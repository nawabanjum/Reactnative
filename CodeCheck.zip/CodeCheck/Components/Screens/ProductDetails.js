import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert, Image, Share, ImageBackground, TextInput, Modal } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { FastImage } from 'react-native';
import { SliderBox } from "react-native-image-slider-box";
import { Card, Title, Paragraph, Button, } from 'react-native-paper';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import styles from '../Common/CommonStyles'

function Detail({ route }) {
    const image = { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo65zKZfMGxojTmtba2hplTbP5EQuFmCaOzQ&usqp=CAU" };
    const images = [

        "http://www.worldfastener.com/wp-content/uploads/2016/11/banner.jpg",
        "http://fazalsons.com/uploadedimages/v3v3R.jpg",
        "http://fazalsons.com/uploadedimages/X3X3w.jpg",
        "http://fazalsons.com/uploadedimages/cqcqg.JPG",
    ]
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [Cat, setCat] = useState([]);
    const [Comments, setComments] = useState([]);
    const [isLoading, SetLoading] = useState(false);
    const [ImageLoading, SetImageLoading] = useState(true);
    const [model, SetModel] = useState(false);
    const [CategoryId, setCategoryId] = useState();
    const [DataId, setDataId] = useState();
    const [Name, SetName] = useState('');
    const [Email, SetEmail] = useState('');
    const [Phone, SetPhone] = useState('');
    const [Remarks, SetRemarks] = useState('');
    //const { Image } = route.params;

    return (
        <SafeAreaView style={{ flex: 1, width: 'auto', padding: 4 }}>

            <ScrollView keyboardShouldPersistTaps={'handled'}>

                <View>
                    <Card style={{ borderRadius: 5 }} >

                        <SliderBox
                            images={images}
                            sliderBoxHeight={220}
                            //onCurrentImagePressed={index => console.warn(`image ${index} pressed`)} 
                            />
                        {/* <Image  style={{ height: undefined, aspectRatio: 1, marginLeft: 10, marginRight: 10 }} resizeMode='contain' source={{ uri: "https://mobilemall.pk/public_html/images/product/product_1597815189nokia-72.jpg" }} /> */}

                        <Card.Content style={{ alignItems: "center", borderBottomColor: 'grey', borderBottomWidth: 0.3, paddingVertical: 5 }}>

                            <Title style={{ color: "#2088dd" }}>We deliver used clothes and used shoes across the globe</Title>
                            <Paragraph style={{ margin: 10 }}>Graders & Exporters of quality used clothing, used shoes worldwide. WTC-Textiles are used clothing graders and used shoes graders, a name you can trust.</Paragraph>
                            {/* <Title style={{ color: "orange" ,fontSize:16}}> Preferred Collection Date</Title>
                            
                            <View style={{ flexDirection: 'row', paddingTop: 15 }}>
                                <Text style={{ flex: 1, color: '#2088dd', fontWeight: 'bold', fontSize: 12, paddingLeft: 20 }}>DATE </Text>
                                <Text style={{ flex: 1, color: '#2088dd', fontWeight: 'bold', fontSize: 12 }}>TIME FROM</Text>
                                <Text style={{ flex: 1, color: '#2088dd', fontSize: 12 }}>TIME To</Text>
                            </View>
                            <View style={{ flexDirection: 'row', paddingVertical: 6, paddingLeft: 20 ,borderBottomWidth:0.7,borderBottomColor:'grey'}}>
                                <Text style={{ flex: 1, color: 'black', fontWeight: 'bold', fontSize: 12 }}>15/3/2021 </Text>
                                <Text style={{ flex: 1, color: 'black', fontWeight: 'bold', fontSize: 12 }}>15:00</Text>
                                <Text style={{ flex: 1, color: 'black', fontWeight: 'bold', fontSize: 12 }}>20:00</Text>
                            </View>
                            <Title style={{ color: "orange",marginTop:5,fontSize:16 }}> Alternative Collection Date</Title>

                            <View style={{ flexDirection: 'row', paddingTop: 15 }}>
                                <Text style={{ flex: 1, color: '#2088dd', fontWeight: 'bold', fontSize: 12, paddingLeft: 20 }}>DATE </Text>
                                <Text style={{ flex: 1, color: '#2088dd', fontWeight: 'bold', fontSize: 12 }}>TIME FROM</Text>
                                <Text style={{ flex: 1, color: '#2088dd', fontSize: 12 }}>TIME To</Text>
                            </View>
                            <View style={{ flexDirection: 'row', paddingVertical: 6, paddingLeft: 20 ,borderBottomWidth:0.7,borderBottomColor:'grey'}}>
                                <Text style={{ flex: 1, color: 'black', fontWeight: 'bold', fontSize: 12 }}>15/3/2021 </Text>
                                <Text style={{ flex: 1, color: 'black', fontWeight: 'bold', fontSize: 12 }}>15:00</Text>
                                <Text style={{ flex: 1, color: 'black', fontWeight: 'bold', fontSize: 12 }}>20:00</Text>
                            </View> */}
                            <Title style={{ color: "black",marginTop:5,fontSize:16 }}> Size/Dimensions</Title>
                            <View style={{ flexDirection: 'row', paddingTop: 5 }}>
                            <Paragraph style={{ margin: 10 }}> WTC-Textiles are used clothing graders and used shoes graders, a name you can trust.</Paragraph>

                            </View>
                            <View style={{flexDirection:'row',marginVertical:20}}>
                                <Paragraph style={{ fontWeight: 'bold',padding:5 }}>Price: </Paragraph>
                                <Title style={{ color: "#2088dd" ,fontSize:16}}>Rs. 5,000</Title>
                            </View>

                            <View style={{ margintop: 0 }}>
                                <Button color='#2088dd' labelStyle={{ color: 'white', paddingLeft: 10 }} style={{ backgroundColor: '#2088dd', }} >SUBMIT REQUEST</Button>
                            </View>
                        </Card.Content>
                        

                        {/*  <Card.Actions style={{ alignSelf: 'center' }}>

                          <View style={{flexDirection:'row',marginTop:20}}>
                                <Paragraph style={{ fontWeight: 'bold',padding:5 }}>Price Range: </Paragraph>
                                <Title style={{ color: "#2088dd" ,fontSize:16}}>Rs. 1000-5000/</Title>
                            </View>
                            <View style={{flexDirection:'row',marginTop:20}}>
                                <Text style={{ fontWeight: 'bold',padding:5}}>Size/Dimensions: </Text>
                                <Title style={{ color: "#2088dd" ,fontSize:16}}>Rs. 1000-5000/</Title>
                            </View>
                            <Paragraph style={{ fontWeight: 'bold' }}> </Paragraph>

                            <Button titleStyle={styles.Detailbtn} onPress={() => checkPermission()}
                                icon={<Icon style={styles.Detailbtn} name="download" />}
                                title="  Download"
                                type="clear"
                            />
                            <Button titleStyle={styles.NextPrebtn} onPress={() => { Previous(); DisplayAds() }}
                                icon={<Icon style={styles.NextPrebtn} name="leftcircle" />}
                                title="  Pre"
                                type="clear"
                            />
                            <Button titleStyle={styles.NextPrebtn} onPress={() => { Next(); DisplayAds() }}
                                icon={<Icon style={styles.NextPrebtn} name="rightcircle" />}
                                title="  Next"
                                type="clear"
                            />
                            <Button titleStyle={styles.Detailbtn} onPress={() => onShare()}
                                icon={<Icon style={styles.Detailbtn} name="sharealt" />}
                                title="  Share"
                                type="clear"
                            />
                        </Card.Actions> */}
                    </Card>
                </View>


            </ScrollView>
            {/* <Icon style={styles.CreateIcon}
                size={40}
                raised
                name='pluscircle'
                type='font-awesome'
                color='White'
                onPress={() => {
                    if (global.LoginDetail == null || global.LoginDetail == undefined) {
                        navigation.navigate("SubmitGuest");
                    } else {
                        navigation.navigate("AddHandiCrafts");
                    }
                }} /> */}
        </SafeAreaView>
    );
}

export default Detail;
// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, ImageBackground, TouchableOpacity, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, CheckBox } from 'react-native-elements';
//import { TextInput } from 'react-native-paper';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId } from '../Common/IDs';
import DocumentPicker from 'react-native-document-picker';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import styles from '../Common/CommonStyles';
const image = { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo65zKZfMGxojTmtba2hplTbP5EQuFmCaOzQ&usqp=CAU" };

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function DonateGoods() {
    const [email, Setemail] = useState('');
    const [FirstName, SetFirstName] = useState('');
    const [LastName, SetLastName] = useState('');
    const [Checked, setChecked] = useState(false);
    let [singleFile, setSingleFile] = useState(null);

    const [password, Setpassword] = useState('');
    const [ConfirmPassword, SetConfirmPassword] = useState('');
    const [About, SetAbout] = useState('');
    const [ReferralId, SetReferralId] = useState('');
    const [isLoading, SetLoading] = useState(false);
    const [selectedPrice, SetSelectedPrice] = useState();
    const [SelectedPreference, SetSelectedPreference] = useState();

    ////////////////////date

    const [date, setDate] = useState(new Date());
    const [dateIn, setdateIn] = useState(new Date());
    const [dateOut, setDateOut] = useState(new Date());
    const [showDate, setshowDate] = useState(false);
    const [showIn, setshowIn] = useState(false);
    const [showOut, setshowOut] = useState(false);

    const navigation = useNavigation();

    function SaveReferral(text) {
        if (text == undefined || text == '') {
            // Alert.alert("Amount must be greater then or equal to zero");
            return false;
        }
        const NON_DIGIT = /^[0-9]+$/;

        NewRefferral = parseFloat(text.toString().replace(NON_DIGIT, ''));
        SetReferralId(NewRefferral)
    }
    function login() {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(email) === false) {
            Alert.alert("Invalid credentials", "Email is Not Valid");
            // Setemail( text )
            return false;
        }

        SetLoading(true);
        try {
            // console.log('res : ' + email + password);

            const response = axios.post(
                BASE_URL + "ApiAccount/UserLogin?Email=" + email + "&Password=" + password
            ).then((response) => {
                SetLoading(false);
                if (response.data.Data === undefined || response.data.Data == null) {
                    Alert.alert("Invalid credentials", "Your Email and Password Not Exist! ")
                }
                else {


                    global.LoginDetail = response.data.Data;
                    // console.log(response.data);
                    (async () => {

                        await AsyncStorage.setItem('Logged_UserId', JSON.stringify(response.data.Data.Users_ID));

                    }

                    )();
                    navigation.navigate('Home');
                }
            }).catch((error) => {
                Alert.alert("Internal Server Error", error.message)
            }).then(function () {

            });



        } catch (error) {
            // handle error

            Alert.alert("Internal Server Error", error.message)
            isLoading(false);

        }
    }

    ////////////////////////////////////DAte piker


    const onChangeDate = (event, selectedValue) => {
        const currentDate = selectedValue || new Date();
        setshowDate(Platform.OS === 'ios');

        setDate(currentDate);

        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const onChangeIn = (event, selectedValue) => {
        const selectedTime = selectedValue || new Date();
        setshowIn(Platform.OS === 'ios');
        setdateIn(selectedTime);
        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const onChangeOut = (event, selectedValue) => {
        const selectedTime = selectedValue || new Date();
        setshowOut(Platform.OS === 'ios');
        setDateOut(selectedTime)
        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const showDatepicker = () => {
        setshowDate(true)
        setshowOut(false)
        setshowIn(false)
    };
    const showTimepickerIn = () => {
        setshowIn(true)
        setshowDate(false)
        setshowOut(false)
    };
    const showTimepickerOut = () => {
        setshowOut(true)
        setshowDate(false)
        setshowIn(false)
    };


    function FormatTime(time) {
        // Alert.alert(time.getHours()+":"+time.getMinutes());
        return time.getHours() + ":" + time.getMinutes();
    }
    const formatDate = (date) => {
        return ` ${date.getDate()}/${date.getMonth() +
            1}/${date.getFullYear()} `;
    };
    const InTimeFormat = (time) => {
        return ` ${time.getHours()}:${time.getMinutes()}`;
    };
    const OutTimeFormat = (time) => {
        return ` ${time.getHours()}:${time.getMinutes()}`;
    };


    function submit() {
        if (password != ConfirmPassword) {
            Alert.alert("Field Validation", "Your Password does not match!")
            return false;
        } let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(email) === false) {
            Alert.alert("Invalid credentials", "Please enter valid email");
            // Setemail( text )
            return false;
        }
        SetLoading(true);

        const model = {

            FirstName: FirstName,
            LastName: LastName,
            Email: email,
            Password: password,
            confirmPassword: ConfirmPassword,

            AboutMySelf: About,
            ReferralId: ReferralId,
        };
        //console.log('res : ' + JSON.stringify(model));
        try {
            axios.post(BASE_URL + 'ApiAccount/Register ', { model: model })

                .then(response => {
                    //console.log(response.data)
                    SetLoading(false);
                    if (response.data.IsSuccess == 'Yes') {
                        Alert.alert('Congratulations!', 'You have successfully registered');
                        (async () => {

                            await AsyncStorage.setItem('Email', email);
                            await AsyncStorage.setItem('Password', password);
                            // await AsyncStorage.setItem('UserId', response.data.Data.Users_ID);

                        }

                        )();
                        // navigation.navigate('ProfileStack', { screen: 'UpdateProfile' })

                        login();
                    }
                    else {
                        SetLoading(false);
                        Alert.alert("", 'This Email/Username is already Exist.')
                    }

                }, (error) => {
                    SetLoading(false);
                    // console.log(error);
                });
        } catch (error) {
            // handle error
            SetLoading(false);
            Alert.alert("Internal Server Error", error.message)

        }
    }

    let selectFile = async () => {
        //Opening Document Picker to select one file
        try {
            const res = await DocumentPicker.pick({
                //Provide which type of file you want user to pick
                type: [DocumentPicker.types.images],
                //There can me more options as well
                // DocumentPicker.types.allFiles
                // DocumentPicker.types.images
                // DocumentPicker.types.plainText
                // DocumentPicker.types.audio
                // DocumentPicker.types.pdf
            });
            //Printing the log realted to the file
            //console.log('res : ' + JSON.stringify(res));
            //Setting the state to show single file attributes
            setSingleFile(res);
        } catch (err) {
            setSingleFile(null);
            //Handling any exception (If any)
            if (DocumentPicker.isCancel(err)) {
                //If user canceled the document selection
                Alert.alert("Canceled", "You have not selected any file");
            } else {
                //For Unknown Error
                alert('Unknown Error: ' + JSON.stringify(err));
                throw err;
            }
        }
    };
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ScrollView style={{ padding: 15 }}>

                <View >
                    {/* <Image style={{ height: 25, width: 100, alignSelf: 'flex-start' }} source={require('../Icons/logo.png')}></Image> */}
                    <Text style={{ textAlign: 'center', paddingBottom: 20, fontWeight: '100', color: 'grey', fontSize: 12 }}>Donate your  unused clothes and support the needy persons.
                            </Text>


                    <View >
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                            <View>
                                <Text style={styles.HeadingsTitle}>ITEM DETAILS</Text>
                            </View>
                        </ImageBackground>
                    </View>
                    <View style={{ margin: 10 }}>
                        <Text style={styles.labelStyle}>Item Name </Text>
                        <TextInput
                            style={styles.TextInput}
                            onChangeText={(text) => Setemail(text.trim())}
                            placeholder='Item Name'

                        //value={value}
                        />
                        <Text style={styles.labelStyle}>Item Description </Text>
                        <TextInput
                            style={styles.TextInput}
                            onChangeText={(text) => Setemail(text.trim())}
                            placeholder='Item Description'

                        //value={value}
                        />
                        <View style={{ flexDirection: 'row' }}>
                            <Button
                                title="Choose Picture"
                                type="clear"
                                onPress={() => selectFile()}
                            />

                        </View>
                        {singleFile == undefined || singleFile == null ?
                            <View >
                               

                            </View>
                            :
                            <Image source={{ uri: singleFile.uri }}
                                style={[styles.ProductCardsImage, { margin: 10, borderRadius: 10 }]}
                                resizeMode='contain'
                                onPress={() => selectFile()}
                            />
                        }


                        <View style={{ flexDirection: 'column', marginTop: 10 }}>
                            <Text style={styles.labelStyle}>Price Range</Text>
                            <View style={styles.PikerContainer}>

                                <Picker mode='dropdown'
                                    selectedValue={selectedPrice}
                                    style={styles.PikerStyle}
                                    onValueChange={(itemValue, itemIndex) => SetSelectedPrice(itemValue, itemIndex)}
                                    dropdownIconColor='grey'
                                >

                                    <Picker.Item label="Rs. 1000 - Rs. 5000" value={0} />
                                    <Picker.Item label="Rs. 5000 - Rs. 10,000" value={1} />
                                    <Picker.Item label="Rs. 10,000 - Rs. 50,000" value={2} />
                                    <Picker.Item label="Rs. 50,000 - Rs. 100,000" value={3} />
                                    <Picker.Item label="NA" value={4} />

                                </Picker>


                            </View>
                        </View>
                        <Text style={styles.labelStyle}>Size/Dimensions </Text>
                        <TextInput
                            style={styles.TextInput}
                            onChangeText={(text) => Setemail(text.trim())}
                            placeholder='Size/Dimensions'

                        //value={value}
                        />
                        {/* <TextInput
                            label="Size/Dimensions"
                            mode='outlined'
                            //value={text}
                            //onChangeText={text => setText(text)}
                            theme={{
                                colors: {
                                    placeholder: 'grey', text: 'black', primary: 'black',
                                    underlineColor: 'white', background: 'white'
                                }
                            }}
                            style={{ marginVertical: 10, fontSize: 12 ,backgroundColor:'white'}}


                        /> */}

                    </View>
                    <View >
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                            <View>
                                <Text style={styles.HeadingsTitle}>Pickup Schedule</Text>
                            </View>
                        </ImageBackground>
                    </View>
                    <Text style={styles.labelStyle}>Please select contact preference</Text>
                    <View style={{ flexDirection: 'row', margin: 10, marginTop: 0 }}>
                        <View style={styles.PikerContainer}>

                            <Picker mode='dropdown'
                                selectedValue={SelectedPreference}
                                style={styles.PikerStyle}
                                onValueChange={(itemValue, itemIndex) => SetSelectedPreference(itemValue, itemIndex)}
                                dropdownIconColor='grey'
                            >

                                <Picker.Item label="No preference" value={0} />
                                <Picker.Item label="Call" value={1} />
                                <Picker.Item label="SMS" value={2} />
                                <Picker.Item label="Whatsapp" value={3} />
                                <Picker.Item label="Email" value={4} />


                            </Picker>


                        </View>
                    </View>
                    <Text style={styles.labelStyle}>Preferred Collection Date </Text>
                    <View style={{ flexDirection: 'row', paddingTop: 10, marginLeft: 20 }}>
                        <Text style={[styles.DateTimeLabels]}>DATE </Text>
                        <Text style={styles.DateTimeLabels}>TIME FROM</Text>
                        <Text style={styles.DateTimeLabels}>TIME TO</Text>
                    </View>
                    <View style={{ flexDirection: 'row', margin: 10 }}>

                        <View style={{ flex: 1, paddingHorizontal: 5 }}>
                            <TouchableOpacity onPress={showDatepicker}>
                                <Text style={styles.DateTimePikerStyle}>{formatDate(date)}</Text>
                            </TouchableOpacity>

                            {showDate && (
                                <DateTimePicker
                                    timeZoneOffsetInMinutes={0}
                                    value={date}
                                    mode="date"
                                    display="SPINNER"
                                    onChange={onChangeDate}
                                />
                            )}
                            {showIn && (
                                <DateTimePicker

                                    timeZoneOffsetInMinutes={0}
                                    value={dateIn}
                                    mode="time"
                                    display="SPINNER"
                                    onChange={onChangeIn}

                                />
                            )}
                            {showOut && (
                                <DateTimePicker

                                    timeZoneOffsetInMinutes={0}
                                    value={dateOut}
                                    mode="time"
                                    display="SPINNER"
                                    onChange={onChangeOut}
                                />
                            )}
                        </View>
                        <View style={{ flex: 1, paddingHorizontal: 5 }}>
                            <TouchableOpacity onPress={showTimepickerIn}>
                                <Text style={styles.DateTimePikerStyle}>{InTimeFormat(dateIn)}</Text>
                            </TouchableOpacity>

                        </View>
                        <View style={{ flex: 1, paddingHorizontal: 5 }}>
                            <TouchableOpacity onPress={showTimepickerOut}>
                                <Text style={styles.DateTimePikerStyle}>{OutTimeFormat(dateOut)}</Text>
                            </TouchableOpacity>

                        </View>

                    </View>
                    <Text style={styles.labelStyle}>Alternative Collection Date </Text>
                    <View style={{ flexDirection: 'row', paddingTop: 10, marginLeft: 20 }}>
                        <Text style={[styles.DateTimeLabels]}>DATE </Text>
                        <Text style={styles.DateTimeLabels}>TIME FROM</Text>
                        <Text style={styles.DateTimeLabels}>TIME TO</Text>
                    </View>
                    <View style={{ flexDirection: 'row', margin: 10 }}>

                        <View style={{ flex: 1, paddingHorizontal: 5 }}>
                            <TouchableOpacity onPress={showDatepicker}>
                                <Text style={styles.DateTimePikerStyle}>{formatDate(date)}</Text>
                            </TouchableOpacity>

                        </View>
                        <View style={{ flex: 1, paddingHorizontal: 5 }}>
                            <TouchableOpacity onPress={showTimepickerIn}>
                                <Text style={styles.DateTimePikerStyle}>{InTimeFormat(dateIn)}</Text>
                            </TouchableOpacity>

                        </View>
                        <View style={{ flex: 1, paddingHorizontal: 5 }}>
                            <TouchableOpacity onPress={showTimepickerOut}>
                                <Text style={styles.DateTimePikerStyle}>{OutTimeFormat(dateOut)}</Text>
                            </TouchableOpacity>

                        </View>

                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <CheckBox
                            // title='You are agreeing to the Privacy Policy'
                            checked={Checked}
                            onPress={() => { setChecked(!Checked) }}
                            style={{ padding: 0 }}
                            size={25}
                        />
                        <Text style={[styles.labelStyle, { paddingTop: 7, marginLeft: 0 }]}>You are agreeing to the  <Text style={{ color: '#2088dd', fontWeight: 'bold', fontSize: 12 }} onPress={() => navigation.navigate('PrivacyPolicy')}>Privacy Policy</Text></Text>
                    </View>

                    {/* <Button containerStyle={{ borderRadius: 20, height: 40, marginBottom: 40, marginTop: 10 }}
                        title="Donate Now"
                        // disabled={(FirstName == '' || LastName == '' || email == '' || password == '' || ConfirmPassword == '') ? true : false}
                        onPress={() => navigation.navigate('ThankYou')}
                    /> */}
                    <View style={{ flexDirection: 'row', marginVertical: 5, marginBottom: 25 }}>
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="DONATE NOW"
                            titleStyle={{ fontSize: 12 }}
                            type='solid'
                            onPress={() => navigation.navigate('ThankYou')}
                        />
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="CANCEL"
                            titleStyle={{ fontSize: 12, color: 'grey' }}
                            type="outline"
                            onPress={() => navigation.goBack()}
                        />

                    </View>

                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default DonateGoods;
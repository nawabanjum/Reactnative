// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, Linking } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, SocialIcon } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import { TextInput } from 'react-native-paper';
import {bannerAdUnitId} from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function SubmitGuest({route}) {
    const [email, Setemail] = useState('');
    const [password, Setpassword] = useState('');
    const [isLoading, SetLoading] = useState(false);

    const [isLogin, SetLogin] = useState(false);
    const navigation = useNavigation();
    const { Type } = route.params;


    // useEffect(() => {
    //     // send HTTP request

    //     (async () => {


    //         try {

    //             let vPincode = await AsyncStorage.getItem('Email')
    //             let vPassword = await AsyncStorage.getItem('Password')
    //             if (vPincode != null && vPassword != null) {
    //                 login(vPincode, vPassword)
    //             }
    //         } catch (error) {
    //             // Error retrieving data

    //         }

    //     })();

    // }, [])
    //    const validate = (text) => {
    //         console.log(text);
    //         let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    //         if (reg.test(text) === false) {
    //           console.log("Email is Not Correct");
    //          // Setemail( text )
    //           return false;
    //         }
    //         else {
    //           Setemail( text)
    //           console.log("Email is Correct");
    //         }
    //       }

    function login() {

        SetLoading(true);
        try {

            const response = axios.get(
                BASE_URL + "ApiAccount/GuestLogin"
            ).then((response) => {
                SetLoading(false);
                if (response.data.Data === undefined || response.data.Data == null) {
                    Alert.alert("Invalid credentials", "Your Email and Password Not Exist! ")
                }
                else {

                    // (async () => {

                    //     await AsyncStorage.setItem('Email', email);
                    //     await AsyncStorage.setItem('Password', password);

                    // }

                    // )();`${Type}`
                    //console.log(Type)
                    global.LoginDetail = response.data.Data;
                    SetLogin(true)
                    navigation.navigate(Type);
                }
            }).catch((error) => {
                Alert.alert("Internal Server Error", error.message)
            }).then(function () {

            });



        } catch (error) {
            // handle error

            Alert.alert("Internal Server Error", error.message)
            isLoading(false);

        }
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <BannerAd
                unitId={bannerAdUnitId}
                size={BannerAdSize.ADAPTIVE_BANNER}
                requestOptions={{
                    requestNonPersonalizedAdsOnly: true,
                }}
            />
            <ScrollView style={{ padding: 25 }}>
                <View>
                    <Image style={{ marginLeft: 10, height: 30, width: 130, alignSelf: 'flex-start', marginBottom: 30 }} source={require('../Icons/logo.png')}></Image>

                    <View style={{ paddingVertical: 60 }}>
                        <Button containerStyle={{ borderRadius: 20, height: 40, marginTop: 20 }}
                            onPress={() => login()}
                            title="Submit as Guest"
                        />
                        <Button containerStyle={{ borderRadius: 20, height: 40, marginTop: 20 }}
                            onPress={() => navigation.navigate('Login')}
                            title="Sign in"
                        />
                        <Button containerStyle={{ borderRadius: 20, height: 40, marginTop: 20 }}
                            onPress={() => navigation.navigate('Register')}
                            title="Sign up"
                        />

                    </View>

                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default SubmitGuest;
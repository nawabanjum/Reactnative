// In App.js in a new project

import React, { Component, useState, useEffect } from "react";
import { View, Text, Linking, Alert, TextInput, FlatList, Share, ActivityIndicator, FastImage, ImageBackground } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Card, Title, Paragraph } from 'react-native-paper';
import Icon from "react-native-vector-icons/AntDesign";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native';
import { ListItem, Avatar, Button, ThemeProvider, Image } from 'react-native-elements';
import axios from 'axios';
import { SliderBox } from "react-native-image-slider-box";
import { BASE_URL } from '../Common/Urls';
import styles from '../Common/CommonStyles';
import Rate, { AndroidMarket } from 'react-native-rate';
import { bannerAdUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function Home(props) {
    const navigation = useNavigation();
    const [Remarks, SetRemarks] = useState('');
    const [Data, setData] = useState([]);
    const [DataCount, setDataCount] = useState([]);
    const [isLoading, SetLoading] = useState(false);
    const [Rated, SetRated] = useState(false);

    const image2 = { uri: "https://i.pinimg.com/originals/3c/24/46/3c24462450c2a902bf7e18f3d9aada81.jpg" };
    const image = { uri: "https://i.pinimg.com/originals/3c/24/46/3c24462450c2a902bf7e18f3d9aada81.jpg" };
    const images = [
        "http://www.worldfastener.com/wp-content/uploads/2016/11/banner.jpg",
        "http://fazalsons.com/uploadedimages/v3v3R.jpg",
        "http://fazalsons.com/uploadedimages/X3X3w.jpg",
        "http://fazalsons.com/uploadedimages/cqcqg.JPG",
    ]

    const WhatsNewList = [
        {
            Title: 'Lord & Taylor to relaunch online, with help from RTW Retailwinds',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://etimg.etb2bimg.com/thumb/high-level-meet-to-discuss-e-commerce-policy-on-saturday-size-419850-updated-2021-03-12t09-38-07z/81465546.cms?width=362&height=240'
        },
        {
            Title: 'didas aims for DTC to be 50% of sales by 2025',
            Subtitle: 'A new four-year strategy is predicated on doubling e-commerce sales, building up an athleisure offering and refocusing on women, among other things.',
            uri: 'https://www.aseanbriefing.com/news/wp-content/uploads/2018/07/ASEAN-Briefing-Thailands-E-commerce-Landscape-Latest-Trends-and-Opportunities-002.jpg'
        },
        {
            Title: 'GameStop taps former Chewy execs to lead transformation group',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAPDw0NDQ0NDQ0NDQ0ODQ0NDQ8NDQ0NFREWFhURExUYHCggGBolGxMVIT0hJzU3Oi4uFx8/ODUsNygtOisBCgoKDg0OGhAQGjceHx0tKy0tKzUrLTUtLi03NzYtKystKzc3KzcrKy0tKysrLTcrNy0tKystLTc3NDgtLSsrN//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIDBQYHBP/EAEAQAQABAwIBBwYLBgcAAAAAAAABAgMRBBIGBRMhMUFRYSJxgZGhsgcjMjNSYnOxwcLRJEJjcqLwNFN0k6PS4f/EABgBAQEBAQEAAAAAAAAAAAAAAAAEAgED/8QAHxEBAAEEAgMBAAAAAAAAAAAAAAECAzEyEVESISJB/9oADAMBAAIRAxEAPwD3EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHzco35ot1VR146PP2R+HpBF7lCzRO2u7TFXdnOPP3PooriqIqpmKonqmJzEvj0/J9q3RmummasZuXaojMz2znshz17iXT6a5XFjdeoqjpoojbRFfZVEz6erwcmqIy7FMzh144+jjqn9/TVUx3xcifyt7yZy7Y1HRRVtr+hX0T6O9yK6Z/Wpt1RmGzAaYAAAAAAAAAAAAAAAAAAAAAAGs5auY5mmf3r1mJ/3aP0ls3McXarZNFOfK+LqoiOmZq3TiPZ7AW4h1s13J08T5FuIquR9OuYzFM+ERifT4OOtaeaqq8Rmd1UzM9VNMT1z6+rxba3qKrlVy5Xt3111TVtztznGIz2dBNMWdFevRjnL+qm3TPhETj1eXKefqr2pj5p9Of5Yjm7Vc0VxF3bM0ZmMzPhT2uK0HGWp012I1dudu7orpom3dpx+9HZXHmdtTTEdPbPTMz01VT4z2sGu0Nu/RVbvUU101d8dMeMT2SedOODwqzy9S4a5Vp1els6iiqK4rp+VT1VT3to8y+BimvTzynydXM1W7F2zqNPVP+XeiqJj128+eZ73pr3jCecgDrgAAAAAAAAAAAAAAAAAAAA8x445QmjU6yuOuxZpot+EzTTET665enPK/hM0U06qqZnFvW2cbp6qblMRT+WifTIL8PVZ09ievNq3OZ6c5phm5TvfEWbXZF+/V6cU/wDaXz8PUzTp7FNUYqptW4qjumKYiYU11XlY7q6/uoTdqunzgMPR0/wf0Rz2qqx0zasRM98RVX+rt3EcAz8df+yp9lX/AK7dTb1SXNpAG2AAAAAAAAAAAAAAAAAAAABoOKuSKNVzMXombNNVXOTT0VUxMRiqJ7OpvwHmmksxa3WqKpqotVV26aqvlVU0ziKp8ZiHwav5dX89Xu0Nvqv8Rqv9Rf8AflqdVHlVfaV+7bTdqumJASw9HTcBz8fd+x/NH6u5cJwJP7Tcj+BV79Du1NvVLd2AG3mAAAAAAAAAAAAAAAAAAAAAA8713+J1X2933ml1PztyMzjMzjPRnojPsj1N3yn0arVfa1NJqfna/wC+5JVlZThBJKJcadNwHH7RcnusT7a6f0d04bgL5+99jHvw7lRb1S3dgB6PMAAAAAAAAAAAAAAAAAADKMgkRkyDz3lro1mqj+JE+uimWk1XztX99je8QxjW6nx5uf8AipaHVfOz6PuSV5WUYhAgZadVwBHxuonutUR66p/R27jPg/p8rUz9WzHtqdmqt6pbuwA28wAAAAAAAAAEZEAJRlGTIJyZRlGQWMq5RkF8oUybgXyZY9xuBxHFEY1tz61u1P8ATj8HO6ufjfRH3S6Xi6P2umfpaej2V1w5nWfOR5o+5LXsrt6oAYbdp8H9Pkamr69un1UzP4uscxwHTjT3Z+lfn2UUumyqo1hJc2lYViUtsLCISAAAAAAAACMIwsAphDIgGNWWXBtBhmUZZpoVm2DDNSJqZJtKVWpBTejnEVW5Ya4kHO8YU/GaevvouUT6JiY96XK6yfLjzU/e7PiDTzdszERmu3MXKI75jOafTEz6cOG1FeZifD2wmux7VWp9Moxc/T25j0TP3HPZxFETVMziOjrnzdbzej0TgynGkpn6Vy7P9WPwb6Gu5D0s2dPYtVfKptxv/nnpq9sy2UTHespjiEdU8zK0LQpvjvRzsd7rLIlh56GSirMZBYAAAAAAAFNyN7HlGQZN5vYpVyDNziOdYVZBn55HPsCswD6J1Cs6qHzzCNoMlWrjuYa9V9VPNkWQfDfrmrqplz/KXDNd6qa6KqbdUzmc0zO6e+el2NFiGam05McuxPGHnMcG6ntu28eFE/q2vJXDdyxVvzurjqmYjo83c7amheKIciiIdmuZaCmm/HbK0Td7ZlvZtwrNmGmWmiuvtyvFdTZzp47lJ08A+GKqn025nDJFhk5sFIuT3yvF2rvNidoLRenwWi94Me1O0GWLseKYrhhwnAM26O8YcAKyhbACqMLYMAphGGTBgGPajay4NoMWxOxl2m0GLYtFDJEJiAVppWiFohIIhYSAABgwkBXBhYBTabVgFNphcBTBhbBgFcIXwAxGGTYbAUwL7DYCmDC+w2gpgwvtNoK4ML7TaCuDC20wCIhKcGAAASAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q=='
        },
        {
            Title: 'Why Nordstrom has gone all-in on DTC brands',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_omS2xw4RY_KnAWupqw7qD02aDWL8gS0FJg&usqp=CAU'
        },
        {
            Title: 'Lord & Taylor to relaunch online, with help from RTW Retailwinds',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSInj2iJzDxIsKUyIPza72jqvh0bi2kI2t2NQ&usqp=CAU'
        },
        {
            Title: 'What is the new retail playbook in a post-pandemic world?',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhURExMWFRIVFxsbFhYXGBsgFhsaFRsYFh4ZFBgaHyghGhoxHhcWIz0hJykrLi4uGB8zODM4QyguMCsBCgoKDg0OFRAPFSsdHR0tNy0tLS0tKy0tLS03Ky43MSstLS0tKy0tKy43Ny4tNy0tLSsrLis3Ky4tLTc3LTg3N//AABEIAPcAzAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcEBQgDAgH/xABDEAACAQMCBAUBBAcFBQkAAAABAgMABBESIQUGMUEHEyJRYXEUMoGhIzNCUmKR0RVygrHwVJKTwuEIFiRDRFNjwdL/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAaEQEBAQADAQAAAAAAAAAAAAAAAREhIkEC/9oADAMBAAIRAxEAPwC8aUpQKUpQKUpQKUpQKUqMc1c9WnDmEcpd5SM+XGAWAPQtkgD+eaCT0qhucvFK4mlX7KrwRqpB1E6mYkZOFOMDAHfqaiFxzDxa6lYxTXDNHErMIXlGFwGJKowzu/tmg6opXOHK/OfG7GUtJBd3UZUqY5RMRkEHUrkMQwAI9vV9KvjlbmKDiNutzAfSdmU/fRx1SQdmGfxBBGxFBt6UpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQavmTjkdhA1zKGKJ1CgFvrgkVDG8ZuHgRs0dwFlzoOhdwrFScB8jcH5rVeKPHVmuBaF0jit5ofNZ8+oSK7PjBHpH6IagRgsckbVFpOB2avoUGSDSHiBYMYxKTJoDZ2+8D369T1ISXj3jSqhxaRq51YTzBIvp0Z1t6eus40ewznfasOKcclu5nnlUapDlzvnJAAxhsbAYH0rMuUghk2ijkUZ2kVSTn5x/wDe3tWoLRjXkEBjnC4AAySAN/n8hQfTyeY2N1RBgMR+yBnYZ9TfHc46dawftUiOZI9cZIwCjOG0jAALL12VfxHSvEMxOATW5jgWD0EBp8anZ8mOFMA/c/bk36HIyyLjJOJblanzs14RcXvNj9on2IIHnPsVIYHDDGcgGpB4WcUnsL6PyixhnkSOdSPRpZsazgYUrknPtnsa0UN0MkgZJPfGf5DYfQbV9XV6zjTk6Ttgd/r8VWXT9xzNZRg6ruAaeo81M7fwg5J+KgfFfFnLFbWEFR0eXOT8hARgfU5+BVKoAnQDPc/0+Kybi5MKDGNbZ3boMYPTv1H50Fl3nindqupjDGvvpP5ZJyfpUW4n4wcRf0wzaR+/5cef8IKnH4/yqB3aOx1OSze59v4f6V4CgmVt4k8XRtX212+GSMqfjGjp9MVcfhb4gtxXzIZogk8Shiyfq2BOMgE5U57ZI+e1c3q1Xv8A9nvhqLaz3QYGSWXQwHVViGQD8nWT9NNBbFKUoFKUoFKUoFKUoFKUoFKUoOdPEKTVfXesjAkAyQSABpxkDqMdq8+XlHlDHTTtgYH4DtWz8XbM/bpwgyZBEcdtTBUAydhnT3+a1vAEKxqrDDBQCPYgYI2qxKj/ABKE6j9a1V0hAJqT8UXBNaC5OQRSjG4OdL68ZCKzkHp+jVmAPwSMfjX0XbyQzHLTuzM3ciMgb/V2c/4RWNaT6VlX96Ij+TK3+QNZ9vftCtrImnUscijUoYZMsudmBHRxWZObW7esjGRv9f6/GvWE5Nel1ePcvqcrqwB6VVRgFj0UAdWPb29qeXpAPyKrL2jGWA+a8uYl9KH+Jv8AJa+4WIYH5rz43JlQPZm/yjqjBsG1ZiJ6glD7MN6xA39ayOHfrV+N/wAq8WG5/GoP1KmnhZzK/D76P1HyJ2WOZe3qOFf4Kk5z7Fh3qGIKz+G27SSxxr953VV/vMQo/Mig7CpSlApSlApSlApSlApSlApSlBRHjNLpup8EhtMBGCQdtW4I6bkVpuXmJiQkkkopJJ3JIG5rZ+N4xeyD96KIjbtqI/5T/KtPwKYCJATjCL/kKsR4cZO5qNz5z8YNb/jEwJ6itC7ZpSMC1wGyQSoJ1fKnZgP4tOo/hWdFYHeEndHyp7FXAyR8EBGH1NYixYzkbH5rZcG4pHFIvnxC4iUEafNZHUHfZkYZwcnSdtz0zms863MzKy7fg5AJB9WNvr7VjQvhhqG2d9u1ZnF+IQ/ftZiQf/KlADjPs6kq30JBHu3WvDhjSSE+Z5aj3eRFOfoTk1WW1FkprScyWr5UqvoGdR7ZPv7dBW0tBNLKILdNcrn0xq8ZBwCTpYPp6Anr2r413KuyPGyOpwysuGHwyn/I0EehCop39Z6nsq9z8n4rFG+/5fFb654Osm6r5bfA9BPyv7P4bfFaie1eJtLjHz2PyDQfCLVu+CXJjSSDiUw/RxkiBf3nGxc/wruP73tp3qiNc1evgDxCR7a4gbJjhkBjYj0jzQSyKfgrqx/8nyKC06UpQKUpQKUpQKUpQKUpQKUpQeFzZxS/rI0fHTUoPX2yK8Dwa2P/AKeH/hp/Ss6lBrv7BtP9mg/4Sf0qmvFyzuLW68xIYYrRlVYmWGAgvgswbUhbVsx9sYq9q8L2yinXRLGkiddLqGXI74Peg5FMWTkkfQRoB+ACgCt3ZctarczRxtNKQSIxGpwFO50hcntXR/8A3Wsf9jt/+En9K564vcPBcW3kSNF5jt5nluVJAuNIDFT00nGOmw9qCLHUjHVEqlCuzxID6skZQruux6jHT3q6PCbh1lxO1c3FpG00MhRpAgVWDDUMaMDUAcEAe3vVhXPKNhIzO9pA7N95mjUse/qJGTW0sbKKBBHFGkca9ERQqj6AbUGt4VytZWj+ZBbxxvgjUBvg4zgnp0rL4jwi3uP1sSOR0JHqH0Ybj+dZ1KDQtybYHrbr/vPn+eqvCbkLhrjDWykexZ//ANVJaUEQg8MeEo2oWgPw0krL/uM5X8qlVpapEixxoqRqMKiABQPZVGwFetKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKCoPETma6fiEnDopjHb+UBIEChyXGo+vBZdmA2IqqeYuDRQEKgPyScmp1fyeZxy8brglf93Cf8taDmPh01zcGOFNbKpYjIGw+TgZ36fX2p4Jh4P87XctzHYTSCSERkIWH6QFQWGX77KRvmrqrlOfh13ZrJOMx6U2kSRcjOn7pVs7q46dQ2KsLwt4xIqQTajiRvLlGfS3q0a8e/Rs/Ud6guqlKVQpSlApSlApSlApSlApSlApSlApSlApSlApSlAr4mfSrNgnAJwOpwM4Ga+603MV7b6TaSmJmnRgIZJAnmDoR+9j5AOKCkLJ5mvbm8aF0Ersyo6SnZizfeRG6ZA6f9dPzDb3UkjMiTBGHqVElCNjJGrIGr8V2r65zsp7K4wLNbCBhhNEsrwu/XLyahg/guO471GjHPcK7BAQm76mBKjc5Or6Gg2E0dzKTG4mJkGnDeYcuzbMQ3fGkf4RVteG/KU8QijkjZEhOp2dSNT6teFBAyNXf2FVj4d8BNwzSTcOF1anbzGleBUIJyUZD+k7grgnIG43z0Vytx23uVaKAFfs4VSpIOBghcEE5+6RvvtUG9pSlUKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKqfxshj82xlOksrujoJAshUqXXGWGACGOdtyB3FTjnri8tlZvcxRiQxkFwWK4Tu2VBO23QVUPGP7FvtP2mBrC4lGpZVPoOrfLEek5z1K7b5IoNPwrnhstb3ANzYyZGhhmSNeuRkb4H7PfAxg7nM5c4Fbw3N0JnD2SJ5jKCS7hPKdY9tyP0oz3IwP2jXxLwG4s7Oazjiik1yRk3iKDKbeXKt1yVVSqE6SRiT4JqC8au2M7RrI7IGZQdTkn9kk5PU7k42Oo+9BJuduc570BFP2e2HpW3XIOkdNQUbjHb7tWh/2feF+VYSTlNJnmOk9NUcY0qcf3jL+VQXh/It5dQRy3k0dlbrGAXIxLIpwR5y5UHbbLnV9djWbwbmC04M2i04jPOADmJgXtznJyFVPTuc5VvrmoL+pXjZys8aOy6WZQSvsSASM/HSvaqFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoItzzfz/Z3hgsjdiVGR8yIiBWBU51HU3Xoo/Gud7Dg1xc3sNhPm1eT05nDYyAd0yOpIwADjJxttU357ebhl/c+Xc3Cq6CZNEmdJlZxiRWySmoEYXBAArW8E5su+IFbaeH7UQylZYk/SoxPpfCjGAcbjSQATk4oJjxOyt+WrTGuW5uJjot02VVZ8E6RvpXUuojfJ2AGSarfiPPE6SaXgh1DGsBGDdiVDFiM/xYI747VffNfCo7i2WW5jQmJQ7gsBoZBqLRuxABBzuSBg9fei7y34NNMXFxNrdjlWDKAWOTqZkAUZJ3LAD3oJJzLwz+1bV+L21yZUjUtJbTHHlBE1Mo/Zb3yAM7dTsYNyVxCytuIwy3TZt4yWDRxtp149OpW9RUE9hnIG1W1xLlix4fw0RXUjJbSyI0iw5Ik05KQggEsCTqJGCcdcAmodf8+W1sunh/Do416CWTGrbbcA6u379QX/AMN4hFcxrNDIskTjKupyD/1+O1ZNV34OC5nhkvpyoE+0aKpXaNmUs2WOd9h8A+9WJVClKUClKUClKUClKUClKUClKUClKUClKUCol4gczDh6R64ZXimJRmjbSVOwA1AhtRycacH0mpYTiq98WLyaa1ktobCa4BwwlBXSjIdQKoCZGIxjGkDfrQV9xblzgt8xSCaSzu+uifV6mb3805JJ6erPsKtDwot/Jsvs7RRxzQNokMYAEmACsp7kkHBLb5VqorlTlyXjF69vqELKNT+dvIqqVBVRgF236HG3U+/RXJ/K68Oi8sSvKxwC79cLnSq9SFGo9ST84AADQ+LfA7i/t44In0p5itImceYF3K59+jAHbI+KpXj3JN607aLdlhGy65VwFAwMeokLt0/Lar28UuZ/7Ps2YRCaWQhI1ZcoGbo0nwPzOBXPHFuLXtvKqvPMxXBKNO7xEjDadLdUxgaWz9TQXt4QcOuI7JoblhLECBHq3XbIZV1dUHpHtnVVX83ctLdcQuLfhdqTFGQkshyUSZSS4iJbSo3UEH904wMVcPhlzgvFLQN5YiljAWRVGI+4DRfw+k7dsY36mI+Jb8ZtVZ4yq2QJy1uCZQuMlpiw9GSScrsMHJ9w+uT+LcQ4REsV/JbvaxoFRVb9MgUbAPgIVHsST87b23E+oBtxkA79d/cdjXLPIccM3FYvt8qaFyzG4kVw5A9KM5yM6iDuexFdTqc7jcGg/aUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQfE0epWXJGoEZHUZGMj5rnfi3Gb/AIU9xCbqfXFNpQvl4ipwylzJqw5U6sZxgjbvVwc6c0wWZWCaSWLzV2eJcsN8HDkEKfwJ3qo+L8l2V8Wey4o0lw25W4fVI5G27bMcbDIVqDO5R5tkv7uAvag3kbeiWIHBBBDK/dFKFhqzpz2FXzUX8OQgskQQRwSRkpKkYGkyLjLg99Q0tk5O+DuKlFBqeZoovIeSVkVI1JZpBlNI6hh7f6weh5+4lzZYMfM/sxNbbiRiDGQDjUCUyRt+7nbp2q7PEjl3+0bNoDIY1zksN8EYILL3UY/PPbNU5zB4eO7rIs1rHEqgZBJJAAGThQD/ADoLo5AhtfswmtZFlWXBaRRj7uwXT1TGT6TuMn3r58RIGmtGg+0LbRyfr5W7Qj7wXJAydlySBgt9DofB7lV7CORtTGOTGNW2ojJ1qvZcHY5Ocn4qacd4FbX0flXMQkQEMASQQR0IKkEfzoKGvLjl+xGmGB7yQbazuhO3UnCkbDoDVj+DvEJrmGSXyxFaDCQRhsrlS2rSuldAGw22JJ9qqPn/AJYS1vmsbV5LltIbQOsRY50SaR6/SVO2n7w2qyvDfj15Y28dreWQhgjXCyqw1kklsvDkkkkkltt+29QWtSvOCZZFV1OVYAqfcMMg/wAq9KoUpSgUpSgUpSgUpSgUpSgUpSgUNK8L+FnjdEbQ7KQrYB0sRs2DscHBwfagrDxp4/amFYNEr3EcqPG6RnQhB9X6RsKTpJ2Un1Bc9KqvlfgFxxq5cQkEqVMksnpKrnALqCSzbHYdx261L5PEO/tvMhuPJneORkeN1CuQpK5GgKpGx6jp2Ne3J3GrGS/huLaBra6J0SQrskqv94LgaWxkNjCnKg7gUFrcncuGwh0PM08rY1SN3C50j3OAcZJJNb+lKCB+L4vntPKsyylj+lKZ1mPo2jG56jIG5Ga5z5hto4rgxR4OkAZwdRbr6snBbJ9hXT/iPzJFw6zaaRS7E4iUHBL9jq7AdT8ZFUfxnxA4jHpWRItTKGz5Z1jPYsG0k47gfh2oLa8G+NXdzaFLsNrh0hXfOtlIOA+dyw09TuQRn3M/qEeFPNMHELXEcXkyR481OoLN+2rdWzg9dx09qm9BT3PfMNzwx5TDYrD5r/pLxxlXZhq2I67bAMdsY04FV5y7Pc8X4hb289xI6Sv6hkopRQXYIFIGdKkAgV0Nzw832KVIIlmmlHloj40evYs+rbSF1Nv1wB3qkrnw9tLRA/Eb/EuB6Ub17DohcEkD4XtQdExRhQFAwAAAPYDYV9VXPhZzEblmgiaWW0hTaWbUW1EjCiRt221HBGwxjbAqxqBSlKBSlKBSlKBSlKBSlKBSlKBWj5i4jIAYLaWCO6IBXzjkAHuI1Oo9CM9M++MVvKqnxyS10QyGSEXSuqhGcB3jbPXG4UMc6ugyd6CvOfOUOLh2nmAuS7a3aJVOG0hcqAA4XAG2MbZq7fDrhtgtnDPZxBRIuS7YM2royyOd8hgQQDgY2qi+UL/iU8wgsnlbcBoyfMgVckZYsSEXr6shjjY9K6D5O4bPb2+m4KeazamVCSik4yFJ36jP49+pDe0pSg0fOHDLe4tn+0CMxIpLeacR4G5LN1XoDkbjFULxbiPBZCJjFdSHHp1M2kgbbNqG34596vTn/gRv7KS2DMmrGSu5GNxt+0M4yO4zVG8Z8PrlhEFa1WOJca9bZbHcjR1+N/rQW54UfYmtjLaMpLY8xVGny8Zwmk7jct6v2jk1OKrHwc5Oax8yYuWWRcAkYD5IbUq/uDGx76ifarOoNdx3hX2qFovNkhJ6SREB16Z0kgjfGPf2wd65t8ReVW4ZcGN5lkMgLxnDNMw1YAcHOluvqJwcH5A6jqlObOJcLtb2eeeGW6vmOCjA+XGMDSgBwuNIX947k96DI8DubLGKBbA64rpnZ3Lr6JGY4Glhsp0qgw2NxtmrjrnCDnG74hcRWVvDDAsrhAqjVpz1YhSo0gZJ26A10Nw20EEUcIORGiqD76QBn8qDJpSlApSlApSlApSlApSlApSlBicWkkSGRok8yRVJVNWnURvp1YOM9M4NUle8Z4JdFpLq0eCV86plBYEnrqZfvH6oTVuc0cfazj1RW0t1L2jixt3y7H7o+gJ36VzFzBcObk64hbGWViRqJRA7ZAZSMqFB+M4yBQWl4Y8PTh15qtrpZ7G69D5xqV1yYyWXqckrjC/rNxttc9QbkXw3tOHhJ9XnXGneTpGckMNCAkYGBgnJ71OaBSlKDT83Xc8NpM9sAbjQREDjGojbrtn67ZxXLfHOEz4jaRZZLmQlpdcbmTJ7MTufxGfnFda3tsJUKHbPf2I3B/nUC4vw2+QlFieQdmQjSf5kEfjQabwO4jfLqs7rV5QQtEJP1i4KgjfcKdXQ7gjtVu1EuS+AtbappQTM4xjsq5zjJ6kkDPbYY9zKwT7UH1UK8WYIHsWWS2a4mY6bZEB8zzWBwyldwAASexAwetTStBzjYXs0X/gpY45h/wC4CRpPXRjIDZx1BFBR/L/JHFrSVLxGgtZUGwbSQARpIKqGByCeuD896uvlDmb7WDFJp+0RqC7R/qjvjK5OV+h/ma5u5ra91ut6ZvMQjWsrAAZzjSvQjY7qCDV5+CHDbaHh6PE8bzS+qcoQWByxSOTHQqpxj3LHvQWHSlKBSlKBSlKBSlKBSlKBSlKDSXEmlmz1yaiPNltDcppmjSQdtQBI/unqp+hqc8U4d5oyp0v79j9f61Gn5TuJH/SPGE7hWbJ/HSMfh+VQbfkVStjAmCFRSiZOToQlV6/AA/Ct9WLaW7IoXKhVAAVV2AGwArJFUftKUoFKUoFKUoFfjNgZPQV+1+EZoKh4nyGL66lvb+YuznEcSDCxxgnSmpgcnB3wBuWPfNYy8Kg4a/nWa+VMM+vUxJB6hgxII6bY7D2qacehe3ySCY+zgZH+LHQ/Wova2hvZAoJEefU56Y7hf3m+n41EWrYXHmxRyYxrRWx7agDj86968bdlACqMKAABjsNhXtVUpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k='
        },
        {
            Title: 'Mashable launches shoppable virtual home featuring Walmart products',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR46A_lYw4jyWVAczJykUwFSIvi78aDhzOKgg&usqp=CAU'
        },
        {
            Title: 'Dicks fulfills 70% of orders from stores, cuts delivery estimates 10%',
            Subtitle: 'The retailers cost of goods sold — which includes shipping, freight and distribution, along with the cost of the merchandise — was up nearly 11%.',
            uri: 'https://english.cdn.zeenews.com/sites/default/files/styles/zm_700x400/public/2020/07/25/874639-e-commerce-notfiied.gif'
        },

    ]
    const CategoryData = [
        {

            name: 'ANCHOR',
            uri: 'https://www.picclickimg.com/d/l400/pict/193007507923_/Internally-Threaded-Surgical-Steel-Star-Prism-Dermal-Anchor.jpg'
        },
        {
            name: 'BOLT',
            uri: 'https://upload.wikimedia.org/wikipedia/commons/2/2f/M4_Inbusschraube_focusstacked.jpg'
        },
        {
            name: 'CLUMPS',
            uri: 'https://3.imimg.com/data3/UE/TE/IMFCP-6433059/rail-parts-clips-20-20clumps-250x250.png'
        },
        {
            name: 'HOOK',
            uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBIRERgRERIYERARERIREREREhERERERGBgZGRgUGBgcIS4lHB4rIRgYJjgmLC8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QGBERGDEhGCExNDQxNDQ0NDE0NDQ0MTE0NDE0NDRAMTQ0MTExMTQxMTE0MTExMT80ND80MTQ0PzExNP/AABEIALcBEwMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAAAAQIEAwUGBwj/xAA9EAACAQIDBQYDBgQGAwEAAAABAgADEQQSIQUiMUFRBhNhcYGRB1KxFDJCYqHBI3KC0TNDksLh8FOi8RX/xAAXAQEBAQEAAAAAAAAAAAAAAAAAAQID/8QAHBEBAQEAAwEBAQAAAAAAAAAAAAERAiExUUES/9oADAMBAAIRAxEAPwDoO03aOjs6j3lTed7ilRUgNUYcfJRcXP72E8W2/wBqMXjnJrVCKd92ihK0lHTLzPibmR7WbbbHYt6xP8O5SivJaQO6PXifEmbj4f7AStU+2Yplp4LCspZ6jBEercZUudLAkE+g5zdu3GZMjR7e7P4jAMq4hAveJnRlYMrDS9j1FxcS72S7MNtE1QHNIUaecOUzUy99FY3uLi/C/Cek/EDBYSrRz4irUq1qiv8A/n0aGUksQDuIo3gd3MxJ04W0i7L4bFulCgmEbZ2EpIlTEvotfFVlA3R+JVJAJJ1I0uJP57N6eV7I27i8BUvQqslms1Nrmm1jqGQ6fuPCe09je19LaSEW7vE0wDUpXuCOGdTzW/qOfInhO1XY7HYqtiMfegFzFmpLWBdFRQArG2XNlAJ14zithbUfB4mniU403BK3tnTgynwIuIlwslfS0Jiw1datNKiG6VEWoh6qwBH1mWbYEIRwFHCEIIQhAIQhAIQhAIWhCAoRwgKEcIChHFAIQhKEYpKKBAiIiSIiIhUTIMsyGIwirkhM+WKVXzjsjCU6tULWrLh6QGZ6jXJCjiFUasx5Cejdl9rYfG4pcImEdsDh1H2allVqa1M12xGIubFiL2vfieJM8vr0Wpu1NhZkZkYdGU2I9xPSPhn2oCNR2cKKL3lSq1SvfefdZlFrfe0C3J4AC05T10rt+2eK7qijjFjBKlRc9QUxVqshB3EWxsSR5aRbExAxxpYqnimbD0kBWgBZ2qFWUtiH4Mwud1QADrrpPNviRU7ur9nZg9d3bFYqoNdWJFCgDxypT5fnvO5+HpFHD0qDY+lX7ymXo4emED0777gtfM1rniBbWXe2c6cf8V8XlrrhkpvQpqrVGGYLQrl2zd4qLpfNmux1J/Xzyd/2/wAbs3FNUrU6lYY1Ki08rgmiyqcrBb3yganT21nBKpJsBck2AGpJ6TN9anj6C+H1UvsrDFuIRk9EqOo/QCdJNX2awBw2CoUG+9TpIH/nO836kzaTpGKIQhCCEIQCEIQCEIQCEIQCEIQCEIQCEIQCEIQFCOKARRwlETEZIxGBAxGTkTAjCEIHmXxO7HsWbH4dCwbXEooJII/zQOluPv1nl6OVIZSVZSCCCQQRwIPIz6knF9o/h1hMWxqUicNWa5JRQaTHqU0sfIiYvH43OX14pjcXUr1DUqu1SowUM7HMxygKLnnoBOg+HGI7vatA8ATUVvI02/4m1xXwsx6scj0aq8iKjKSPEMNPcwwnwx2lmBzUqVvx98bgcDbKDykyrscVjaueq7jg9R2HqSZ3nwz7ItXqrja6lcPSYNSVh/jVBwIB/CDrfmRbrOn7P/DHC0GD4pjinGoUrkog+K8W9TbwnfIgAAAsAAAALAAcABLOP1Ly+FHaO0LTTKMJK0LQiMIQgEIQgEZEUcBQjhAI7RgTBicZTp/fqBTxy3u3sNYGa0LTTVe0CE2pi/i+l/IXgm37EZqZYHi1Mi4/pPH0jVxubRWlehtKi/Bsp6OpQ/rpLQsRcG46g3EIhCSIitAUIQgKEISgMiZKKBEyJkjImFRhHCBmhCEiHCKECQmPE4gU0LtwHAdTyEkTNF2lxRXu6a65i7W5HKBb6mFavaW2MRnARrMx3EXRVHU9Zmp9pKlAAVv4rE6AKFYnoLTT4XFo2JcuLZFVRztcD/n3kKuJU1KlUEHJalSHHeNxe3oT6zOtY6/D9psM1hUbunP4H1t6ibpHVhdSGHUEGef7P2eMveMLu+t+dustKHQ3SplP82WXUx21oWnNYfblZNHUOOvP3E2eH27RfRr0z+YXHuI1MbK0LRU6iuLqwYdVIMlaVEYSUVoCkgIgJrts1HKd3T+8wu5vqE6DxP0Bi1Wq232hNzTw5sBo1QcSei/3nOK7E3NySdWJuSZdegPxAofAXX25Su1AggLvZtBbnM6shq/XUcyZz+0Np1GfcYpTGigfeb8xMt7e2ilJMi75JKmx/wARxxA/IOvMzT4BK1d1DgAE62BzZeJ5wNlgEr1UJao6IeBDWzDnxvp4zd4HFdwt6btpYaG5PqePrNRtbHsrdzTChVCgsxtY8bDy0lJ8ethTf5w2ejUViLcRy5E89IHqGxtupXsjmznQHgHI5ef6TbkTzWg6lVZDu6BbXGW3K3Izuti7RFWiGdgHQ5HJIF+jessSr0IJURvusGtxykG0ZlQoo4oBEY4jKFImSMiYEYQhAzQhCQELwhAg01O28Gaiqy6PTbMvQg6Mp8xNvaYay3EiuEKCniSWFlqqFv8AK68vUTUYqnkqMl7fxiw6WYXX953GN2ar8RNFj9j5+N9OB524yYurFKpUpgAbygADyg1FKgJ+6/EqeflFQd0AVrtYWueJ8ZkDKeIga1qTId0kW6GNMUQbOMw9j7zYOgI0N/OUq2GJ5QL2HJsHpOQfAkEHpL9Lbdeno6ioPHj7iafZxWmTnY7w4W0B6zaIVf7rA+HGBtsN2govo90P5hdfcTa0qquLowYdVIM5F8Kp4r7aTD9lZDenUKnlqVMaY7YkAXOgAuT4TisZi6jVjVUka7tuS8pYG0cQVNJ2urrYkgZrc7GVXSLSRZG0FqC1Ub/JwOP801uKff7qkf4jDfccKdM8dfmP0hjT3QAtetU/w6fP+d+ij9ZSqoVXuEN6lQlq1Q9OLEnoP28okW1SehTqPurmWmAgf8Tn5E+UcSTxPtMePrHCvdHyuq8U0Cnmi+HLxl5itFC69e7og8S5/H58z6Tn8fhKjs9TilIqp14DRQfUy6inhsbd2aopqFiTcNlN/UGdfgNgHED7XWp9xROlNL3epbmSbaTD2S2BTFsTiVzg71KkdEIH+a/Vb8F5kdJtO2HaoowSmAXC2RTqtIfMy/MeS8hGGsL7MorUFQnulVRulylPwJFwCZt8OKbLmRlqDqpDKPQaTzCpiHqMzVHLs4OZmNze2n/ySwmMqUSrUzldOJAtnHyv8w85Ux6/scfxP6De3mJujOd7J4xa6iqumambj5WBAK+hvOiMqFFHFICKOKApEwMCZRGEIQrNHFHIhQjigEiwkojCsD07ynVw82JkGWQaOrhZXbDWm8enMD0oGnNAeI8ojQblZh7GbN6UwmnaQat6Y4MLHxErmhrdCQfOb219CLjx1mN8EjcLqfDUe0LrUpi61P8AOPHjLNLadNtHBQ9eUyPgai8AHHhofYypVReDCx6EWMC0uIpkkqQ1iRYm1xysZixmIqIjOgSmFF73NSoegUkBQb2HrNTWwpGqkgytUrMi/wAR9wG9rjeI1tbnrYwLWz6ZuXe7Od5na5JPK5Pv6QpKz1Li+/uj82t/bQe0yYRSUsRbPvW6JyH7+swbaxv2elZRv1AUX8q/iPtp6wKmJr9/ilRLvTw4bIFF+8YalgOdyBbwAlfAYLE4uqlDu2ALBWzUzTUC9yTcXJ4n9Zr8FXNOm9RTlclUQ9CdSfYTsNlJUw+HGYn7Vi7Bs181OibELrwLcT4WEuGrPaDaFPCoRSs2X+Gh5O6i2a3yL/aecVnLnMxLMzMWY6kk2uZs9t45atQhDdE3KY8Bxb1Nz7TWty9T+37QJUUvG9PWOm9o2a8o9L+HOFKYXvD+NmI8ibf7R7zrWM03ZWnkwVIdaak+eUXm1YwiV4ryMIErxRQhAZEyUiYChFCVWeOKORBCEIBEY4oETEZORMKgVmJkmcyJEgqOkwukusswskCqUkbSwyyBECKmQxFSmBZwGvewIBvaZLTT7apF3FjYqunnfrJVihi2JY5BkQnQXuQOl5qMNs4vie8rsDRV701uCHPIH8oPLn7zamrU4kkMDZwSePzDwP1mOqudfEEX+n7iBfxIsbicHt/Hd9WJB3E3F8hxPvedhthjRwpyks+XKp53P9h9J56Ab66yRcb3ZWISiqO6h2QGpTRtVNVjlS45gWJ9Jvto4opTeq7EuKYp5+Zq1PvN5/eM5ulTLV0S2iFb/wBIBP6kzfbcwiPhAWrCm4dqqpkLtVOqqAAbjnrw1mkrjwovprLZwrA5WBVuFjxHhaa9qbqdRw5rqJu9h4ypWdaZ37b2Yi5GQXBv4WHHrGjA+DChgKis6DM9MXzKul9eFxcXErCdH2go00OcKFqMhRioC5g1gAQNL2za+HlOctpEHs3Z974SietJPpLxM0fZHFB8HSW9mVAtjoSBpcdZuoQ7x3kY5RKEjJQImKOKEEIoSjPHFCQEcUIDhFCAGKO8UCJiMlERIIkSDLMlpEwqu6zEyy26zC6QKzShjFBbzA/ebJ0lLGLqD5iTl4s9a+vh76jjy8fA+EwUsKWNhwe6C/FXtwP6Hxl57kacpjp1Sj5gLngQdAw8eh6HlMxar1U70KLE2XMQOIJ0/YypU2LTO8yjTX8OaZcZXbvHelTdUZiwF1NgTfpbiTMZxlQ6NmF9CWQWt6WhVTZuCU0zVtdy9RV8sx/sJre1D5aqJyShTHuWJm62LQZ6S24E1ATci1nIOnOabtkMmJvzNKnlHTiL/pNsfrQ1Htu+refT/vjOk7KYayPWbQscinS2Qan3Nv8ATOYoUmqOEUXZ2CjzOk6zbFYYfDrQTiy5B4IPvN5kn/2MitLtLGGtUZr7t7IOQUaD34zHg8I1eqtJOLE3PRQLs3sJgGgv7TtOw2z8qNiHG9UsqX5Uwbk+rAH+jxmkrpdj4Xu7ACy00CKCLa/9+s2wMrq8yqYRkjiEIVIRyMIBFCKVBCF4QM8IoSBwhCAQvFHAUIGIwpyJjihBIwhCoyLSUiwkGBhKuLS6m3EaiW3mBzBGrv0mMi5/7eW6tLW49pWqaa21mbGpWN+HraRQSTVAfWMleRhVDszVsatE8aWIqf6HOZfrKHbrC3yVhwF6beHNf90NoV/smLXEgE0ayinWtrldfut7fSbLaldMTQKUytTvAoD3BRBcHPfqOQ6y/jOduZ7MYXNUaqRuoMq3+c8T6D6yttXGCrVZ77i7ieKjmPPU+s6LE4B0wppYVMzHdJzKDY/eYkn09ZrcB2VckNiXCL/40OZ28LjQRCq/Z/ZJxb53BFBDZuWd+SL9SeQ6EielYakqKFUWAAAA0E1mEpqgCooRFGVVGgAmxpXlRbQTKJiSZBKjIIRAx3gOEUIDihCUKEIQM8IhHIHFaEIUQiheA4RXhCCKBhIokTGTEYEYjJWitAxMJidJZYTGywKVRJSqLe4M2jpKdWnA1VSkRqDfwPGQJHlL1SnKz05FVMRSSohR1zIwsQef/M56nsWvhqhbD1EqIf8ALqMy++Ui/n+k6J8MOkSYaDUMFia2W1RUQjgKdyLevOXaSk8YqeHl6jRtKidFJeppIUklhRKGokwIgJIQhiMQEYgEIQlBCEZgRhCEDKJKREcinFCOAoWhCAjCOKAQivHAjaFpKEghCO0IEYjJSLSjE4mB0vLDSBEgqNSvMbYW8ulYQNecFGuDtL4WSAjBVTD2mZKUyhZMCUQCSYEdpICEICSAhCAQtHCUKELQgEDAxGAoRQlGWShCRThCEBxQhAIoQkBCEIBCEIBIwhARkWhCBAiRKwhAWWGWEIQwIwIQlVMLJWhCQAELQhKHaOEIChCEAgYoQhXiJhCVUbwhCGX/2Q=='
        },
        {
            name: 'LOCKS',
            uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRYVFhUVGBgZGSQaGhwcGhgZIR4dHh0hHBodIRwdIzAmHh4rHxkaJjgsKy8xNjU1HSU7Rjs0Py40OjEBDAwMBgYGEAYGEDEdFh0xMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMTExMf/AABEIAOEA4QMBIgACEQEDEQH/xAAcAAEBAQEBAQEBAQAAAAAAAAAABwYFBAMBAgj/xABKEAACAQIDBQQGBgYHBgcAAAABAgADEQQSIQUGMUFRByJhcRMygZGhsRQkQlJiwSMzU3KS8DRzgqLC0eEWF0NUsvEVY2STlNLi/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/ALNERAREQEREBE81TGU1NmqID0LKPmZ9aVVWF1YMOoIPygfSIiAiIgIiICIiAiIgIiICJ86lRVF2YAdSQPnPlTxtNjZaiE9Ayn5GB6YiICIiAiIgIiICIiAiJxt5dsrhaDVDYse6g6sRfXwABJ8vGB/G8G8lHCr3jdyO6g4+ZOth7CTyBk12/vJiqmtSoaKH1VXukg8DlBub+JN+k/GD3FV7viq2tMMM+TN6rZOBc37o4KLGxuBNbu9uGiWq4omrVOpBYkA+J+0evLz4wJW12N1R2HUkrfxtpPfsilVzgUGq06h4ZGIJ8LHj5a3l3w2Ep0xZERB0VQvynxxuy6NUd+mpPJrWYeIYaiBhNib81qZ9HjFzAGxdVyuv79PmPEW8jKFhsQlRQ6MGVhcEG4ImO3t2YBTDPmYrYLW52Jtlqjnpwb5c89urtxsJWCObUXfK68qdQ6Bx0U8/9BArMREBERAREQERED44iuqKXdgqqLkk2AEwG2t9alTMuEGVR61Rha3IG7aLfpqf3TPLvNtQ4ys1JWKYajq7DmQbXHVidFHt8vLsjd18aw/4WFTQKvBjz14u/IudPC2kDJ4/GvUY53qVn56sQPaf8xPMKR4mm6+OY/5mXfZu7uGoACnRS4+0QGb3nh7LTpVKKsLMqkdCAR7jAkOzNtY7CKjB2qUW9VaveU+CuNVPhfTmJRN3t5qWKFhdKoF2ptxHiD9pfEfCfSrsVFDeiRcrevROiN4gfYbTQjT5iZ7ToeirFqJdCj2Qto6MLd1uoN/L43CzxOJuttoYqgHIy1FOSovRhx9h4/8AaduAiIgIiICIiAk13trDEbSpYdtadFM7jroaj+9FAlKkjxTFcdj6jgoDTqKjMCAxVQndJ48bQNJuLszOz46p3ndmCdFUGxI8SbjwF+s3E426aZcHhx1QH+K7fnOzAREQPjXpK6lWAKsLEHgQeMjuP2UUxr4MnSp3UJ6Pqh8w2X3GWiTHfkhdqYV+SohY9P0tx8oGy3QxrVsHRdvWC5W/eQlDfx7s7kzG41QGjWy+qMTUC8tCQw0/tTTwEREBERAThb5bSOHwdaovrZcq/vMco917+yd2YntSRmwqKis16ykhQToAxJNuUDLbM2Sai4XDXK+mJrVSOOUXC/3VNv3z1lYw2HWmqoihVUWUDkBMNuiyNjEykHJgk4cmyoGHnqZQICIiAmD7Stlj0QxKjvIQr25qdFJ8QbD2+E3k4m+Kg4HEg/smt527vxtAx24WIK4hD9nFUmv+/RNr+eQ3/tSmSS7oVgDgFJ76V6gI8HpIOPDjK1AREQEREBERASI70WGIxJ0Fy55cS4vzb8pbpDd5quatXuSbBhrc/bHXl5H3cIFd3cFsLQBuP0a8QRy6ED5Tqzm7AW2GoC1v0a6Wt9kcsq29wnSgIiICSftCP15NfsJxPDv+enw/OViSTtKe2Op9BTTifxk9Rb2EQNN2YN9WqjT9cx5cwPAdJtZiOy8/V6uvCs2mmmg/EfkPbNvAREQEREBMV2lAegTQaMT7lP4h16GbWYftLq2ooNdc3XoONvPn8IHI7M1+s1j0pKL2/d8NOHhw58qfJl2Zr9YxJtwRRwHhzy6cPvDya1xTYCIiAme33/oNfW3dHO3MacR7vgZoZwd9v6DiP3PHqOkCYbsP9ZwvD9e3Tmq24jSW2QvdWr9ZwuoH6fqBxVR94fyefCXSAiIgIiICInh2xgjWoVaQbKXUrfz/AJtA9LVFAN2HvE/z9iKud8S17gk9BoXFuQ04cvdNDtvYf0VlDse9e12DX8bhPynFq1XCtkTOqLnbvLoo0JsU/EOcC47JW1GkNPUXgAB6o4AAW9wnukF2JiMRWYpRVywUkqmpC3sTbQW7w94nbXA7R/Z4gf2X/IwK/Ekv0faP3cQNLaCoPlzn6E2iP+aH/wAgfLhArMkPagtsdSbrTU8xwduenz90+z1NoICzNiABqSWraAc9eAsJyGFXEvmWm+JqAWvZiygcDmZuAJ435wNt2WkfR6wvwrHS/DQW0zG19eQ9s3Mjy47G4PVsPXoo73PEoWOpuVYhSbeF/ZNfuhtDF161SpUDDDst6YI0BJFgrEAsLX11EDZREQERED+SwHEgSZ9rmIH1dQwv3iRpw0trbz5zo727qtUq1MSGYrlBIzABQi2N1I7w0J485gGdV1Q5iPxW/wAH+fnA2vZmn6fFHTTKOV/fbhp198o8/wA8VNoVEfKyZDlBuCPVdQ66qBxVlM0lLBbQKqwp1yCAQQCdOI4HhrAscSRrhdoi/cxGv4X/ACn9ei2j93EjyFYcPKBWpwN9FvgcSP8AyyevAg8gen+o4zDr/wCJdcUNebYgfOeHaOPxABo13qnPa6MajXBta4Y8NL3txgcvdJ/rGFubfp+tuIX8Q/1/Fwl5kXwuy8YuV0wNUZWDoV7pBta4GcNqLT34bebHVV9FTFUVQ9zdWzgCylSrAhRe+p4QKzE+VDNlXN62UZvO2vxn1gIiICIiBgu0LALUamXNX1SEFKn6ViwOt0uNLEcDxmDTCuPTKjotkAdax9E7AsDlVNbtdRpfnLZj9nUqwAqKGtw1II62KkEThV9w8CxuUqDr+lqm/PXMxvAyfZRgT9Iq1R6q08h15s4I0/sNKtObsnY1HDBhRXLmN21JJtw1J8T750oCIiBwN9aLPgqyoCWspsOgdS390GYPdPErgWNaqVK1FK5UZXdbEHOVBvl0I6yrVUDAqb2IINtOOkxeN7PldQq4hkW9zalSzHpdwAx9pgfDfHeJaiLh1o1szlWBZMunEWBNzfhw6zbbOplaVNSLFUVSOhCgETMYHcGgjq7Vqz5SGAYqBcW5gXtp1mxgIiICIiB4troWoVlBAJpsNfFTIttLAImZk+k5b2zVKORLnkKmazewS6EX0OonBxm6ODqXzU216VKqj2KGtf2QI9tXAO1UIzUnchUDU3zqcqKijNbjYAecvOCplaaKdSqqp8wADOFgtysFTYOtNiykEFndtRw4nX2zSwEREBJBvVsepUxtYMyorNmDu6ooXKNSSeGhHslfnB23u6uIdahbKyrl1SnUHMg5XBFwTA5+B30otSZhSrsaajOFQMByvmBy5SQbG88+4dU1amKxAQqtRtL24lmYjTnYqT5ieej2cIMxbFViWIPdVEFxflYg8fZNVsPY9PC0/R08xBOYljckkAeQFlGggdSIiAiIgIiICIiAiIgIiICfk/YgIiICIiAiIgIiICIiAiIgJ+T9iAiIgIiICIiAiIgIiICcvam3cPh/1tVVP3Rq38I1mW3h3tdnbD4OxIBL1LgAAesQx0VRzb3W4zAVKZqtlohsTUY3LBTkJ8BqW15nWBQ63aXhQbLTrMOoCj/FPTgO0PBVCFZnpE/tFsP4gSB7bTGYfcHHOMzMqeBIHyJPvn9HczEUiPTKWp8GZAHy/iKccvXhArdGqrqGVgynUFSCCPAjjPtJBSpYnZ7K1J1yPqtiWpOOhB9VvcfnKJu3t9MUhIGR19dDxU9R1U9YHbiIgIiICIiAiIgIn4TMZt7fhaZyYdRVc8DxX2AasPG4HQmBtIkN2rvVi2Jz4lk/Chy/BbfnOfQ21iAbricSpH4m+V9YH+gokq2RvziqRVcQgroftAZHt1twb4X6yibH2vRxKZ6ThhzHBlPRhyMDoxEQEREBERAREQEyG/22GpU1oU7+krHLpxy8DbxJIX2ma+S7a+I9Jtaox1XDU7r5qhcH+MiB4sJstqj/AEKlYka4h7d24436qvBV5nXmMtL2PsalhkCUlA6nmx6k/lwnK3CwKphg9u9VYux52BKqL9AB8TNRAREQM7vHspmpP6EAg956fJrakr91vLj5yZ4DaDYesK9Mkmme8Dpmp3synxH88BLdJNt/ArS2qiW7lcq1vBzkce8n3wKnh6yuqupurAMp6gi4n2mc3EY/Q0RjdqTNSP8AYYgfC00cBERAREQEROTvNtL6Nha1bmqd3946L8SIGS3v249eo2DoMFRb+lflZfXufuLwPU6eef2fsiriHNHDA06Qt6So3rserNy8EF7c7nUNn4Go9OhRQ2qYpy7t0RSQPG11dj1uDxAlV2Vs9MPTWkgsqjjzJ5k9SYHA2VuFg6QBZTUbmzEjXyH5kzq1d28IwynD07eAsfeNZ2IgZbE7uU1T0eU1KOtlNi9O/Om3Ej8PPx4HBuz4WvnoPmINlcAgONCUdeuo/m1rLJ12jbKyAYlBZS1qgH3j6r+BPA+yBsthbVTE0VrJpfRhzVh6yny+Vp05N+z7FFK5T7GIp+lXp6RGy1LefH3SkQEREBERAREQEjm1a4o4vHOczGotRLEBQtyFBBucw9gljkS3q0xFc9Q3h9sfhW/x+GgVfddbYTD/ANWvxF51pzN3VAw1AC36teFunhpOnAREQEl2/wDWA2hh3500TyN6l+ZHwlRkn7RNMdT5XRCLc+/5Dp1b2cg1fZ9ic9Cu2muJc2FtM2U9TbUma2YnsxN8PV1/4zcyeQ6sfy9s20BERAREQEw/atVIwar9+sgPlqfyE3Ex3aMzCguUsO8ScpYaZSLGwOmvhA8O61IHGUh9zBIw8Cypf/rPvm/kx7NNcTVPSio9+W/X7vWU6AiIgJwt9KQbA4kH9kxHmveHxAndmf31v9BxFr+p0vpmF+R5f9xxgYjc6sL7PNxmFaqhFxfK1JOXG2aVeRPdisfpOFuT/SG0v1VRzf8Am3PhLZAREQEREBETy7Qxi0ab1XvlRSxtqbDpA9Ug23K4aribWsLjSw+2umgFz7+EpA7QsIQbLVPsS3vzSWtSZvTP3b1DcC45tm5+APWBcthn6vR/q153+yOYZvmZ0Zk9mb3YUU0QuwKoAbq59UWOt2vw+8fMz2De7Cffb+B/PpA0ETh/7VYT9qeF/UqcOH3Z+/7U4S9vS/3Kn/1gduSHtKa2Pp/1af8AWfD/ADlGG8mF/bL7Qw+Yk27Qqi18XTeld1WmAzAEjRmOunLygansu/o9Xj+uPXoJuJgOzvFJSp1UqFUY1iVDaE3AGl1F9ehPkNL7WjjKbsyLURmX1lDKSvmAbj2wPVERAREQExHaW9qKg2+1yB1t4qbceom3k37W65C0FBHezac+UD59mR+sYnX7Cc/L8X5HzHA0yTfsx/X4ryXn+Wb45T5jgaRAREQEz++4+o4jS/c6X5jXgffy6jiNBODvst8Dif6u/uIMCV7qOfpOF4/rz1+6suUhG6FziMJx/X9L/ZX8J/npxl3gIiICIiAnxxFBXVkYAqwsR4T7RAlm/WETDNTCAsXBvmN7a2AFraTIvT9ItQ52QomdQttTmVQNb6d6VPfTBs2V0po3dKsWonEAC91sigm9yTcSb16KKzipRrMSo9GyU3oC97ElGUXHgenEQPzcrZJxdZqLVChWmamYjNwZVta4H2vhNsOzf/1I/wDb/wD3Pn2YbJZGq1mVlOUIpIIBBOZuPG2VPfKLAn3+7s/8wD/YYf44/wB3h/bL/Cw/xSgxAme2Nzxh6L1mqAhBwAfUkgAcepE4e7OyzjqjotQUsi5iVRmJFwLd57X9nKVHebAenw1Wne11zX8VIYe/LaTGhjzg0WrQVkckqzO9Jw66HIKanMBcA30PjA9+8O6FbDIKyYrOoYBlamAdeBDBvAcpp9ztgPSJxNR8z1UGg4ANZtTzOg4TI7T3gq4tqdEVwyMy5gtEpZjpwJLMATxuL9JV8NTCoqDUKoW/kLflA+0REBERAwe9eFx3pnenVqrSygqELWACjNmKsMuoJvb2zDbQrs5Vqr+lKiwzEuRrwsWJln2wpNCsFFyabgeZUyIYvBqjMq16FQj7KFywvqAQVFj7YH7gd4nou/ozUps1s3rDNzUkNodCLHofGdsb3YznUccOS/mszm2sJVNXK9N0qZETI1iTkRUB0NjcKD7Zetn0ytKmrCxVFBHQhQCIEuTfDGa/pT4aU9Pek/v/AGwxv7Q/w0fb9iVbKOgn8+iX7o9wgTFN78b96+vSn+SzzbS3oxFSm9KqyBHGU6ohINtAff7DKr9HX7q/wiSHejB4irjqqUlcsGsgVbWAAI1FgBre8DkYGvSpFHVX7jhwxTOLga3JSxGgI6fGa5e0Ko1INTFN3L/dYqVsOABBvfx9nXWYfenBimpNdFIUAqbhgQNRkte48pxdyRSq4nFV0UFS10YrawZ2bS40JsD1gbbDuWVSRYlQSOhI1E+sRAREQEREBERAREQEREBOZV2FhWN2w2HY+NJDx48ROnPyB5qODpqbrTRTa11VQbchoOFp6oiAiIgIiIH8VFBBU8CLHyOhmU2luOlVSn0isqcQuWiQD1vkDH+Ka6IGHwPZ8iOrviKlQqwbgF1GvjxsJuIiAiIgJlt493nr1FqIU0XKys1Wne1yDmp2Y8beQ5zUxAmeD3GxyCooxFGmr2uqZ3DAXsDmUGwv43vNjuvsT6JRNPPnJcsTa1tAth4WWduICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgf/9k='
        },
        {
            name: 'FOUNDATION BOLT',
            uri: 'https://s.alicdn.com/@sc01/kf/Hac638f45994c4c0688f6413e418b44ce2.jpg'
        },
        {
            name: 'MACHINE SCREW',
            uri: 'https://image.made-in-china.com/43f34j00qQRUcYidsDbH/Spare-Parts-M3-Pan-Head-Machine-Screw-with-Spring-Cross-Drive-for-Radiator-Accessories.jpg'
        },
        {
            name: 'HEX NUTS',
            uri: 'https://image.made-in-china.com/2f0j00PEtGTdSCYbgn/Tool-Auto-Parts-High-Quality-Fastener-Spare-Parts-Hex-Head-Nut.jpg'
        },
        {
            name: 'SHEET METAL SCREW ',
            uri: 'https://uk.rs-online.com/euro/img/solutions/scretform.jpg'
        },
    ]

    const renderItem = ({ item, i }) => (
        <View style={{ margin: 5, flex: 1,borderWidth:1,borderColor:'#2088dd',borderRadius:10,paddingTop:10 }} >
            <Avatar
                size='large'
                //onPress={() => navigation.navigate('ProductByCategory')}
                source={{ uri: item.uri }}
                containerStyle={{ alignSelf: 'center' }}
                rounded={false}
            />
            <Title style={{ color: '#2088dd', fontSize: 10, textAlign: 'center' ,paddingHorizontal:5}}>{item.name}</Title>
        </View>
    );
    // const toggleDrawer = () => {
    //     //Props to open/close the drawer
    //     navigation.toggleDrawer();
    //   };
    useEffect(() => {

        SetLoading(true);
        const unsubscribe = navigation.addListener('focus', () => {

            // Alert.alert('Refreshed');
            var url = BASE_URL + "ApiCommon/GetWhatsNewList";
            var Count_url = BASE_URL + "ApiCommon/TotalItemsCount";
            axios.get(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
            axios.get(
                Count_url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setDataCount(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
        });
        return unsubscribe;

    }, [navigation])
    const ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem containerStyle={{ borderRadius: 10, paddingVertical: 5, marginVertical: 5 }} underlayColor='white' bottomDivider key={index}>
                <Avatar size={50} source={{ uri: item.uri }} />
                <ListItem.Content Style={{ padding: 0 }}>
                    {/* <ListItem.Title>{item.UserName}</ListItem.Title> */}
                    <ListItem.Title style={{ fontSize: 12 }}>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle style={{ fontSize: 10 }}>{item.Subtitle}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>

        );
    };
    let upload = async () => {
        //Check if any file is selected or not
        if (Remarks.trim() == '')
            Alert.alert('', " Remarks can not be empty.")

        else {
            //If file selected then create FormData
            // const fileToUpload = singleFile;
            // const UsersId = global.LoginDetail.Users_ID;
            SetLoading(true);
            const formData = new FormData();

            formData.append('ParentId', 0);
            formData.append('Comments', Remarks);

            if (global.LoginDetail == null || global.LoginDetail == undefined) {
                formData.append('UserId', 7867);
            } else {
                formData.append('PostedByUserId', global.LoginDetail.Users_ID);
            }

            //debugger
            axios({
                url: BASE_URL + 'ApiCommon/AddWhatsNew',
                method: 'POST',
                data: formData,
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'multipart/form-data'
                },
            })
                .then(function (response) {
                    Alert.alert("", "Remarks added successfully");
                    SetRemarks('');
                    SetLoading(false);

                })
                .catch(function (response) {
                    Alert.alert("Error", "Upload failed");
                    SetLoading(false);
                });


        }
        // else{
        // alert("Please Select file.");
        // }
    };
    const onShare = async () => {
        try {
            const result = await Share.share({
                message: null
                ,
            });
            if (result.action === Share.sharedAction) {
                if (result.activityType) {
                    // shared with activity type of result.activityType
                } else {
                    // shared
                }
            } else if (result.action === Share.dismissedAction) {
                // dismissed error.message
            }
        } catch (error) {
            Alert.alert('', 'Coming Soon');
        }
    };
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='#2088dd' animating={isLoading} />
            <ScrollView style={{ padding: 5 }}>
                {/* <Text style={{ textAlign: 'center', color: 'grey', fontSize: 10, paddingVertical: 10, fontWeight: 'bold' }} onPress={() => Linking.openURL('https://www.youtube.com/channel/UCVznarIGi1laaY46zTUy-1w')}>It's the only place that keeps you fresh and motivated.</Text> */}
                <View>
                    <SliderBox
                        ImageComponent={FastImage}
                        images={images}
                        sliderBoxHeight={180}
                        //onCurrentImagePressed={index => console.warn(`image ${index} pressed`)}
                        dotColor="#2088dd"
                        inactiveDotColor="#90A4AE"
                        paginationBoxVerticalPadding={20}
                        autoplay
                        circleLoop
                        resizeMethod={'resize'}
                        resizeMode={'cover'}
                        paginationBoxStyle={{
                            position: "absolute",
                            bottom: 0,
                            padding: 0,
                            alignItems: "center",
                            alignSelf: "center",
                            justifyContent: "center",
                            paddingVertical: 10
                        }}
                        dotStyle={{
                            width: 10,
                            height: 10,
                            borderRadius: 5,
                            marginHorizontal: 0,
                            padding: 0,
                            margin: 0,
                            backgroundColor: "rgba(128, 128, 128, 0.92)"
                        }}
                        ImageComponentStyle={{ borderRadius: 0, width: '97%', marginTop: 0 }}
                        imageLoadingColor="#2196F3"
                    />
                </View>
                <View>
                    <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.HeadingsTitle}>Browse Categories</Text>

                        </View>
                    </ImageBackground>

                </View>
                <View style={{ padding: 5, borderRadius: 0 }}>
                    <FlatList
                        data={CategoryData}
                        renderItem={renderItem}
                        keyExtractor={(item, index) => index.toString()}
                        numColumns={3}
                    />
                </View>
                <View>
                    <ImageBackground source={image2} style={styles.HeadingBackgroundImage}>
                        <View>
                            <Text style={styles.HeadingsTitle}>Popular Products</Text>
                        </View>
                    </ImageBackground>
                </View>
                <View style={{ flexDirection: 'row', padding: 5 }}>
                    <View style={{ flex: 1 }}>
                        <Card onPress={() => navigation.navigate('ProductDetails')}>
                            <Image source={{ uri: "https://sc04.alicdn.com/kf/HTB1SB2FaovrK1RjSspcq6zzSXXaC.jpg" }}
                                style={styles.ProductCardsImage} resizeMode='cover'
                            />
                            <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                                <Text style={styles.ProductCardsTitle}>High Strength Hex Bolt With Nut And Washer.</Text>
                                {/* <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text> */}
                            </View>
                        </Card>

                    </View>
                    <View style={{ flex: 1, }}>
                        <Card onPress={() => navigation.navigate('ProductDetails')}>
                            <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnahFmghWa_jPyXBCUGWrpNA9zc4lXiQZ6UQ&usqp=CAU" }}
                                style={styles.ProductCardsImage} resizeMode='cover' />
                            <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                                <Text style={styles.ProductCardsTitle}>EYE BOLTS/EYE NUTS | FB&middot;B | Products | TAKIGEN  </Text>
                                {/* <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text> */}
                            </View>
                        </Card>
                    </View>

                </View>
                <View style={{ flexDirection: 'row', padding: 5 }}>
                    <View style={{ flex: 1, }}>
                        <Card onPress={() => navigation.navigate('ProductDetails')}>
                            <Image source={{ uri: "https://previews.123rf.com/images/slawa2020/slawa20202003/slawa2020200300036/141376616-a-group-of-large-metal-products-bolts-nuts-washers-is-shot-close-up-shiny-chrome-parts.jpg" }}
                                style={styles.ProductCardsImage} resizeMode='cover'
                            />
                            <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                                <Text style={styles.ProductCardsTitle}>A group of large metal products, bolts, nuts</Text>
                                {/* <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text> */}
                            </View>
                        </Card>

                    </View>
                    <View style={{ flex: 1, }}>
                        <Card onPress={() => navigation.navigate('ProductDetails')}>
                            <Image source={{ uri: "https://3.imimg.com/data3/WL/MM/MY-7941424/1-500x500.jpg" }}
                                style={styles.ProductCardsImage} resizeMode='cover' />
                            <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                                <Text style={styles.ProductCardsTitle}>Hex Nut & Bolt, Hexagonal Nut, Hex Jam Nut</Text>
                                {/* <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text> */}
                            </View>
                        </Card>
                    </View>

                </View>

                {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
                <View >



                    {/* <Text style={{ textAlign: 'center', color: 'blue', fontSize: 12 ,fontWeight:'bold'}} onPress={() => Linking.openURL('http://fun2fresh.com/Map/Index#')}>Fun2Fresh.com</Text> */}
                    {/* <Text style={{ textAlign: 'center', color: 'grey', fontSize: 10, paddingBottom: 20 }}>Last updated on  March 10 2021 - 7:00 PM</Text> */}
                </View>
            </ScrollView>


        </SafeAreaView>
    );
}

export default Home;
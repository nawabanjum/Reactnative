// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput, Share,TouchableOpacity, ActivityIndicator, ImageBackground } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, Avatar, Accessory, CheckBox } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import styles from '../Common/CommonStyles';
import DocumentPicker from 'react-native-document-picker';
import { bannerAdUnitId } from '../Common/IDs';
import Clipboard from '@react-native-community/clipboard';
import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function UpdateProfile({ route }) {
    const [email, Setemail] = useState('');
    const [UserName, SetUserName] = useState('');
    const [FirstName, SetFirstName] = useState('');
    const [LastName, SetLastName] = useState('');
    const [FatherName, SetFatherName] = useState('');
    const [Dasignation, SetDasignation] = useState('');
    let [singleFile, setSingleFile] = useState(null);
    const [fileToUpload, setFiletoUpload] = useState();
    const [password, Setpassword] = useState('');
    const [Phone, SetPhone] = useState('');
    const [About, SetAbout] = useState('');
    const [Data, SetData] = useState([]);
    const [ReferralId, SetReferralId] = useState('');
    const [Address, SetAddress] = useState('');
    const [City, SetCity] = useState('');
    const [Country, SetCountry] = useState('');
    const [Id, SetId] = useState();
    const [isLoading, SetLoading] = useState(false);
    const [Checked, setChecked] = useState(false);
    const [SelectedPreference, SetSelectedPreference] = useState();
    ////////////////////date

    const [date, setDate] = useState(new Date());
    const [dateIn, setdateIn] = useState(new Date());
    const [dateOut, setDateOut] = useState(new Date());
    const [showDate, setshowDate] = useState(false);
    const [showIn, setshowIn] = useState(false);
    const [showOut, setshowOut] = useState(false);


    const navigation = useNavigation();
    let Users_ID = '';
    //const { Id } = route.params;
    const image = { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo65zKZfMGxojTmtba2hplTbP5EQuFmCaOzQ&usqp=CAU" };


    useEffect(() => {

        SetLoading(true);
        const unsubscribe = navigation.addListener('focus', () => {
            // Alert.alert('Refreshed');
            AsyncStorage.getItem('Logged_UserId').then(
                (value) => {
                    // AsyncStorage returns a promise
                    // Adding a callback to get the value
                    // console.log('GetId:' + value)
                    // Setting the value in Text
                    axios.post(
                        BASE_URL + "ApiCommon/GetUserById?Id=" + value
                    )
                        .then(response => {
                            SetLoading(false);
                            if (response.data == null) {
                                Alert.alert("No Record Found ")
                            }
                            else {
                                SetLoading(false);
                                SetData(response.data.Data)
                                //console.log(response.data.Data);


                            }
                        }).catch((error) => {
                            SetLoading(false);
                            Alert.alert("Internal Server Error", error.message)
                        })
                }

            );

        });
        return unsubscribe;

    }, [navigation])

    ////////////////////////////////////DAte piker


    const onChangeDate = (event, selectedValue) => {
        const currentDate = selectedValue || new Date();
        setshowDate(Platform.OS === 'ios');

        setDate(currentDate);

        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const onChangeIn = (event, selectedValue) => {
        const selectedTime = selectedValue || new Date();
        setshowIn(Platform.OS === 'ios');
        setdateIn(selectedTime);
        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const onChangeOut = (event, selectedValue) => {
        const selectedTime = selectedValue || new Date();
        setshowOut(Platform.OS === 'ios');
        setDateOut(selectedTime)
        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const showDatepicker = () => {
        setshowDate(true)
        setshowOut(false)
        setshowIn(false)
    };
    const showTimepickerIn = () => {
        setshowIn(true)
        setshowDate(false)
        setshowOut(false)
    };
    const showTimepickerOut = () => {
        setshowOut(true)
        setshowDate(false)
        setshowIn(false)
    };


    function FormatTime(time) {
        // Alert.alert(time.getHours()+":"+time.getMinutes());
        return time.getHours() + ":" + time.getMinutes();
    }
    const formatDate = (date) => {
        return ` ${date.getDate()}/${date.getMonth() +
            1}/${date.getFullYear()} `;
    };
    const InTimeFormat = (time) => {
        return ` ${time.getHours()}:${time.getMinutes()}`;
    };
    const OutTimeFormat = (time) => {
        return ` ${time.getHours()}:${time.getMinutes()}`;
    };


    //////////////////

    const onShare = async () => {
        try {
            const result = await Share.share({
                message: `${Data.Users_ID}`
                ,
            });
            if (result.action === Share.sharedAction) {
                if (result.activityType) {
                    // shared with activity type of result.activityType
                } else {
                    // shared
                }
            } else if (result.action === Share.dismissedAction) {
                // dismissed
            }
        } catch (error) {
            Alert.alert('', error.message);
        }
    };
    const copyToClipboard = (text) => {
        Clipboard.setString(text);
        Alert.alert("", "Referral Id copied to Clipboard");
    }
    ///////////////
    let upload = async () => {
        //Check if any file is selected or not
        // if (email.trim() == '' || password == null)
        //     alert(" Email and password can not be empty.")

        // else {
        //If file selected then create FormData
        if (singleFile == undefined || singleFile == null) {
            setFiletoUpload(Data.ProfilePhoto);
        } else {
            setFiletoUpload(singleFile);


        }
        // const formData = new FormData();

        // formData.append('Users_ID', global.LoginDetail.Users_ID);
        // formData.append('FirstName', FirstName == null || FirstName.length <= 0 ? global.LoginDetail.FirstName : FirstName);
        // formData.append('LastName', LastName == null || LastName.length <= 0 ? global.LoginDetail.LastName : LastName);
        // formData.append('FatherName', FatherName == null || FatherName.length <= 0 ? global.LoginDetail.FatherName : FatherName);
        // formData.append('Email', email == null || email.length <= 0 ? global.LoginDetail.Email : email);
        // formData.append('Password', password == null || password.length <= 0 ? global.LoginDetail.Password : password);
        // formData.append('MobileNumber', Phone == null || Phone.length <= 0 ? global.LoginDetail.MobileNumber : Phone);
        // formData.append('AboutMySelf', About == null || About.length <= 0 ? global.LoginDetail.AboutMySelf : About);

        // formData.append('ProfilePhoto', fileToUpload);
        // formData.append('UserName', UserName);

        // formData.append('CreatedBy', global.LoginDetail.Users_ID);
        // formData.append('ModifiedBy', global.LoginDetail.Users_ID);

        const Model = {
            Users_ID: global.LoginDetail.Users_ID,
            FirstName: FirstName == null || FirstName.length <= 0 ? Data.FirstName : FirstName,
            LastName: LastName == null || LastName.length <= 0 ? Data.LastName : LastName,
            FatherName: FatherName == null || FatherName.length <= 0 ? Data.FatherName : FatherName,
            Email: email == null || email.length <= 0 ? Data.Email : email,
            Password: password == null || password.length <= 0 ? Data.Password : password,
            MobileNumber: Phone == null || Phone.length <= 0 ? Data.MobileNumber : Phone,
            AboutMySelf: About == '' || About == null || About.length <= 0 ? Data.AboutMySelf : About,
            ProfilePhoto: singleFile == undefined || singleFile == null || singleFile.length <= 0 ? Data.ProfilePhoto : singleFile,
            UserName: UserName,
            CreatedBy: Data.Users_ID,
            ModifiedBy: Data.Users_ID,
            Address: Address == null || Address.length <= 0 ? Data.Address : Address,
            City: City == null || City.length <= 0 ? Data.City : City,
            Country: Country == null || Country.length <= 0 ? Data.Country : Country,
            ReferralId: ReferralId == null || ReferralId.length <= 0 ? Data.ReferralId : ReferralId,
            Designation: Dasignation == null || Dasignation.length <= 0 ? Data.Designation : Dasignation,

        }
        //console.log('Sending data : ' + JSON.stringify(Model));
        // debugger
        // axios({
        //     url: BASE_URL + 'ApiCommon/UpdateProfile',
        //     method: 'POST',
        //     model: Model,
        //     headers: {
        //         Accept: 'application/json',
        //         'Content-Type': 'multipart/form-data'
        //     },
        // })
        axios.post(BASE_URL + 'ApiCommon/UpdateProfile', { model: Model })
            .then(function (response) {
                Alert.alert("", "Your  profile has been updated successfully.",);
                navigation.goBack();

            })
            .catch(function (response) {
                Alert.alert("Error", "Update failed");
                // console.log(response);
            });


        // }
        // else{
        // alert("Please Select file.");
        // }
    };

    let selectFile = async () => {
        //Opening Document Picker to select one file
        try {
            const res = await DocumentPicker.pick({
                //Provide which type of file you want user to pick
                type: [DocumentPicker.types.images],
                //There can me more options as well
                // DocumentPicker.types.allFiles
                // DocumentPicker.types.images
                // DocumentPicker.types.plainText
                // DocumentPicker.types.audio
                // DocumentPicker.types.pdf
            });
            //Printing the log realted to the file
            //console.log('res : ' + JSON.stringify(res));
            //Setting the state to show single file attributes
            setSingleFile(res);
        } catch (err) {
            setSingleFile(null);
            //Handling any exception (If any)
            if (DocumentPicker.isCancel(err)) {
                //If user canceled the document selection
                Alert.alert("Canceled", "You have not selected any file");
            } else {
                //For Unknown Error
                alert('Unknown Error: ' + JSON.stringify(err));
                throw err;
            }
        }
    };
    function logout() {
        (async () => {


            try {

                //    await AsyncStorage.removeItem('userName') 
                //    await AsyncStorage.getremoveItemItem('Password')    
                await AsyncStorage.removeItem('Email')
                await AsyncStorage.removeItem('Password')
                //await AsyncStorage.removeItem('Users_ID')
            } catch (error) {
                // Error retrieving data
                //console.log(error.message);
            }

        })();
        global.LoginDetail = null;
        navigation.navigate('Login');
    };

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <ScrollView style={{ padding: 15 }}>
                {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
                <View>
                    <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                        <View style={{ flexDirection: 'row' }}>
                            <Text style={styles.HeadingsTitle}>Contact  Details</Text>

                        </View>
                    </ImageBackground>

                </View>
                <View style={{ marginTop: 10 }}>
                    {singleFile == undefined || singleFile == null ?
                        <Avatar
                            rounded
                            size="large"
                            containerStyle={{ alignSelf: 'center' }}
                            source={{ uri: 'http://' + Data.ProfilePhoto }}
                            activeOpacity={0.7}
                            onPress={() => selectFile()}
                        ></Avatar>
                        :
                        <Avatar
                            rounded
                            size="large"
                            containerStyle={{ alignSelf: 'center' }}
                            source={{ uri: singleFile.uri }}
                            onPress={() => selectFile()}
                        ></Avatar>
                    }
                    <Text style={{ textAlign: 'center', color: '#2088dd', fontWeight: 'bold' }} onPress={() => selectFile()}>Change</Text>
                    {/* <Image onPress={() => selectFile()} style={{ height: 25, width: 100, alignSelf: 'center' }} source={require('../Icons/logo.png')}></Image> */}

                    {/* <TextInput
                        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginVertical: 15, paddingLeft: 15 }}
                        onChangeText={(text) => SetUserName(text)}
                        placeholder='User Name'

                    // value={Data.UserName}
                    >{Data.UserName}</TextInput> */}
                    {/* <Text style={{ margin: 10 }}>Referral id shared by your friend</Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => SetReferralId(text.replace(/[^0-9]/g, ''))}
                        numeric
                        keyboardType='numeric'
                        placeholder='Referral Id'
                        editable={Data.ReferralId == 0 ? true : false}

                    // value={Data.MobileNumber}
                    >{Data.ReferralId}</TextInput> */}
                    <View style={{ flexDirection: 'row' }}>

                        <View style={{ flex: 1 }}>

                            <Text style={styles.labelStyle}>First Name </Text>
                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetFirstName(text)}
                                placeholder='First Name'

                            // value={Data.FirstName}
                            >{Data.FirstName}</TextInput>
                        </View>
                        <View style={{ flex: 1, paddingLeft: 5 }}>
                            <Text style={styles.labelStyle}>Last Name </Text>

                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetLastName(text)}
                                placeholder='Last Name'

                            //value={Data.LastName}
                            >{Data.LastName}</TextInput>

                        </View>
                    </View>
                    <Text style={styles.labelStyle}>Email </Text>

                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text)}
                        placeholder='Email'

                    //value={Data.Email}
                    >{Data.Email}</TextInput>
                    <View style={{ flexDirection: 'row' }}>

                        <View style={{ flex: 1 }}>

                            <Text style={styles.labelStyle}>Phone No. </Text>
                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetPhone(text)}
                                placeholder='Phone No.'

                            // value={Data.FirstName}
                            >{Data.MobileNumber}</TextInput>
                        </View>
                        <View style={{ flex: 1, paddingLeft: 5 }}>
                            <Text style={styles.labelStyle}>Profession </Text>

                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetDasignation(text)}
                                placeholder='Designation'

                            //value={Data.LastName}
                            >{Data.Designation}</TextInput>

                        </View>
                    </View>
                    <View style={styles.labelStyle}>
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.HeadingsTitle}>Address Details</Text>

                            </View>
                        </ImageBackground>

                    </View>

                    <View style={{ flexDirection: 'row' }}>
                        <View style={{ flex: 1 }}>

                            <Text style={styles.labelStyle}>Country </Text>
                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetFirstName(text)}
                                placeholder='Country'

                            //value={value}
                            >Pakistan</TextInput>
                        </View>
                        <View style={{ flex: 1, paddingLeft: 5 }}>
                            <Text style={styles.labelStyle}>Province </Text>

                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetLastName(text)}
                                placeholder='Province'

                            //value={value}
                            >Punjab</TextInput>

                        </View>
                    </View>
                    <Text style={styles.labelStyle}>City </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text.trim())}
                        placeholder='City'

                    //value={value}
                    >{Data.City}</TextInput>
                    <Text style={styles.labelStyle}>Address </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text.trim())}
                        placeholder='Address'

                    //value={value}
                    >{Data.Address}</TextInput>
                    <View style={{ flexDirection: 'row' ,margin:10,borderColor:'grey',borderWidth:0.3,borderRadius:5 }}>
                        <CheckBox
                            //title='Display my Name as Donur'
                            //sty={{fontSize:20}}
                            checked={Checked}
                            onPress={() => { setChecked(!Checked) }}
                            style={{ padding: 0 }}
                            size={25}
                        />
                        <View style={{ flexDirection: 'column',marginVertical:10 }}>
                            <Text style={[styles.labelStyle,{margin:0,textAlign:'center'}]}>Display my Name as Donur</Text>
                            <Text style={[styles.labelStyle,{margin:0,fontSize:8}]}>Note: (if you will un check this, your name will be hidden)</Text>
                        </View>

                    </View>
                   
                    <Button  containerStyle={{ flex: 1, margin: 5 }} onPress={() => upload()}
                        title="SAVE"
                        type="solid"

                    />
                    <View style={{ flexDirection: 'row', marginVertical: 10, marginBottom: 20 }}>
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="Change Password"
                            titleStyle={{ fontSize: 12 }}
                            type="outline"
                            onPress={() => navigation.navigate('ChangePassword', { Id: Data.Users_ID })}
                        />
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="Cancel"
                            titleStyle={{ fontSize: 12, color: 'grey' }}
                            type="outline"
                            onPress={() => navigation.goBack()}
                        />

                    </View>
                    {/* <View style={{ flexDirection: 'row', marginVertical: 10,marginBottom:40}}>
                        <Text style={{ textAlign: 'center', color: '#2088dd', fontWeight: 'bold', flex: 1 }} onPress={() => navigation.navigate('ChangePassword', { Id: Data.Users_ID })}>Change Password</Text>
                        <Text style={{ textAlign: 'center', color: 'red', fontWeight: 'bold', flex: 1 }} onPress={() => navigation.goBack()}>Cancel</Text>

                    </View> */}
                    {/* <Text onPress={() => copyToClipboard(`${Data.Users_ID}`)} style={{ color: 'black', padding: 10, backgroundColor: 'yellow', marginVertical: 10, borderRadius: 10,marginBottom:30 }}>My Referral id is <Text style={{ color: 'red' }}>{Data.Users_ID}</Text>.   <Icon style={styles.CreateIcon}
                        size={20}
                        raised
                        name='copy'
                        type='font-awesome'
                        color='White'

                    />    {'\n'}{'\n'}
                    Note! You can share your referral id <Text style={{ color: 'red' }}>{Data.Users_ID}</Text>  with your friends to get rewards points.</Text> */}



                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default UpdateProfile;
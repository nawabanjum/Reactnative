// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, Linking, Image, Alert, ActivityIndicator, FlatList } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/AntDesign";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native';
import { Card, Title, Paragraph, Caption, Avatar } from 'react-native-paper';
import { Input, Button, BottomSheet, ListItem } from 'react-native-elements';
import { BASE_URL } from '../Common/Urls';
import axios from 'axios';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../Common/CommonStyles';
import { bannerAdUnitId,adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
function MembersProfile({ route }) {
    const navigation = useNavigation();
    const [Data, SetData] = useState([]);
    const [GWData, SetGWData] = useState([]);
    const [P_Data, SetP_Data] = useState([]);
    const [HC_Data, SetHC_Data] = useState([]);
    const [FunData, SetFunData] = useState([]);

    //const [Id, SetId] = useState();
    const [isLoading, SetLoading] = useState(false);
    const { Id } = route.params;
    useEffect(() => {

        SetLoading(true);
        const unsubscribe = navigation.addListener('focus', () => {
            SetLoading(true);
            DisplayAds();
            var url = BASE_URL + "ApiCommon/GetUserById?Id=" + Id;
            // console.log(url)
            axios.post(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        SetData(response.data.Data)
                        SetGWData(response.data.Data.quotatoinModels)
                        SetP_Data(response.data.Data.poetryModels)
                        SetHC_Data(response.data.Data.handiCraftModels)
                        SetFunData(response.data.Data.jokeModels)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
        });
        return unsubscribe;

    }, [navigation])
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    const Footer = () => {
        return (
            <Card>
                <Button buttonStyle={[styles.AddnewBtn, { alignSelf: 'center' }]}
                    titleStyle={{ fontSize: 12 }}
                    iconRight={true}
                    type='clear'
                    icon={
                        <Icon
                            name="sync"
                            size={14}
                            color="#2088dd"
                        />

                    } title="LOADING  " />
            </Card>
        )
    }
    const Handi_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate("HandiCraftDetail", { CatId: item.HandiCraftCat_Id, Id: item.HandiCraftId })} key={index}>
                <Avatar.Image rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Golden_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate("GoldenWordDetail", { CatId: item.QuotationCategoryId, Id: item.QuotationId })} key={index}>
                <Avatar.Image rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.QuotationName}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Poetry_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate("PoetryDetail", { CatId: item.PoetryTypeId, Id: item.PoetryId })} key={index}>
                <Avatar.Image rounded size={50} source={{ uri: 'http://' + item.Image }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    const Sms_ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider onPress={() => navigation.navigate('FunnySmsDetail', { CatId: item.JokeCategoryId, Id: item.JokeId })} key={index}>
                <Avatar.Image rounded size={50} source={{ uri: 'https://pbs.twimg.com/profile_images/583641266979647488/ZiQhABjl.jpg' }} />
                <ListItem.Content>
                    <ListItem.Title>{item.Title}</ListItem.Title>
                    <ListItem.Subtitle>{item.Description}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron />
            </ListItem>
            //

        );
    };
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <ScrollView style={{ padding: 5 }}>
                <View>
                    <Card>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1, paddingTop: 10 }}>
                                <Avatar.Image style={{ alignSelf: 'center' }} source={{ uri: 'http://' + Data.ProfilePhoto }} size={80}></Avatar.Image>
                            </View>
                            <View style={{ flex: 2 }}>
                                <View style={{ marginLeft: 15, flexDirection: 'column' }}>
                                    <Title style={{ fontSize: 16 }}>{Data.FirstName} {Data.LastName}</Title>
                                    <Caption style={{ color: 'orange', fontWeight: 'bold' }}>Profession :  <Caption >{Data.Designation}</Caption></Caption>
                                    <Caption style={{ color: 'orange', fontWeight: 'bold' }}>City             :  <Caption >{Data.City}</Caption></Caption>
                                    <Caption style={{ color: 'orange', fontWeight: 'bold' }}>Country      :  <Caption >{Data.Country}</Caption></Caption>
                                </View>
                            </View>
                        </View>
                    </Card>
                    {/* <Card style={{ margin: 5, padding: 10, borderColor: 'lightgrey', borderWidth: 0.5, borderRadius: 10 }}>
                        <View style={{ flexDirection: 'row' }}>
                            <View style={{ flex: 1 }}>
                                <Caption style={{ color: 'orange', fontWeight: 'bold', padding: 5 }}>Golden words shared by  Ali : </Caption>
                                <Caption style={{ color: 'orange', fontWeight: 'bold', padding: 5 }}>Poetry shared by  Ali : </Caption>
                                <Caption style={{ color: 'orange', fontWeight: 'bold', padding: 5 }}>Handi Crafts words shared by  Ali : </Caption>
                                <Caption style={{ color: 'orange', fontWeight: 'bold', padding: 5 }}>Jokes shared by  Ali : </Caption>

                            </View>
                            <View >
                                <View style={{ marginLeft: 15, flexDirection: 'column' }}>
                                    <Caption style={{ color: 'black', fontWeight: 'bold', padding: 5 }}>43</Caption>
                                    <Caption style={{ color: 'black', fontWeight: 'bold', padding: 5 }}>34</Caption>
                                    <Caption style={{ color: 'black', fontWeight: 'bold', padding: 5 }}>34</Caption>
                                    <Caption style={{ color: 'black', fontWeight: 'bold', padding: 5 }}>34</Caption>

                                </View>
                            </View>
                        </View>
                    </Card> */}

                    {GWData.length != 0 ?
                        <View>
                            <Card style={styles.YouMayAlsoLike_Background}>
                                <Text style={styles.YouMayAlsoLike_Title}>Golden words posted ({GWData.length})</Text>
                            </Card>
                            <FlatList
                                data={GWData}
                                keyExtractor={(item, index) => index.toString()}     //has to be unique   
                                renderItem={Golden_ItemView} //method to render the data in the way you want using styling u need
                                initialNumToRender={1}
                                windowSize={1}
                               // ListFooterComponent={Footer}
                            />
                        </View>
                        :
                        <View >
                            {/* <Text style={{ color: 'red', alignSelf: 'center', fontWeight: 'bold' }}>
                                No Record found</Text> */}
                        </View>}
                    {P_Data.length != 0 ?
                        <View>
                            <Card style={styles.YouMayAlsoLike_Background}>
                                <Text style={styles.YouMayAlsoLike_Title}>Poetries Posted ({P_Data.length})</Text>
                            </Card>
                            <FlatList
                                data={P_Data}
                                keyExtractor={(item, index) => index.toString()}     //has to be unique   
                                renderItem={Poetry_ItemView} //method to render the data in the way you want using styling u need
                                initialNumToRender={1}
                                windowSize={1}
                               // ListFooterComponent={Footer}
                            />
                        </View>
                        :
                        <View >

                        </View>}
                    {HC_Data.length != 0 ?
                        <View>
                            <Card style={styles.YouMayAlsoLike_Background}>
                                <Text style={styles.YouMayAlsoLike_Title}> Handi Crafts Posted ({HC_Data.length})</Text>
                            </Card>
                            <FlatList
                                data={HC_Data}
                                keyExtractor={(item, index) => index.toString()}     //has to be unique   
                                renderItem={Handi_ItemView} //method to render the data in the way you want using styling u need
                                initialNumToRender={1}
                                windowSize={1}
                               // ListFooterComponent={Footer}
                            />
                        </View>
                        :
                        <View >

                        </View>}
                    {FunData.length != 0 ?
                        <View>
                            <Card style={styles.YouMayAlsoLike_Background}>
                                <Text style={styles.YouMayAlsoLike_Title}> Fun Posted ({FunData.length})</Text>
                            </Card>
                            <FlatList
                                data={FunData}
                                keyExtractor={(item, index) => index.toString()}     //has to be unique   
                                renderItem={Sms_ItemView} //method to render the data in the way you want using styling u need
                                initialNumToRender={1}
                                windowSize={1}
                                //ListFooterComponent={Footer}
                            />
                        </View>
                        :
                        <View>

                        </View>}
                  
                </View>
            </ScrollView>

        </SafeAreaView>
    );
}

export default MembersProfile;
// In App.js in a new project

import React, { Component, useState, useEffect } from "react";
import { View, Text, Linking, Alert, TextInput, FlatList, Share, ActivityIndicator, FastImage, ImageBackground } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Card, Title, Paragraph } from 'react-native-paper';
import Icon from "react-native-vector-icons/MaterialCommunityIcons"
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native';
import { SearchBar, Header, Badge, Button, Avatar, Image, Rating, ListItem } from 'react-native-elements';
import axios from 'axios';
import { SliderBox } from "react-native-image-slider-box";
import { BASE_URL } from '../Common/Urls';
import styles from '../Common/CommonStyles';
import Rate, { AndroidMarket } from 'react-native-rate';
import { bannerAdUnitId } from '../Common/IDs';

////Ads
import {
  TestIds,
  BannerAd,
  BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function ProductList(props) {
  const [search, setsearch] = useState();
  const navigation = useNavigation();
  const [Remarks, SetRemarks] = useState('');
  const [Data, setData] = useState([]);
  const [DataCount, setDataCount] = useState([]);
  const [isLoading, SetLoading] = useState(false);
  const [Rated, SetRated] = useState(false);

  const image2 = { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSrOirlCSVnddPD-wY6OytRvEp98zqTcFYh6g&usqp=CAU" };
  const image = { uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRo65zKZfMGxojTmtba2hplTbP5EQuFmCaOzQ&usqp=CAU" };
  const images = [
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ9rcH2xeEh5Z04GeQcDR0BaeGUTv6wKdWy2g&usqp=CAU",
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRn7POwtFuYuAMlrJw-qXKrFGYHthxxl-TuEw&usqp=CAU",
    "https://source.unsplash.com/1024x768/?girl",
    // "https://source.unsplash.com/1024x768/?tree",
  ]

  const WhatsNewList = [
    {
      Title: 'Lord & Taylor to relaunch online, with help from RTW Retailwinds',
      Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
      uri: 'https://etimg.etb2bimg.com/thumb/high-level-meet-to-discuss-e-commerce-policy-on-saturday-size-419850-updated-2021-03-12t09-38-07z/81465546.cms?width=362&height=240'
    },
    {
      Title: 'didas aims for DTC to be 50% of sales by 2025',
      Subtitle: 'A new four-year strategy is predicated on doubling e-commerce sales, building up an athleisure offering and refocusing on women, among other things.',
      uri: 'https://www.aseanbriefing.com/news/wp-content/uploads/2018/07/ASEAN-Briefing-Thailands-E-commerce-Landscape-Latest-Trends-and-Opportunities-002.jpg'
    },
    {
      Title: 'GameStop taps former Chewy execs to lead transformation group',
      Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
      uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAPDw0NDQ0NDQ0NDQ0ODQ0NDQ8NDQ0NFREWFhURExUYHCggGBolGxMVIT0hJzU3Oi4uFx8/ODUsNygtOisBCgoKDg0OGhAQGjceHx0tKy0tKzUrLTUtLi03NzYtKystKzc3KzcrKy0tKysrLTcrNy0tKystLTc3NDgtLSsrN//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIDBQYHBP/EAEAQAQABAwIBBwYLBgcAAAAAAAABAgMRBBIGBRMhMUFRYSJxgZGhsgcjMjNSYnOxwcLRJEJjcqLwNFN0k6PS4f/EABgBAQEBAQEAAAAAAAAAAAAAAAAEAgED/8QAHxEBAAEEAgMBAAAAAAAAAAAAAAECAzEyEVESISJB/9oADAMBAAIRAxEAPwD3EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHzco35ot1VR146PP2R+HpBF7lCzRO2u7TFXdnOPP3PooriqIqpmKonqmJzEvj0/J9q3RmummasZuXaojMz2znshz17iXT6a5XFjdeoqjpoojbRFfZVEz6erwcmqIy7FMzh144+jjqn9/TVUx3xcifyt7yZy7Y1HRRVtr+hX0T6O9yK6Z/Wpt1RmGzAaYAAAAAAAAAAAAAAAAAAAAAAGs5auY5mmf3r1mJ/3aP0ls3McXarZNFOfK+LqoiOmZq3TiPZ7AW4h1s13J08T5FuIquR9OuYzFM+ERifT4OOtaeaqq8Rmd1UzM9VNMT1z6+rxba3qKrlVy5Xt3111TVtztznGIz2dBNMWdFevRjnL+qm3TPhETj1eXKefqr2pj5p9Of5Yjm7Vc0VxF3bM0ZmMzPhT2uK0HGWp012I1dudu7orpom3dpx+9HZXHmdtTTEdPbPTMz01VT4z2sGu0Nu/RVbvUU101d8dMeMT2SedOODwqzy9S4a5Vp1els6iiqK4rp+VT1VT3to8y+BimvTzynydXM1W7F2zqNPVP+XeiqJj128+eZ73pr3jCecgDrgAAAAAAAAAAAAAAAAAAAA8x445QmjU6yuOuxZpot+EzTTET665enPK/hM0U06qqZnFvW2cbp6qblMRT+WifTIL8PVZ09ievNq3OZ6c5phm5TvfEWbXZF+/V6cU/wDaXz8PUzTp7FNUYqptW4qjumKYiYU11XlY7q6/uoTdqunzgMPR0/wf0Rz2qqx0zasRM98RVX+rt3EcAz8df+yp9lX/AK7dTb1SXNpAG2AAAAAAAAAAAAAAAAAAAABoOKuSKNVzMXombNNVXOTT0VUxMRiqJ7OpvwHmmksxa3WqKpqotVV26aqvlVU0ziKp8ZiHwav5dX89Xu0Nvqv8Rqv9Rf8AflqdVHlVfaV+7bTdqumJASw9HTcBz8fd+x/NH6u5cJwJP7Tcj+BV79Du1NvVLd2AG3mAAAAAAAAAAAAAAAAAAAAAA8713+J1X2933ml1PztyMzjMzjPRnojPsj1N3yn0arVfa1NJqfna/wC+5JVlZThBJKJcadNwHH7RcnusT7a6f0d04bgL5+99jHvw7lRb1S3dgB6PMAAAAAAAAAAAAAAAAAADKMgkRkyDz3lro1mqj+JE+uimWk1XztX99je8QxjW6nx5uf8AipaHVfOz6PuSV5WUYhAgZadVwBHxuonutUR66p/R27jPg/p8rUz9WzHtqdmqt6pbuwA28wAAAAAAAAAEZEAJRlGTIJyZRlGQWMq5RkF8oUybgXyZY9xuBxHFEY1tz61u1P8ATj8HO6ufjfRH3S6Xi6P2umfpaej2V1w5nWfOR5o+5LXsrt6oAYbdp8H9Pkamr69un1UzP4uscxwHTjT3Z+lfn2UUumyqo1hJc2lYViUtsLCISAAAAAAAACMIwsAphDIgGNWWXBtBhmUZZpoVm2DDNSJqZJtKVWpBTejnEVW5Ya4kHO8YU/GaevvouUT6JiY96XK6yfLjzU/e7PiDTzdszERmu3MXKI75jOafTEz6cOG1FeZifD2wmux7VWp9Moxc/T25j0TP3HPZxFETVMziOjrnzdbzej0TgynGkpn6Vy7P9WPwb6Gu5D0s2dPYtVfKptxv/nnpq9sy2UTHespjiEdU8zK0LQpvjvRzsd7rLIlh56GSirMZBYAAAAAAAFNyN7HlGQZN5vYpVyDNziOdYVZBn55HPsCswD6J1Cs6qHzzCNoMlWrjuYa9V9VPNkWQfDfrmrqplz/KXDNd6qa6KqbdUzmc0zO6e+el2NFiGam05McuxPGHnMcG6ntu28eFE/q2vJXDdyxVvzurjqmYjo83c7amheKIciiIdmuZaCmm/HbK0Td7ZlvZtwrNmGmWmiuvtyvFdTZzp47lJ08A+GKqn025nDJFhk5sFIuT3yvF2rvNidoLRenwWi94Me1O0GWLseKYrhhwnAM26O8YcAKyhbACqMLYMAphGGTBgGPajay4NoMWxOxl2m0GLYtFDJEJiAVppWiFohIIhYSAABgwkBXBhYBTabVgFNphcBTBhbBgFcIXwAxGGTYbAUwL7DYCmDC+w2gpgwvtNoK4ML7TaCuDC20wCIhKcGAAASAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q=='
    },
    {
      Title: 'Why Nordstrom has gone all-in on DTC brands',
      Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
      uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_omS2xw4RY_KnAWupqw7qD02aDWL8gS0FJg&usqp=CAU'
    },
    {
      Title: 'Lord & Taylor to relaunch online, with help from RTW Retailwinds',
      Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
      uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSInj2iJzDxIsKUyIPza72jqvh0bi2kI2t2NQ&usqp=CAU'
    },
    {
      Title: 'What is the new retail playbook in a post-pandemic world?',
      Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
      uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIQEhURExMWFRIVFxsbFhYXGBsgFhsaFRsYFh4ZFBgaHyghGhoxHhcWIz0hJykrLi4uGB8zODM4QyguMCsBCgoKDg0OFRAPFSsdHR0tNy0tLS0tKy0tLS03Ky43MSstLS0tKy0tKy43Ny4tNy0tLSsrLis3Ky4tLTc3LTg3N//AABEIAPcAzAMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABgcEBQgDAgH/xABDEAACAQMCBAUBBAcFBQkAAAABAgMABBESIQUGMUEHEyJRYXEUMoGhIzNCUmKR0RVygrHwVJKTwuEIFiRDRFNjwdL/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAaEQEBAQADAQAAAAAAAAAAAAAAAREhIkEC/9oADAMBAAIRAxEAPwC8aUpQKUpQKUpQKUpQKUqMc1c9WnDmEcpd5SM+XGAWAPQtkgD+eaCT0qhucvFK4mlX7KrwRqpB1E6mYkZOFOMDAHfqaiFxzDxa6lYxTXDNHErMIXlGFwGJKowzu/tmg6opXOHK/OfG7GUtJBd3UZUqY5RMRkEHUrkMQwAI9vV9KvjlbmKDiNutzAfSdmU/fRx1SQdmGfxBBGxFBt6UpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQavmTjkdhA1zKGKJ1CgFvrgkVDG8ZuHgRs0dwFlzoOhdwrFScB8jcH5rVeKPHVmuBaF0jit5ofNZ8+oSK7PjBHpH6IagRgsckbVFpOB2avoUGSDSHiBYMYxKTJoDZ2+8D369T1ISXj3jSqhxaRq51YTzBIvp0Z1t6eus40ewznfasOKcclu5nnlUapDlzvnJAAxhsbAYH0rMuUghk2ijkUZ2kVSTn5x/wDe3tWoLRjXkEBjnC4AAySAN/n8hQfTyeY2N1RBgMR+yBnYZ9TfHc46dawftUiOZI9cZIwCjOG0jAALL12VfxHSvEMxOATW5jgWD0EBp8anZ8mOFMA/c/bk36HIyyLjJOJblanzs14RcXvNj9on2IIHnPsVIYHDDGcgGpB4WcUnsL6PyixhnkSOdSPRpZsazgYUrknPtnsa0UN0MkgZJPfGf5DYfQbV9XV6zjTk6Ttgd/r8VWXT9xzNZRg6ruAaeo81M7fwg5J+KgfFfFnLFbWEFR0eXOT8hARgfU5+BVKoAnQDPc/0+Kybi5MKDGNbZ3boMYPTv1H50Fl3nindqupjDGvvpP5ZJyfpUW4n4wcRf0wzaR+/5cef8IKnH4/yqB3aOx1OSze59v4f6V4CgmVt4k8XRtX212+GSMqfjGjp9MVcfhb4gtxXzIZogk8Shiyfq2BOMgE5U57ZI+e1c3q1Xv8A9nvhqLaz3QYGSWXQwHVViGQD8nWT9NNBbFKUoFKUoFKUoFKUoFKUoFKUoOdPEKTVfXesjAkAyQSABpxkDqMdq8+XlHlDHTTtgYH4DtWz8XbM/bpwgyZBEcdtTBUAydhnT3+a1vAEKxqrDDBQCPYgYI2qxKj/ABKE6j9a1V0hAJqT8UXBNaC5OQRSjG4OdL68ZCKzkHp+jVmAPwSMfjX0XbyQzHLTuzM3ciMgb/V2c/4RWNaT6VlX96Ij+TK3+QNZ9vftCtrImnUscijUoYZMsudmBHRxWZObW7esjGRv9f6/GvWE5Nel1ePcvqcrqwB6VVRgFj0UAdWPb29qeXpAPyKrL2jGWA+a8uYl9KH+Jv8AJa+4WIYH5rz43JlQPZm/yjqjBsG1ZiJ6glD7MN6xA39ayOHfrV+N/wAq8WG5/GoP1KmnhZzK/D76P1HyJ2WOZe3qOFf4Kk5z7Fh3qGIKz+G27SSxxr953VV/vMQo/Mig7CpSlApSlApSlApSlApSlApSlBRHjNLpup8EhtMBGCQdtW4I6bkVpuXmJiQkkkopJJ3JIG5rZ+N4xeyD96KIjbtqI/5T/KtPwKYCJATjCL/kKsR4cZO5qNz5z8YNb/jEwJ6itC7ZpSMC1wGyQSoJ1fKnZgP4tOo/hWdFYHeEndHyp7FXAyR8EBGH1NYixYzkbH5rZcG4pHFIvnxC4iUEafNZHUHfZkYZwcnSdtz0zms863MzKy7fg5AJB9WNvr7VjQvhhqG2d9u1ZnF+IQ/ftZiQf/KlADjPs6kq30JBHu3WvDhjSSE+Z5aj3eRFOfoTk1WW1FkprScyWr5UqvoGdR7ZPv7dBW0tBNLKILdNcrn0xq8ZBwCTpYPp6Anr2r413KuyPGyOpwysuGHwyn/I0EehCop39Z6nsq9z8n4rFG+/5fFb654Osm6r5bfA9BPyv7P4bfFaie1eJtLjHz2PyDQfCLVu+CXJjSSDiUw/RxkiBf3nGxc/wruP73tp3qiNc1evgDxCR7a4gbJjhkBjYj0jzQSyKfgrqx/8nyKC06UpQKUpQKUpQKUpQKUpQKUpQeFzZxS/rI0fHTUoPX2yK8Dwa2P/AKeH/hp/Ss6lBrv7BtP9mg/4Sf0qmvFyzuLW68xIYYrRlVYmWGAgvgswbUhbVsx9sYq9q8L2yinXRLGkiddLqGXI74Peg5FMWTkkfQRoB+ACgCt3ZctarczRxtNKQSIxGpwFO50hcntXR/8A3Wsf9jt/+En9K564vcPBcW3kSNF5jt5nluVJAuNIDFT00nGOmw9qCLHUjHVEqlCuzxID6skZQruux6jHT3q6PCbh1lxO1c3FpG00MhRpAgVWDDUMaMDUAcEAe3vVhXPKNhIzO9pA7N95mjUse/qJGTW0sbKKBBHFGkca9ERQqj6AbUGt4VytZWj+ZBbxxvgjUBvg4zgnp0rL4jwi3uP1sSOR0JHqH0Ybj+dZ1KDQtybYHrbr/vPn+eqvCbkLhrjDWykexZ//ANVJaUEQg8MeEo2oWgPw0krL/uM5X8qlVpapEixxoqRqMKiABQPZVGwFetKBSlKBSlKBSlKBSlKBSlKBSlKBSlKBSlKCoPETma6fiEnDopjHb+UBIEChyXGo+vBZdmA2IqqeYuDRQEKgPyScmp1fyeZxy8brglf93Cf8taDmPh01zcGOFNbKpYjIGw+TgZ36fX2p4Jh4P87XctzHYTSCSERkIWH6QFQWGX77KRvmrqrlOfh13ZrJOMx6U2kSRcjOn7pVs7q46dQ2KsLwt4xIqQTajiRvLlGfS3q0a8e/Rs/Ud6guqlKVQpSlApSlApSlApSlApSlApSlApSlApSlApSlAr4mfSrNgnAJwOpwM4Ga+603MV7b6TaSmJmnRgIZJAnmDoR+9j5AOKCkLJ5mvbm8aF0Ersyo6SnZizfeRG6ZA6f9dPzDb3UkjMiTBGHqVElCNjJGrIGr8V2r65zsp7K4wLNbCBhhNEsrwu/XLyahg/guO471GjHPcK7BAQm76mBKjc5Or6Gg2E0dzKTG4mJkGnDeYcuzbMQ3fGkf4RVteG/KU8QijkjZEhOp2dSNT6teFBAyNXf2FVj4d8BNwzSTcOF1anbzGleBUIJyUZD+k7grgnIG43z0Vytx23uVaKAFfs4VSpIOBghcEE5+6RvvtUG9pSlUKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQKqfxshj82xlOksrujoJAshUqXXGWGACGOdtyB3FTjnri8tlZvcxRiQxkFwWK4Tu2VBO23QVUPGP7FvtP2mBrC4lGpZVPoOrfLEek5z1K7b5IoNPwrnhstb3ANzYyZGhhmSNeuRkb4H7PfAxg7nM5c4Fbw3N0JnD2SJ5jKCS7hPKdY9tyP0oz3IwP2jXxLwG4s7Oazjiik1yRk3iKDKbeXKt1yVVSqE6SRiT4JqC8au2M7RrI7IGZQdTkn9kk5PU7k42Oo+9BJuduc570BFP2e2HpW3XIOkdNQUbjHb7tWh/2feF+VYSTlNJnmOk9NUcY0qcf3jL+VQXh/It5dQRy3k0dlbrGAXIxLIpwR5y5UHbbLnV9djWbwbmC04M2i04jPOADmJgXtznJyFVPTuc5VvrmoL+pXjZys8aOy6WZQSvsSASM/HSvaqFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoFKUoItzzfz/Z3hgsjdiVGR8yIiBWBU51HU3Xoo/Gud7Dg1xc3sNhPm1eT05nDYyAd0yOpIwADjJxttU357ebhl/c+Xc3Cq6CZNEmdJlZxiRWySmoEYXBAArW8E5su+IFbaeH7UQylZYk/SoxPpfCjGAcbjSQATk4oJjxOyt+WrTGuW5uJjot02VVZ8E6RvpXUuojfJ2AGSarfiPPE6SaXgh1DGsBGDdiVDFiM/xYI747VffNfCo7i2WW5jQmJQ7gsBoZBqLRuxABBzuSBg9fei7y34NNMXFxNrdjlWDKAWOTqZkAUZJ3LAD3oJJzLwz+1bV+L21yZUjUtJbTHHlBE1Mo/Zb3yAM7dTsYNyVxCytuIwy3TZt4yWDRxtp149OpW9RUE9hnIG1W1xLlix4fw0RXUjJbSyI0iw5Ik05KQggEsCTqJGCcdcAmodf8+W1sunh/Do416CWTGrbbcA6u379QX/AMN4hFcxrNDIskTjKupyD/1+O1ZNV34OC5nhkvpyoE+0aKpXaNmUs2WOd9h8A+9WJVClKUClKUClKUClKUClKUClKUClKUClKUCol4gczDh6R64ZXimJRmjbSVOwA1AhtRycacH0mpYTiq98WLyaa1ktobCa4BwwlBXSjIdQKoCZGIxjGkDfrQV9xblzgt8xSCaSzu+uifV6mb3805JJ6erPsKtDwot/Jsvs7RRxzQNokMYAEmACsp7kkHBLb5VqorlTlyXjF69vqELKNT+dvIqqVBVRgF236HG3U+/RXJ/K68Oi8sSvKxwC79cLnSq9SFGo9ST84AADQ+LfA7i/t44In0p5itImceYF3K59+jAHbI+KpXj3JN607aLdlhGy65VwFAwMeokLt0/Lar28UuZ/7Ps2YRCaWQhI1ZcoGbo0nwPzOBXPHFuLXtvKqvPMxXBKNO7xEjDadLdUxgaWz9TQXt4QcOuI7JoblhLECBHq3XbIZV1dUHpHtnVVX83ctLdcQuLfhdqTFGQkshyUSZSS4iJbSo3UEH904wMVcPhlzgvFLQN5YiljAWRVGI+4DRfw+k7dsY36mI+Jb8ZtVZ4yq2QJy1uCZQuMlpiw9GSScrsMHJ9w+uT+LcQ4REsV/JbvaxoFRVb9MgUbAPgIVHsST87b23E+oBtxkA79d/cdjXLPIccM3FYvt8qaFyzG4kVw5A9KM5yM6iDuexFdTqc7jcGg/aUpQKUpQKUpQKUpQKUpQKUpQKUpQKUpQfE0epWXJGoEZHUZGMj5rnfi3Gb/AIU9xCbqfXFNpQvl4ipwylzJqw5U6sZxgjbvVwc6c0wWZWCaSWLzV2eJcsN8HDkEKfwJ3qo+L8l2V8Wey4o0lw25W4fVI5G27bMcbDIVqDO5R5tkv7uAvag3kbeiWIHBBBDK/dFKFhqzpz2FXzUX8OQgskQQRwSRkpKkYGkyLjLg99Q0tk5O+DuKlFBqeZoovIeSVkVI1JZpBlNI6hh7f6weh5+4lzZYMfM/sxNbbiRiDGQDjUCUyRt+7nbp2q7PEjl3+0bNoDIY1zksN8EYILL3UY/PPbNU5zB4eO7rIs1rHEqgZBJJAAGThQD/ADoLo5AhtfswmtZFlWXBaRRj7uwXT1TGT6TuMn3r58RIGmtGg+0LbRyfr5W7Qj7wXJAydlySBgt9DofB7lV7CORtTGOTGNW2ojJ1qvZcHY5Ocn4qacd4FbX0flXMQkQEMASQQR0IKkEfzoKGvLjl+xGmGB7yQbazuhO3UnCkbDoDVj+DvEJrmGSXyxFaDCQRhsrlS2rSuldAGw22JJ9qqPn/AJYS1vmsbV5LltIbQOsRY50SaR6/SVO2n7w2qyvDfj15Y28dreWQhgjXCyqw1kklsvDkkkkkltt+29QWtSvOCZZFV1OVYAqfcMMg/wAq9KoUpSgUpSgUpSgUpSgUpSgUpSgUNK8L+FnjdEbQ7KQrYB0sRs2DscHBwfagrDxp4/amFYNEr3EcqPG6RnQhB9X6RsKTpJ2Un1Bc9KqvlfgFxxq5cQkEqVMksnpKrnALqCSzbHYdx261L5PEO/tvMhuPJneORkeN1CuQpK5GgKpGx6jp2Ne3J3GrGS/huLaBra6J0SQrskqv94LgaWxkNjCnKg7gUFrcncuGwh0PM08rY1SN3C50j3OAcZJJNb+lKCB+L4vntPKsyylj+lKZ1mPo2jG56jIG5Ga5z5hto4rgxR4OkAZwdRbr6snBbJ9hXT/iPzJFw6zaaRS7E4iUHBL9jq7AdT8ZFUfxnxA4jHpWRItTKGz5Z1jPYsG0k47gfh2oLa8G+NXdzaFLsNrh0hXfOtlIOA+dyw09TuQRn3M/qEeFPNMHELXEcXkyR481OoLN+2rdWzg9dx09qm9BT3PfMNzwx5TDYrD5r/pLxxlXZhq2I67bAMdsY04FV5y7Pc8X4hb289xI6Sv6hkopRQXYIFIGdKkAgV0Nzw832KVIIlmmlHloj40evYs+rbSF1Nv1wB3qkrnw9tLRA/Eb/EuB6Ub17DohcEkD4XtQdExRhQFAwAAAPYDYV9VXPhZzEblmgiaWW0hTaWbUW1EjCiRt221HBGwxjbAqxqBSlKBSlKBSlKBSlKBSlKBSlKBWj5i4jIAYLaWCO6IBXzjkAHuI1Oo9CM9M++MVvKqnxyS10QyGSEXSuqhGcB3jbPXG4UMc6ugyd6CvOfOUOLh2nmAuS7a3aJVOG0hcqAA4XAG2MbZq7fDrhtgtnDPZxBRIuS7YM2royyOd8hgQQDgY2qi+UL/iU8wgsnlbcBoyfMgVckZYsSEXr6shjjY9K6D5O4bPb2+m4KeazamVCSik4yFJ36jP49+pDe0pSg0fOHDLe4tn+0CMxIpLeacR4G5LN1XoDkbjFULxbiPBZCJjFdSHHp1M2kgbbNqG34596vTn/gRv7KS2DMmrGSu5GNxt+0M4yO4zVG8Z8PrlhEFa1WOJca9bZbHcjR1+N/rQW54UfYmtjLaMpLY8xVGny8Zwmk7jct6v2jk1OKrHwc5Oax8yYuWWRcAkYD5IbUq/uDGx76ifarOoNdx3hX2qFovNkhJ6SREB16Z0kgjfGPf2wd65t8ReVW4ZcGN5lkMgLxnDNMw1YAcHOluvqJwcH5A6jqlObOJcLtb2eeeGW6vmOCjA+XGMDSgBwuNIX947k96DI8DubLGKBbA64rpnZ3Lr6JGY4Glhsp0qgw2NxtmrjrnCDnG74hcRWVvDDAsrhAqjVpz1YhSo0gZJ26A10Nw20EEUcIORGiqD76QBn8qDJpSlApSlApSlApSlApSlApSlBicWkkSGRok8yRVJVNWnURvp1YOM9M4NUle8Z4JdFpLq0eCV86plBYEnrqZfvH6oTVuc0cfazj1RW0t1L2jixt3y7H7o+gJ36VzFzBcObk64hbGWViRqJRA7ZAZSMqFB+M4yBQWl4Y8PTh15qtrpZ7G69D5xqV1yYyWXqckrjC/rNxttc9QbkXw3tOHhJ9XnXGneTpGckMNCAkYGBgnJ71OaBSlKDT83Xc8NpM9sAbjQREDjGojbrtn67ZxXLfHOEz4jaRZZLmQlpdcbmTJ7MTufxGfnFda3tsJUKHbPf2I3B/nUC4vw2+QlFieQdmQjSf5kEfjQabwO4jfLqs7rV5QQtEJP1i4KgjfcKdXQ7gjtVu1EuS+AtbappQTM4xjsq5zjJ6kkDPbYY9zKwT7UH1UK8WYIHsWWS2a4mY6bZEB8zzWBwyldwAASexAwetTStBzjYXs0X/gpY45h/wC4CRpPXRjIDZx1BFBR/L/JHFrSVLxGgtZUGwbSQARpIKqGByCeuD896uvlDmb7WDFJp+0RqC7R/qjvjK5OV+h/ma5u5ra91ut6ZvMQjWsrAAZzjSvQjY7qCDV5+CHDbaHh6PE8bzS+qcoQWByxSOTHQqpxj3LHvQWHSlKBSlKBSlKBSlKBSlKBSlKDSXEmlmz1yaiPNltDcppmjSQdtQBI/unqp+hqc8U4d5oyp0v79j9f61Gn5TuJH/SPGE7hWbJ/HSMfh+VQbfkVStjAmCFRSiZOToQlV6/AA/Ct9WLaW7IoXKhVAAVV2AGwArJFUftKUoFKUoFKUoFfjNgZPQV+1+EZoKh4nyGL66lvb+YuznEcSDCxxgnSmpgcnB3wBuWPfNYy8Kg4a/nWa+VMM+vUxJB6hgxII6bY7D2qacehe3ySCY+zgZH+LHQ/Wova2hvZAoJEefU56Y7hf3m+n41EWrYXHmxRyYxrRWx7agDj86968bdlACqMKAABjsNhXtVUpSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlApSlB/9k='
    },
    {
      Title: 'Mashable launches shoppable virtual home featuring Walmart products',
      Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
      uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR46A_lYw4jyWVAczJykUwFSIvi78aDhzOKgg&usqp=CAU'
    },
    {
      Title: 'Dicks fulfills 70% of orders from stores, cuts delivery estimates 10%',
      Subtitle: 'The retailers cost of goods sold — which includes shipping, freight and distribution, along with the cost of the merchandise — was up nearly 11%.',
      uri: 'https://english.cdn.zeenews.com/sites/default/files/styles/zm_700x400/public/2020/07/25/874639-e-commerce-notfiied.gif'
    },

  ]
  const users = [
    {

      name: 'Clothing',
      uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2c3irvr74B5y9PevZ1mkq6Wcu671wd6Ve3w&usqp=CAU'
    },
    {
      name: 'Shirts',
      uri: 'https://cdn.shopify.com/s/files/1/1749/9711/products/Navyshort_1024x1024.jpg?v=1509980184'
    },
    {
      name: 'T-Shirts',
      uri: 'https://cdn.shortpixel.ai/client/q_glossy,ret_img,w_750,h_400/http://www.designhill.com/design-blog/wp-content/uploads/2018/10/27.jpg'
    },
    {
      name: 'Kurtas',
      uri: 'https://i.pinimg.com/originals/fe/f1/8a/fef18ade3820c0c90746ea0275a9a7bf.jpg'
    },
    {
      name: 'Winter Clothing',
      uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTwaEEc5iYuktCzJcr95vKNwUM71giXc61glg&usqp=CAU'
    },
    {
      name: 'Inner Wear',
      uri: 'https://miro.medium.com/max/1902/1*6Hj7mOddt1sz89ZScuiL3A.jpeg'
    },
    {
      name: 'Accessories',
      uri: 'https://i.pinimg.com/736x/65/04/d0/6504d02171d72304d880bbdf68697fcb.jpg'
    },
    {
      name: 'All',
      uri: 'https://cdn2.iconfinder.com/data/icons/buno-editing/32/__justify_all_paragraph-256.png'
    },

  ]

  const renderItem = ({ item, i }) => (
    <View style={{ margin: 5, flex: 1 }} >
      <Avatar
        size='large'
        rounded onPress={() => navigation.navigate('ProductByCategory')}
        source={{ uri: item.uri }}
      />
      <Title numberOfLines={2} style={{ color: 'white', fontSize: 12, textAlign: 'center' }}>{item.name}</Title>
    </View>
  );
  // const toggleDrawer = () => {
  //     //Props to open/close the drawer
  //     navigation.toggleDrawer();
  //   };
  useEffect(() => {

    SetLoading(true);
    const unsubscribe = navigation.addListener('focus', () => {

      // Alert.alert('Refreshed');
      var url = BASE_URL + "ApiCommon/GetWhatsNewList";
      var Count_url = BASE_URL + "ApiCommon/TotalItemsCount";
      axios.get(
        url
      )
        .then(response => {
          SetLoading(false);
          if (response.data == null) {
            Alert.alert("No Record Found ")
          }
          else {
            SetLoading(false);
            setData(response.data.Data)

          }
        }).catch((error) => {
          SetLoading(false);
          Alert.alert("Internal Server Error", error.message)
        });
      axios.get(
        Count_url
      )
        .then(response => {
          SetLoading(false);
          if (response.data == null) {
            Alert.alert("No Record Found ")
          }
          else {
            SetLoading(false);
            setDataCount(response.data.Data)

          }
        }).catch((error) => {
          SetLoading(false);
          Alert.alert("Internal Server Error", error.message)
        });
    });
    return unsubscribe;

  }, [navigation])
  const ItemView = ({ item, index }) => {
    return (
      // Flat List Item
      <ListItem containerStyle={{ borderRadius: 10, paddingVertical: 5, marginVertical: 5 }} underlayColor='white' bottomDivider key={index}>
        <Avatar size={50} source={{ uri: item.uri }} />
        <ListItem.Content>
          {/* <ListItem.Title>{item.UserName}</ListItem.Title> */}
          <ListItem.Title style={{ fontSize: 12 }}>{item.Title}</ListItem.Title>
          <ListItem.Subtitle style={{ fontSize: 10 }}>{item.Subtitle}</ListItem.Subtitle>
        </ListItem.Content>
        <ListItem.Chevron />
      </ListItem>

    );
  };
  let upload = async () => {
    //Check if any file is selected or not
    if (Remarks.trim() == '')
      Alert.alert('', " Remarks can not be empty.")

    else {
      //If file selected then create FormData
      // const fileToUpload = singleFile;
      // const UsersId = global.LoginDetail.Users_ID;
      SetLoading(true);
      const formData = new FormData();

      formData.append('ParentId', 0);
      formData.append('Comments', Remarks);

      if (global.LoginDetail == null || global.LoginDetail == undefined) {
        formData.append('UserId', 7867);
      } else {
        formData.append('PostedByUserId', global.LoginDetail.Users_ID);
      }

      //debugger
      axios({
        url: BASE_URL + 'ApiCommon/AddWhatsNew',
        method: 'POST',
        data: formData,
        headers: {
          Accept: 'application/json',
          'Content-Type': 'multipart/form-data'
        },
      })
        .then(function (response) {
          Alert.alert("", "Remarks added successfully");
          SetRemarks('');
          SetLoading(false);

        })
        .catch(function (response) {
          Alert.alert("Error", "Upload failed");
          SetLoading(false);
        });


    }
    // else{
    // alert("Please Select file.");
    // }
  };
  const onShare = async () => {
    try {
      const result = await Share.share({
        message: null
        ,
      });
      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed error.message
      }
    } catch (error) {
      Alert.alert('', 'Coming Soon');
    }
  };
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
      <ScrollView style={{ padding: 5 }}>
        <SearchBar
          onChangeText={(search) => setsearch(search)}
          containerStyle={{ borderTopWidth: 0, borderBottomWidth: 0, backgroundColor: 'orange' }}
          inputContainerStyle={{ backgroundColor: 'white', height: 30 }}
          placeholder="SEARCH NEEDS"
          fontSize={14}
          value={search}
          leftComponent={{ icon: 'menu', color: 'gray' }}

        />

        <View style={{ flexDirection: 'row', padding: 5 }}>
          <View style={{ flex: 1 }}>
            <Card onPress={() => navigation.navigate('ProductDetails')}>
              <Image source={{ uri: "https://images.pexels.com/photos/994517/pexels-photo-994517.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500" }}
                style={styles.ProductCardsImage} resizeMode='cover'
              />
              <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                <Text style={styles.ProductCardsTitle}>Oxford shirts, cotton shirts and woven shirt.</Text>
                <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>
              </View>
            </Card>

          </View>
          <View style={{ flex: 1, }}>
            <Card onPress={() => navigation.navigate('ProductDetails')}>
              <Image source={{ uri: "https://www.theworkathomewoman.com/wp-content/uploads/Where-to-Sell-Used-Clothes-Online-for-Cash-2.jpg" }}
                style={styles.ProductCardsImage} resizeMode='cover' />
              <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                <Text style={styles.ProductCardsTitle}>Find the best Used Clothing! Used Clothing </Text>
                <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>
              </View>
            </Card>
          </View>

        </View>
        <View style={{ flexDirection: 'row', padding: 5 }}>
          <View style={{ flex: 1, }}>
            <Card onPress={() => navigation.navigate('ProductDetails')}>
              <Image source={{ uri: "http://static1.squarespace.com/static/5442b6cce4b0cf00d1a3bef2/544ea656e4b07de01f73d3c5/5e20bf24a917cc6d14820020/1590698561156/how+to+sell+secondhand+clothing+online.jpg?format=1500w" }}
                style={styles.ProductCardsImage} resizeMode='cover'
              />
              <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                <Text style={styles.ProductCardsTitle}>Find the best For Winter! Used For Winter</Text>
                <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>
              </View>
            </Card>

          </View>
          <View style={{ flex: 1, }}>
            <Card onPress={() => navigation.navigate('ProductDetails')}>
              <Image source={{ uri: "https://images.theconversation.com/files/371985/original/file-20201130-13-xieqc.jpg?ixlib=rb-1.1.0&rect=0%2C0%2C5129%2C2560&q=45&auto=format&w=668&h=324&fit=crop" }}
                style={styles.ProductCardsImage} resizeMode='cover' />
              <View style={{ padding: 5, paddingTop: 0, alignSelf: 'center' }}>
                <Text style={styles.ProductCardsTitle}>Capture great Boys Tops, Shirts & T-Shirts</Text>
                <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>
              </View>
            </Card>
          </View>

        </View>
        <View style={{ flexDirection: 'row', marginTop: 15, backgroundColor: "white", padding: 10 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontWeight: 'bold', marginLeft: 15, textAlign: 'center' }}>
              Recently Shipped items
              </Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row', marginBottom: 5, marginLeft: 15, marginRight: 15, marginTop: 10 }}>
          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row', }}>

              <View style={{ flex: 1 }}>
                <Card onPress={() => navigation.navigate('ProductDetails')}>

                  <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWhGrporkUNUw2scGnQ4LJJ7UkpxFIJnQKRA&usqp=CAU" }}
                    style={{ flex: 1, aspectRatio: 1, margin: 5 }} resizeMode='contain'
                  />
                  <Text style={[styles.ProductCardsTitle, { padding: 5, paddingTop: 0 }]}>Baby's Cap</Text>
                </Card>
              </View>
              <View style={{ padding: 5 }}></View>
              <View style={{ flex: 1 }}>
                <Card onPress={() => navigation.navigate('ProductDetails')}>
                  <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVYjjQiihWaz5fLPOwhz1Daznpz7PzAGsy8Q&usqp=CAU" }}
                    style={{ flex: 1, aspectRatio: 1, margin: 5 }} resizeMode='contain' />
                  <Text style={[styles.ProductCardsTitle, { padding: 5, paddingTop: 0 }]}> Shoes</Text>
                </Card>
              </View>
            </View>
          </View>
          <View style={{ padding: 10 }}></View>

          <View style={{ flex: 1 }}>
            <View style={{ flexDirection: 'row' }}>

              <View style={{ flex: 1 }}>
                <Card onPress={() => navigation.navigate('ProductDetails')}>

                  <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNPKMZHwlgr62dSj6kQvSEKzT58iVRPoQJFw&usqp=CAU" }}
                    style={{ flex: 1, aspectRatio: 1, margin: 5 }} resizeMode='contain' />
                  <Text style={[styles.ProductCardsTitle, { padding: 5, paddingTop: 0 }]}>Bag</Text>
                </Card>
              </View>
              <View style={{ padding: 5 }}></View>
              <View style={{ flex: 1 }}>
                <Card onPress={() => navigation.navigate('ProductDetails')}>

                  <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLQaxK1i5HF4E-JjlUFXk9PEY9FLv6YO5e2w&usqp=CAU" }}
                    style={{ flex: 1, aspectRatio: 1, margin: 5 }} resizeMode='contain' />
                  <Text style={[styles.ProductCardsTitle, { padding: 5, paddingTop: 0 }]}>Bag</Text>
                </Card>
              </View>
            </View>
          </View>
        </View>
        <View>


        </View>
        <View style={{ marginTop: 10 }}>
          <ImageBackground source={image2} style={styles.HeadingBackgroundImage}>
            <View style={{ flexDirection: 'row' }}>
              <Text style={styles.HeadingsTitle}>
                Recommended For You  🎉
                  </Text>
              {/* <Icon name='chevron-down-circle-outline' color='white' size={20} style={{
                flex: 1,
                justifyContent: "center"
              }}></Icon> */}
            </View>
          </ImageBackground>

        </View>
        <View style={{ flexDirection: 'row', padding: 5 }}>
          <View style={{ flex: 1, backgroundColor: '#D3D3D3', }}>
            <Card style={{ padding: 0 }} onPress={() => navigation.navigate('ProductDetails')} >
              <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvVtfobIs4cFNc5JhwV0XbdvMh93dpGWFuAQ&usqp=CAU" }}
                style={styles.ProductCardsImage} resizeMode='cover'
                onPress={() => navigation.navigate('ProductDetails')} />
              <Text style={styles.ProductCardsTitle}>Find the best Used Headphones!</Text>
              <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>

              <Rating
                style={{ marginVertical: 5, }}
                ratingColor='red'
                ratingBackgroundColor='#c8c7c8'
                type='star'
                ratingCount={5}
                imageSize={20}
              />
            </Card>
          </View>
          <View style={{ flex: 1 }}>
            <Card >
              <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQdqKSVbGpiW7ZaqycSRJQSGsB4b80dh8DmQA&usqp=CAU" }}
                style={styles.ProductCardsImage} resizeMode='cover'
                onPress={() => navigation.navigate('ProductDetails')} />
              <Text style={styles.ProductCardsTitle}>Find the best For Winter! Used For Winter</Text>
              <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>

              <Rating
                style={{ marginVertical: 5, }}
                ratingColor='red'
                ratingBackgroundColor='#c8c7c8'
                type='star'
                ratingCount={5}
                imageSize={20}
              />
            </Card>
          </View>

        </View>
        <View style={{ flexDirection: 'row', padding: 5 }}>
          <View style={{ flex: 1, }}>
            <Card  >
              <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS7L7xgAK_GVO53GMrPn1mqbb0YYVKgSvMFNw&usqp=CAU" }}
                style={styles.ProductCardsImage} resizeMode='cover'
                onPress={() => navigation.navigate('ProductDetails')} />
              <Text style={styles.ProductCardsTitle}>FPV cameras are typically used for racing</Text>
              <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>

              <Rating
                style={{ marginVertical: 5, }}
                ratingColor='red'
                ratingBackgroundColor='#c8c7c8'
                type='star'
                ratingCount={5}
                imageSize={20}
              />
            </Card>
          </View>
          <View style={{ flex: 1 }}>
            <Card >
              <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7x4XkEa4Yvbt4lTRXCvS-OzVcDFq7z716wA&usqp=CAU" }}
                style={styles.ProductCardsImage} resizeMode='cover'
                onPress={() => navigation.navigate('ProductDetails')} />
              <Text style={styles.ProductCardsTitle}>Capture great Boys Tops, Shirts & T-Shirts</Text>
              <Text style={styles.ProductCardsPrice}>Rs.1,000 - Rs. 5,000</Text>

              <Rating
                style={{ marginVertical: 5, }}
                ratingColor='red'
                ratingBackgroundColor='#c8c7c8'
                type='star'
                ratingCount={5}
                imageSize={20}
              />
            </Card>
          </View>

        </View>
        {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
        <View >
        </View>
      </ScrollView>


    </SafeAreaView>
  );
}

export default ProductList;
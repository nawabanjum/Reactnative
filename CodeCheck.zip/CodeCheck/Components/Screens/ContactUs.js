// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, Avatar } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId } from '../Common/IDs';
import styles from '../Common/CommonStyles';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
import { Card } from 'react-native-paper';
/////////////////////////////////////////////////////////////
function ContactUs() {
    const navigation = useNavigation();

    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ScrollView style={{ padding: 15 }}>
                <Text style={{ paddingLeft:10, fontWeight: 'bold',fontSize:14 }}>Call Us</Text>
                <Text style={{ padding: 10, fontWeight: '100', color: '#2088dd', fontSize: 12 }}>
                    Our sales office is open from 10:00 AM to 8:00 PM.
                 </Text>
                <Text style={{ padding: 10, paddingTop: 0, paddingBottom: 20, fontWeight: '100', color: '#2088dd', fontSize: 12 }}>
                    From Monday to Friday where our dedicated team are on hand to take your call.                    </Text>
                <Text style={{ paddingLeft:10, fontWeight: 'bold' ,fontSize:14 }}>Phone:</Text>
                <Text style={{ padding: 10, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                +92-42-3765-3990    +92-42-3766-7044
                </Text>
                <Text style={{ paddingLeft:10, fontWeight: 'bold' ,fontSize:14 }}>Fax:</Text>
                <Text style={{ padding: 10, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                +92-42-3763-7537
                </Text>
                <Text style={{ paddingLeft:10, fontWeight: 'bold' ,fontSize:14 }}>Email:</Text>
                <Text style={{ padding: 10, fontWeight: '100', color: 'blue', fontSize: 12 }}>
                info@fazalsons.com
                </Text>
                <Text style={{ padding: 10, fontWeight: '100', color: 'grey', fontSize: 14 }}>
                Fazal Sons 25-Brandreth Road, Lahore-54000, Pakistan.
                 </Text>
            </ScrollView>
        </SafeAreaView>
    );
}

export default ContactUs;

{/* <Icon color='green' size={20} name='ios-checkmark-sharp' /> */ }
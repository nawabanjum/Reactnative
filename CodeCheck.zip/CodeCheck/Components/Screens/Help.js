import React from 'react';
import { StyleSheet, Text, View, Dimensions } from 'react-native';
import { WebView } from 'react-native-webview';
import { Component, useState, useEffect } from "react";
import { bannerAdUnitId,adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
const Help = ({ route }) => {
    // useEffect(() => {
    //     const eventListener = interstitial.onAdEvent(type => {
    //         if (type === AdEventType.LOADED) {

    //             interstitial.show();
    //         }
    //     });

    //     // Start loading the interstitial straight away
    //     interstitial.load();

    //     // Unsubscribe from events on unmount
    //     return () => {
    //         eventListener();
    //     };
    // }, []);
    return (
        <View style={{
            flex: 1,
            marginTop: 10
        }}>
            
            <View style={{
                width: "100%",
                height: "90%"
            }}>
                <WebView
                    allowsFullscreenVideo
                    allowsInlineMediaPlayback
                    mediaPlaybackRequiresUserAction
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                    source={{ uri: 'https://www.youtube.com/channel/UCVznarIGi1laaY46zTUy-1w' }}
                />

            </View>
            <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                />
            
        </View>
    )
}

export default Help
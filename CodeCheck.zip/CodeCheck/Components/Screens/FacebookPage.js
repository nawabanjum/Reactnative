import React from 'react';
import { StyleSheet, Text, View, Dimensions } from 'react-native';
import { WebView } from 'react-native-webview';
import { Component, useState, useEffect } from "react";
import { bannerAdUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
const FacebookPage = ({ route }) => {

    // const {itemId,title} = route.params
    return (
        <View style={{
            flex: 1,
            marginTop: 10
        }}>
            
            <View style={{
                width: "100%",
                height: "90%"
            }}>
                <WebView
                    allowsFullscreenVideo
                    allowsInlineMediaPlayback
                    mediaPlaybackRequiresUserAction
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                    source={{ uri: 'https://www.facebook.com/fun2freshdotcom' }}
                />

            </View>
            <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    //onAdFailedToLoad={error => console.log(error)}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                />
            
        </View>
    )
}

export default FacebookPage
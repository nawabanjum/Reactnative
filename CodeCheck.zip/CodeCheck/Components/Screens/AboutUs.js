// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, Avatar } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId } from '../Common/IDs';
import styles from '../Common/CommonStyles';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
import { Card } from 'react-native-paper';
/////////////////////////////////////////////////////////////
function HowWorks() {

    const navigation = useNavigation();

  
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ScrollView style={{ padding: 15 }}>
                <Text style={{ textAlign: 'justify', paddingTop: 10, paddingBottom: 20, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                    Fazal Sons is a market leading company that distributes fixings, fasteners, power tools, and all associated consumables to the construction and civil engineering industries in the Pakistan. We offer brand name products and an unrivalled delivery service that includes same day/next day deliveries throughout the Pakistan with competitive prices for our valued customers, which establish us a key partner in their supply chain.
                </Text>
                <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>Terms & Conditions</Text>

                <Text style={{ textAlign: 'justify', paddingTop: 10, paddingBottom: 20, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                    Fazal Sons , which expression shall include its affiliates (“The Company”), will only use information collected about you in accordance with current Pakistan Data Protection statutes and any other applicable legislation. The Company may collect personal information from visitors to this Website through usage of the Website (for example in cookies) and, when you email the Company, your details for the purpose of registration i.e. name, postal address and email address. The Company may process information collected via this Website for the purposes of i) providing the Company’s services 2) answering your queries 3) dealing with your order(s) and account(s) and 4) providing you with information about products and services. You may opt-out by emailing the Company at the following address: info@fazalsons.com Or by using the ‘unsubscribe’ link present on all our email marketing messages. The Company may also use and disclose information in aggregate (so that no individuals may be identified) for marketing and strategic development purposes. We do not send random marketing emails to personal email addresses (spam).
                </Text>
                <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>Disclosure</Text>
                <Text style={{ textAlign: 'justify', paddingTop: 10, paddingBottom: 20, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                    The Company does not disclose information about you or your business to any third parties unless required to do so by government bodies and law enforcement agencies.
                  </Text>
                <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>Links</Text>
                <Text style={{ textAlign: 'justify', paddingTop: 10, paddingBottom: 20, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                    This Website may contain links to other websites which are outside the Company’s control and are not covered by this privacy policy. If you access other sites using the links provided, the operators of these sites may collect information from you which will be used by them in accordance with their own privacy policy.                  </Text>
                <Text style={{ textAlign: 'center', fontWeight: 'bold' }}>Access Right</Text>
                <Text style={{ textAlign: 'justify', paddingTop: 10, paddingBottom: 30, fontWeight: '100', color: 'grey', fontSize: 12 }}>
                    You have a right to access the personal data held about you. To obtain a copy of the personal information held about you by the Company, please contact us at <Text style={{color:'#2088dd'}}>info@fazalsons.com</Text> </Text>
            </ScrollView>
        </SafeAreaView>
    );
}

export default HowWorks;

{/* <Icon color='green' size={20} name='ios-checkmark-sharp' /> */ }
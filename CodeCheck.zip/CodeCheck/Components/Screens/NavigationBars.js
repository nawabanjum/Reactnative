// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput ,BackHandler} from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, BottomSheet, ListItem } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { Card, Title, Paragraph } from 'react-native-paper';
import { bannerAdUnitId } from '../Common/IDs';
////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';

function Navigationbars() {
    //onPress={
    //() => { this.functionOne(); this.functionTwo(); }
    //}

    const navigation = useNavigation();
    const [isVisible, setIsVisible] = useState(true);
    function logout() {
        (async () => {


            try {

                await AsyncStorage.clear()
            } catch (error) {
                // Error retrieving data
                console.log(error.message);
            }

        })();
        global.LoginDetail = null;
        navigation.navigate('Login');
    };
    function backPressed (){
        Alert.alert(
          'Exit App',
          'Do you want to exit?',
          [
            {text: 'No', style: 'cancel'},
            {text: 'Yes', onPress: () => BackHandler.exitApp()},
          ],
          { cancelable: false });
          return true;
      }
    const list = [
        {
            title: "ANCHOR",
            icon: 'md-build',
            // onPress: () => {
            //     navigation.navigate('DonateStack', { screen: 'DonateGoods' });
            // }
        },
        // {
        //     title: 'Daily Diary',
        //     icon: 'book',
        //     onPress: () => {
        //         if (global.LoginDetail == null || global.LoginDetail == undefined) {
        //             navigation.navigate('SubmitGuest')
        //         } else {
        //             navigation.navigate('DairyStack', { screen: 'DailyDairy' })
        //         }
        //     }
        // },
        {
            title: "BOLT",
            icon: 'md-lock-open',
            // onPress: () => {
            //     navigation.navigate('ProductListStack', { screen: 'ProductList' });
            // }
        },
        // {
        //     title: 'Picture of the Month',
        //     icon: 'image',
        //     // onPress: () => {
        //     //     if (global.LoginDetail == null || global.LoginDetail == undefined) {
        //     //         navigation.navigate('SubmitGuest'); setIsVisible(false)
        //     //     } else {
        //     //         navigation.navigate('AddHandiCrafts'); setIsVisible(false)
        //     //     }
        //     // }
        // },
        {
            title: 'CLUMPS',
            icon: 'ios-magnet',
           // onPress: () => { navigation.navigate('ArchiveProducts') }
        },
        {
            title: 'HOOK',
            icon: 'md-ellipse',
            // onPress: () => {
            //     navigation.navigate('CanDonate');
            // }
        },
        {
            title: 'LOCKS',
            icon: 'md-lock-open',
            // onPress: () => {
            //     navigation.navigate('WorkStack', { screen: 'HowWorks' });
            // }
        },
        // {
        //     title: 'About Donation',
        //     icon: 'shield',
        //     onPress: () => { navigation.navigate('DonationsPolicy') }
        // },
        {
            title: 'FOUNDATION BOLT ',
            icon: 'md-hammer',
           // onPress: () => { navigation.navigate('DonationsPolicy') }

        },
        {
            title: 'MACHINE SCREW ',
            icon: 'md-settings',
            // onPress: () => { navigation.navigate('PrivacyPolicy') }
        },
        {
            title: 'HEX NUTS ',
            icon: 'ios-logo-xing',
            titleStyle: { color: 'black' },
            // onPress: () => { navigation.navigate('NewStack', { screen: 'WhatsNew' }) }
        },
        {
            title: 'SHEET METAL SCREW ',
           icon: 'md-shapes-sharp',
            // onPress: () => { navigation.navigate('PrivacyPolicy') }
        },
        {
            title: 'SOCKET SCREW ',
            icon: 'ios-logo-twitch',
            // onPress: () => { navigation.navigate('PrivacyPolicy') }
        },
        {
            title: 'My Profile ',
            icon: 'ios-person-circle',
            onPress: () => {
                if (global.LoginDetail == null || global.LoginDetail == undefined) {
                    navigation.navigate('LoginStack')
                } else {
                    navigation.navigate('ProfileStack')
                }
            }
        },
        {
            title: 'Log Out ',
            icon: 'md-log-in',
            onPress: () => logout()
        },
        
        {
            title: 'Close this App',
            icon: 'md-power',

            containerStyle: { backgroundColor: 'grey' },
            titleStyle: { color: 'black' },
            onPress: backPressed,
        },
    ];

    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
            // Alert.alert('Refreshed');
            setIsVisible(true);
        });
        return unsubscribe;

    }, [navigation])


    return (
        <SafeAreaView style={{ flex: 1, padding: 10, backgroundColor: 'white' }}>
            <ScrollView>
                {list.map((l, i) => (
                    <ListItem key={i} containerStyle={{ padding: 10, paddingHorizontal: 5 }} onPress={l.onPress}>
                        <Icon size={16} style={l.titleStyle} name={l.icon} />
                        <ListItem.Content>
                            <ListItem.Title style={[l.titleStyle,{fontSize:14}]}>{l.title}</ListItem.Title>
                        </ListItem.Content>
                    </ListItem>
                ))}
                {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
            </ScrollView>

        </SafeAreaView>
    );
}

export default Navigationbars;
// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Button, Card, Title, Paragraph } from 'react-native-paper';
import Icon from "react-native-vector-icons/AntDesign";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ListItem, Avatar } from 'react-native-elements';
import styles from '../Common/CommonStyles';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId,adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
/////////////////////////////////////////////////////////////

function DailyDairy() {
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [Remarks, SetRemarks] = useState('');
    const [isLoading, SetLoading] = useState(false);

    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
            SetLoading(true);
            DisplayAds();
            var url = BASE_URL + "ApiCommon/SearchUserDairy?userid="+global.LoginDetail.Users_ID+"&text="+Remarks;
            axios.post(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert('Alert', "No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
        });
        return unsubscribe;

    }, [navigation]);
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    const Submit = (text) => {
   
        // if(!Remarks)
        // {
        //   Alert.alert("Field Validation", "Please type something!")
        //   return false;
        // }
        SetLoading(true);
        var url = BASE_URL + "ApiCommon/SearchUserDairy?userid=10083&text="+text;
            axios.post(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert('Alert', "No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
      }


    const ItemView = ({ item, index }) => {
        return (
            // Flat List Item
            <ListItem bottomDivider key={index}>
                <ListItem.Content>
                    <ListItem.Title>{item.Description}</ListItem.Title>
                    <ListItem.Subtitle style={{ fontSize: 12 }}>{item.PostedDate}</ListItem.Subtitle>
                </ListItem.Content>
            </ListItem>
            //
            // <View style={{ flex: 1, padding: 5 }}>
            //     <Card style={{ borderRadius: 20 }}
            //        key={index}>
            //         <Card.Content style={{ alignItems: "center" }}>
            //             <Card.Content >
            //                 <Title style={{ fontSize: 12, padding: 5, textAlign: 'center', borderBottomWidth: 0.3, borderBottomColor: 'grey' }} >{item.PostedDate} </Title>
            //                 <Paragraph numberOfLines={3} style={{ fontSize: 8, color: 'grey', textAlign: 'center' }} >{item.Description} </Paragraph>
            //             </Card.Content>
            //         </Card.Content>
            //     </Card>
            // </View>
        );
    };

    return (
        <SafeAreaView style={{ flex: 1, padding: 4 }}>
            <ScrollView>
            <BannerAd
                unitId={bannerAdUnitId}
                size={BannerAdSize.ADAPTIVE_BANNER}
                requestOptions={{
                    requestNonPersonalizedAdsOnly: true,
                }}
            />
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <Card>
                <View style={{ flexDirection: 'row', padding: 5 }}>

                    <TextInput
                        style={{ height: 40, borderColor: 'gray', borderWidth: 1, flex: 2, marginVertical: 15, paddingLeft: 15 }}
                        onChangeText={(text) => Submit(text)}
                       // value={Remarks}
                        placeholder='Search here..'

                    //value={value}
                    />
                </View>

            </Card>
            <FlatList
                data={Data}
                keyExtractor={(item, index) => index.toString()}     //has to be unique   
                renderItem={ItemView} //method to render the data in the way you want using styling u need
            />
            </ScrollView>
        </SafeAreaView>
    );
}

export default DailyDairy;
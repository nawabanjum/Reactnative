// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput, ActivityIndicator, Linking } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import styles from '../Common/CommonStyles';
import { bannerAdUnitId, adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
/////////////////////////////////////////////////////////////
function SubmitFeedback() {
    const [email, Setemail] = useState('');
    const [Name, SetName] = useState('');
    const [Phone, SetPhone] = useState('');

    const [Comment, SetComment] = useState('');

    const [isLoading, SetLoading] = useState(false);

    const navigation = useNavigation();
    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
            // DisplayAds();

        });
        return unsubscribe;

    }, [navigation]);


    function submit() {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (Name == '' || Phone == '' || Comment == '') {
            Alert.alert("", "Please enter your name and comments");
            // Setemail( text )
            return false;
        } else
            if (reg.test(email) === false) {
                Alert.alert("", "Please enter your name and comments");
                // Setemail( text )
                return false;
            }
        SetLoading(true);

        const model = {

            FeedBack_ID: 0,
            Name: Name,
            Email: email,
            Phone: Phone,
            Comments: Comment,

        };
        try {
            axios.post(BASE_URL + 'ApiCommon/SuggestionsAndFeedback', { model: model })

                .then(response => {
                    //console.log(response.data.Message)
                    SetLoading(false);
                    Alert.alert('', 'Your feedback sent successfully');
                    navigation.navigate('Home');
                }, (error) => {
                    SetLoading(false);
                });
        } catch (error) {
            // handle error
            SetLoading(false);
            Alert.alert("Internal Server Error", error.message)

        }
    }
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <ScrollView style={{ padding: 15 }}>
                {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
                <View >
                    {/* <Image style={{ height: 25, width: 100, alignSelf: 'center' }} source={require('../Icons/logo.png')}></Image> */}
                    <Text style={styles.labelStyle}>Name </Text>
                    <TextInput
                        style={[styles.TextInput, { marginTop: 10 }]}
                        onChangeText={(text) => SetName(text)}
                        placeholder='Name'

                    //value={value}
                    />
                    <Text style={styles.labelStyle}>Email </Text>
                    <TextInput
                        style={[styles.TextInput, { marginVertical: 10 }]}
                        onChangeText={(text) => Setemail(text)}
                        placeholder='Email'

                    //value={value}
                    />
                    <Text style={styles.labelStyle}>Phone No. </Text>
                    <TextInput
                        style={[styles.TextInput, { marginVertical: 10 }]}
                        onChangeText={(text) => SetPhone(text)}
                        placeholder='Phone No.'

                    //value={value}
                    />
                    <Text style={styles.labelStyle}>Comments </Text>
                    <TextInput
                        style={[styles.TextInput, { marginVertical: 10 }]}
                        onChangeText={(text) => SetComment(text)}
                        placeholder='Comments'

                    //value={value}
                    />

                    <View style={{ flexDirection: 'row', marginVertical: 10, marginBottom: 20 }}>
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="Submit"
                            titleStyle={{ fontSize: 12 }}
                            type="outline"
                            onPress={() => submit()}
                        />
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="Cancel"
                            titleStyle={{ fontSize: 12, color: 'grey' }}
                            type="outline"
                            onPress={() => navigation.goBack()}
                        />

                    </View>
                    {/* <Button containerStyle={{ borderRadius: 20, height: 40 }} onPress={() => submit()}
                        title="Submit"
                    // disabled={(FirstName == '' || LastName == '' || email == '' || password == '' || ConfirmPassword == '') ? true : false}

                    />
                    <Button containerStyle={{ borderRadius: 20, height: 40, marginVertical: 15 }} onPress={() => navigation.goBack()}
                        title="Cancel"
                    // disabled={(FirstName == '' || LastName == '' || email == '' || password == '' || ConfirmPassword == '') ? true : false}

                    /> */}
                    {/* <Text style={{ textAlign: 'center', color: 'grey', fontSize: 12, padding: 20 }} onPress={() => Linking.openURL(`tel:${+923004761693}`)}>For feedback & suggestions, You can call or Whatsapp us on<Text style={{ color: 'orange', fontSize: 12, padding: 20 }} onPress={() => Linking.openURL(`tel:${+923004761693}`)}> +92 300 4761693</Text></Text>
                    <Text style={{ textAlign: 'center', color: 'grey', fontSize: 12, padding: 10 }}>Join our Whatsapp group for Help and latest update!!!<Text style={{ color: 'orange', fontSize: 12, padding: 10 }} onPress={() => Linking.openURL('https://chat.whatsapp.com/I4tbeR70BLO7m0C67iMoNW')}>{'\n'} https://chat.whatsapp.com/I4tbeR70BLO7m0C67iMoNW</Text></Text>
                    <Text style={{ textAlign: 'center', color: '#2088dd', fontWeight: 'bold', flex: 1 }} onPress={() => navigation.navigate('FacebookPage')}>Find us on facebook</Text> */}

                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default SubmitFeedback;
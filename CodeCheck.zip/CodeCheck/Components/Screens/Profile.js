// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, Linking, Image, Alert, ActivityIndicator, FlatList, BackHandler, ImageBackground } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import { SafeAreaView } from 'react-native';
import { Card, Title, Paragraph, Caption, DataTable } from 'react-native-paper';
import { Input, Button, BottomSheet, ListItem ,Avatar} from 'react-native-elements';
import { BASE_URL } from '../Common/Urls';
import { LoaderColor } from '../Common/StaticColors';
import axios from 'axios';
import AsyncStorage from '@react-native-community/async-storage';
import styles from '../Common/CommonStyles';
import { bannerAdUnitId, adUnitId } from '../Common/IDs';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
const image = { uri: "https://i.pinimg.com/originals/3c/24/46/3c24462450c2a902bf7e18f3d9aada81.jpg" };

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);

const Tab = createMaterialTopTabNavigator();
function MYRequests() {
    return (
        <View>
            <View style={{ flexDirection: 'row', backgroundColor: 'lightgrey' }}>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiyzJ2WkoARUvHQxB2RfRqeNbAEWAA_KyLSg&usqp=CAU" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'green', fontSize: 12 }}>Approved</Text></Text>
                        </View>

                    </Card>

                </View>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhOsKXd0Sbacs0bYjPJRx5srEqRWDVq4pQwQ&usqp=CAU" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'orange', fontSize: 12 }}>Pending</Text></Text>
                        </View>
                    </Card>
                </View>

            </View>
            <View style={{ flexDirection: 'row', backgroundColor: 'lightgrey' }}>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSiyzJ2WkoARUvHQxB2RfRqeNbAEWAA_KyLSg&usqp=CAU" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'green', fontSize: 12 }}>Approved</Text></Text>
                        </View>
                    </Card>

                </View>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQhOsKXd0Sbacs0bYjPJRx5srEqRWDVq4pQwQ&usqp=CAU" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'green', fontSize: 12 }}>Approved</Text></Text>
                        </View>
                    </Card>
                </View>

            </View>
            <View style={{ flexDirection: 'row', backgroundColor: 'lightgrey' }}></View>

        </View>
    );
}

function Donates() {
    return (
        <View>
            <View style={{ flexDirection: 'row', backgroundColor: 'lightgrey' }}>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://www.mymove.com/wp-content/uploads/2018/12/donation-box.jpg" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'green', fontSize: 12 }}>Approved</Text></Text>
                        </View>
                    </Card>

                </View>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://www.arizonagaragedesign.com/hubfs/shutterstock_146716256.jpg" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'orange', fontSize: 12 }}>Pending</Text></Text>
                        </View>
                    </Card>
                </View>

            </View>
            <View style={{ flexDirection: 'row', backgroundColor: 'lightgrey' }}>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/donations-box-royalty-free-image-1585255302.jpg" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'red', fontSize: 12 }}>Deleted</Text></Text>
                        </View>
                    </Card>

                </View>
                <View style={{ flex: 1, backgroundColor: '#D3D3D3', margin: 10 }}>
                    <Card >
                        <Image source={{ uri: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTiKvP7IBIm-ULkfQaIkpLcETOYBlE50KEn0w&usqp=CAU" }}
                            style={{ flex: 1, aspectRatio: 1 }} resizeMode='contain' />
                        <View style={{ padding: 5 }}>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Power Bank 2870mah</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>18 march,2020</Text>
                            <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}>Status: <Text style={{ marginTop: 5, color: 'orange', fontSize: 12 }}>Pending</Text></Text>
                        </View>
                    </Card>
                </View>

            </View>

        </View>
    );
}
function Profile({ route }) {
    const navigation = useNavigation();
    const [Data, SetData] = useState([]);
    const [ReferralData, SetReferralData] = useState([]);
    const [RewardsData, SetRewarsData] = useState([]);
    const [Id, SetId] = useState();
    const [isLoading, SetLoading] = useState(false);
    var sum = RewardsData.reduce((accumulator, current) => accumulator + current.RewardsPoints, 0);
    const users = [
        {
            itemNumber:11,
            ItemName: 'BOLT',
            ItemSizs: '2.3',
            uri: 'https://uk.rs-online.com/euro/img/solutions/scretform.jpg',
            Price:' Rs. 400',
            Qunantity:'10',
            color:'green'
        },{
            itemNumber:12,
            ItemName: 'HOOK',
            ItemSizs: 'NA',
            uri: 'https://s.alicdn.com/@sc01/kf/Hac638f45994c4c0688f6413e418b44ce2.jpg',
            Price:' Rs. 1,000',
            Qunantity:'10',
            color:'green'
        },{
            itemNumber:13,
            ItemName: 'Hex Nuts',
            ItemSizs: 'NA',
            uri: 'https://image.made-in-china.com/2f0j00PEtGTdSCYbgn/Tool-Auto-Parts-High-Quality-Fastener-Spare-Parts-Hex-Head-Nut.jpg',
            Price:' Rs. 500',
            Qunantity:'5',
            color:'green'
        },
    ]
   
    useEffect(() => {

        // (async () => {


        //     try {

        //         let Users_ID = await AsyncStorage.getItem('Logged_UserId')
        //         SetId(Users_ID)
        //     } catch (error) {
        //         // Error retrieving data

        //     }

        // })();
        const unsubscribe = navigation.addListener('focus', () => {
            SetLoading(true);
            //DisplayAds();
            AsyncStorage.getItem('Logged_UserId').then(
                (value) => {
                    // AsyncStorage returns a promise
                    // Adding a callback to get the value
                    // console.log('GetId:' + value)
                    // Setting the value in Text
                    axios.post(
                        BASE_URL + "ApiCommon/GetUserById?Id=" + value
                    )
                        .then(response => {
                            SetLoading(false);
                            if (response.data == null) {
                                Alert.alert("No Record Found ")
                            }
                            else {
                                SetLoading(false);
                                SetData(response.data.Data)


                            }
                        }).catch((error) => {
                            SetLoading(false);
                            Alert.alert("Internal Server Error", error.message)
                        })
                    axios.post(
                        BASE_URL + "ApiCommon/RewardsListByUserId?userId=" + value
                    )
                        .then(response => {
                            SetLoading(false);
                            if (response.data == null) {
                                Alert.alert("No Record Found ")
                            }
                            else {
                                SetLoading(false);
                                SetRewarsData(response.data.Data)

                            }
                        }).catch((error) => {
                            SetLoading(false);
                            Alert.alert("Internal Server Error", error.message)
                        });
                    axios.get(
                        BASE_URL + "ApiCommon/MyReferralUsers?id=" + value
                    )
                        .then(response => {
                            SetLoading(false);
                            if (response.data == null) {
                                Alert.alert("No Record Found ")
                            }
                            else {
                                SetLoading(false);
                                SetReferralData(response.data.Data)


                            }
                        }).catch((error) => {
                            SetLoading(false);
                            Alert.alert("Internal Server Error", error.message)
                        });
                }

            );
        });
        return unsubscribe;

    }, [navigation])

    const ItemView = ({ item, index }) => {
        return (
            // Flat List Item   onPress={() => navigation.navigate("WhatsNewDetail", { Id: item.WhatsNewId })}
            <ListItem containerStyle={{ borderRadius: 10, paddingVertical: 5, marginVertical: 5 }} underlayColor='white' bottomDivider key={index}>
                <Avatar size={50} source={{ uri: item.uri }} />
                <ListItem.Content>
                    {/* <ListItem.Title>{item.UserName}</ListItem.Title> */}
                    <ListItem.Title style={{ fontSize: 14 }}>{item.itemNumber}-{item.ItemName}</ListItem.Title>
                    <View style={{ flexDirection: 'row' }}>
                        <ListItem.Subtitle style={{ fontSize: 12,paddingTop:5 ,flex:1}}>Qunantity: {item.Qunantity}</ListItem.Subtitle>
                        <ListItem.Subtitle style={{ fontSize: 12,paddingTop:5 ,flex:1}}>Size: {item.ItemSizs}</ListItem.Subtitle>
                        {/* <Icon color='grey' style={{paddingHorizontal:10}} size={20} name='ios-reader' /> */}
                        <Text style={{ marginTop: 5, color: 'gray', fontSize: 12 }}> <Text style={{ marginTop: 5, color: '#2088dd', fontSize: 12 }}>{item.Price}</Text></Text>
                        {/* <Icon color='grey' style={{paddingHorizontal:10}} size={20} name='bookmark-outline' /> */}
                    </View>
                </ListItem.Content>
                {/* <ListItem.Chevron /> */}
            </ListItem>

        );
    };
    function logout() {
        (async () => {


            try {

                await AsyncStorage.clear()
            } catch (error) {
                // Error retrieving data
                // console.log(error.message);
            }

        })();
        global.LoginDetail = null;
        navigation.navigate('Home');
    };
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    function backPressed() {
        Alert.alert(
            'Exit App',
            'Do you want to exit?',
            [
                { text: 'No', style: 'cancel' },
                { text: 'Yes', onPress: () => BackHandler.exitApp() },
            ],
            { cancelable: false });
        return true;
    }
    return (
        <SafeAreaView style={{ flex: 1 }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color={LoaderColor} animating={isLoading} />
            <ScrollView style={{ padding: 5 }}>
                <View>
                    <Card>


                        <View style={{ flexDirection: 'row', padding: 10 }}>
                            <View style={{ flex: 1, paddingTop: 10 }}>
                                <Avatar containerStyle={{ alignSelf: 'center' }} rounded source={{ uri: 'https://www.atlassian.com/dam/jcr:ba03a215-2f45-40f5-8540-b2015223c918/Max-R_Headshot%20(1).jpg' }} size={80}></Avatar>
                            </View>
                            <View style={{ flex: 2 }}>
                                <View style={{ marginLeft: 15, flexDirection: 'column' }}>
                                    <Title style={{ fontSize: 16 }}>John Wick</Title>
                                    <Caption><Caption >johnwick@gmail.com</Caption></Caption>
                                    <Caption ><Caption >Mechanic</Caption></Caption>
                                    <Caption style={{ color: 'orange', fontWeight: 'bold' }}><Caption >New York, USA</Caption></Caption>
                                </View>
                            </View>

                        </View>
                        <View style={{ flexDirection: 'row', marginVertical: 10 }}>
                            <Button
                                containerStyle={{ flex: 1, margin: 5 }}
                                title="Update Profile"
                                titleStyle={{ fontSize: 12 }}
                                type="outline"
                                //onPress={() => navigation.navigate('UpdateProfile')}
                            />
                            <Button
                                containerStyle={{ flex: 1, margin: 5 }}
                                title="Change Password"
                                titleStyle={{ fontSize: 12 }}
                                type="outline"
                                onPress={() => navigation.navigate('ChangePassword', { Id: Data.Users_ID })}
                            />

                        </View>
                    </Card>

                    <View >
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                            <View>
                                <Text style={styles.HeadingsTitle}>MY QUOTE LIST</Text>
                            </View>
                        </ImageBackground>
                    </View>
                    <FlatList
                    data={users}
                    keyExtractor={(item, index) => index.toString()}     //has to be unique   
                    renderItem={ItemView} //method to render the data in the way you want using styling u need
                />
               
                    {/* <View>
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>

                            <Tab.Navigator initialRouteName="MYRequests" tabBarOptions={{

                                labelStyle: { fontSize: 12, fontWeight: 'bold' },
                                tabStyle: { backgroundColor: 'white' },
                                activeTintColor: 'blue',
                                inactiveTintColor: 'grey',
                            }}>
                                <Tab.Screen
                                    name="MYRequests"
                                    component={MYRequests}
                                    options={{ tabBarLabel: 'MY REQUESTS',
                                    tabBarIcon: ({ color, size }) => (
                            
                                      <Icon name='home' color={color} size={size} />
                                    ), }}
                                />
                                <Tab.Screen
                                    name="Donates"
                                    component={Donates}
                                    options={{ tabBarLabel: 'My Donated Items' }}
                                />

                            </Tab.Navigator>
                        </ImageBackground>

                    </View> */}


                    <Card>
                        <View style={{ flexDirection: 'row', marginVertical: 10 }}>
                            <Button
                                containerStyle={{ flex: 1, margin: 5 }}
                                title="Close This App"
                                titleStyle={{ fontSize: 12 }}
                                type="outline"
                                onPress={backPressed}
                            />
                            <Button
                                containerStyle={{ flex: 1, margin: 5 }}
                                title="LOG OUT"
                                titleStyle={{ fontSize: 12, color: 'red' }}
                                type="outline"
                                onPress={() => logout()}
                            />

                        </View>
                        {/* <View style={{ flexDirection: 'row', marginVertical: 10, marginBottom: 20 }}>
                            <Text style={{ textAlign: 'center', color: '#2088dd', fontWeight: 'bold', flex: 1 }} onPress={backPressed}>CLOSE HELP</Text>

                            <Text style={{ textAlign: 'center', color: 'red', fontWeight: 'bold', flex: 1 }} onPress={() => logout()}>LOG OUT</Text>

                        </View> */}

                    </Card>
                </View>
            </ScrollView>

        </SafeAreaView >
    );
}

export default Profile;
// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput, ActivityIndicator } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, Avatar, Accessory } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
//import { TextInput } from 'react-native-paper';
import DocumentPicker from 'react-native-document-picker';
import styles from '../Common/CommonStyles';
////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
import { bannerAdUnitId, adUnitId } from '../Common/IDs';

function ChangePassword({ route }) {
    const [password, Setpassword] = useState('');
    const [isLoading, SetLoading] = useState(false);
    const { Id } = route.params;
    const navigation = useNavigation();

    // useEffect(() => {
    //     const eventListener = interstitial.onAdEvent(type => {
    //         if (type === AdEventType.LOADED) {

    //             interstitial.show();
    //         }
    //     });

    //     // Start loading the interstitial straight away
    //     interstitial.load();

    //     // Unsubscribe from events on unmount
    //     return () => {
    //         eventListener();
    //     };
    // }, []);
    
    let upload = async () => {
        //Check if any file is selected or not
        if (password.trim() == '' || password == null)
            Alert.alert('', " Password can not be empty.")

        else {
            const Model = {
                uid: Id,
                NewPassword: password
            }
            // console.log('Sending data : ' + JSON.stringify(Model));
            // axios({
            //     url: BASE_URL + 'ApiAccount/UpdateUserPassword',
            //     method: 'POST',
            //     model: Model,
            //     headers: {
            //         Accept: 'application/json',
            //         'Content-Type': 'multipart/form-data'
            //     },
            // })
            SetLoading(true);
            axios.post(BASE_URL + 'ApiAccount/UpdateUserPassword?uid=' + Id + '&NewPassword=' + password)
                .then(function (response) {
                    Alert.alert("", "Your password has been changed successfully.",);
                    Setpassword('');
                    // navigation.goBack();
                    SetLoading(false);
                })
                .catch(function (response) {
                    Alert.alert("Error", "Update failed");
                    SetLoading(false);
                });


        }
        // else{
        // alert("Please Select file.");
        // }
    };


    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            {/* <BannerAd
                unitId={bannerAdUnitId}
                size={BannerAdSize.ADAPTIVE_BANNER}
                //onAdFailedToLoad={error => console.log(error)}
                requestOptions={{
                    requestNonPersonalizedAdsOnly: true,
                }}
            /> */}
            <ScrollView style={{ padding: 15 }}>
                <View >

                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setpassword(text)}
                        placeholder='Old Password'
                        // secureTextEntry={true}
                        value={password}
                    ></TextInput>
                    <TextInput
                        style={[styles.TextInput,{marginVertical:5}]}
                        onChangeText={(text) => Setpassword(text)}
                        placeholder='New Password'
                        // secureTextEntry={true}
                        value={password}
                    ></TextInput>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setpassword(text)}
                        placeholder='Confirm  Password'
                        // secureTextEntry={true}
                        value={password}
                    ></TextInput>
                   
                    <View style={{ flexDirection: 'row', marginVertical: 10, marginBottom: 20 }}>
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="SAVE"
                            titleStyle={{ fontSize: 12 }}
                            type="outline"
                            onPress={() => Alert.alert("", "Your password has been changed successfully.",)}
                        />
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="CANCEL"
                            titleStyle={{ fontSize: 12, color: 'grey' }}
                            type="outline"
                            onPress={() => navigation.goBack()}
                        />

                    </View>


                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default ChangePassword;
// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, Avatar } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId } from '../Common/IDs';
import styles from '../Common/CommonStyles';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
import { Card } from 'react-native-paper';
/////////////////////////////////////////////////////////////
function PrivacyPolicy() {
    const [email, Setemail] = useState('');
    const [FirstName, SetFirstName] = useState('');
    const [LastName, SetLastName] = useState('');

    const [password, Setpassword] = useState('');
    const [ConfirmPassword, SetConfirmPassword] = useState('');
    const [About, SetAbout] = useState('');
    const [ReferralId, SetReferralId] = useState('');
    const [isLoading, SetLoading] = useState(false);

    const navigation = useNavigation();

    function SaveReferral(text) {
        if (text == undefined || text == '') {
            // Alert.alert("Amount must be greater then or equal to zero");
            return false;
        }
        const NON_DIGIT = /^[0-9]+$/;

        NewRefferral = parseFloat(text.toString().replace(NON_DIGIT, ''));
        SetReferralId(NewRefferral)
    }
    function login() {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(email) === false) {
            Alert.alert("Invalid credentials", "Email is Not Valid");
            // Setemail( text )
            return false;
        }

        SetLoading(true);
        try {
            // console.log('res : ' + email + password);

            const response = axios.post(
                BASE_URL + "ApiAccount/UserLogin?Email=" + email + "&Password=" + password
            ).then((response) => {
                SetLoading(false);
                if (response.data.Data === undefined || response.data.Data == null) {
                    Alert.alert("Invalid credentials", "Your Email and Password Not Exist! ")
                }
                else {


                    global.LoginDetail = response.data.Data;
                    // console.log(response.data);
                    (async () => {

                        await AsyncStorage.setItem('Logged_UserId', JSON.stringify(response.data.Data.Users_ID));

                    }

                    )();
                    navigation.navigate('Home');
                }
            }).catch((error) => {
                Alert.alert("Internal Server Error", error.message)
            }).then(function () {

            });



        } catch (error) {
            // handle error

            Alert.alert("Internal Server Error", error.message)
            isLoading(false);

        }
    }
    function submit() {
        if (password != ConfirmPassword) {
            Alert.alert("Field Validation", "Your Password does not match!")
            return false;
        } let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(email) === false) {
            Alert.alert("Invalid credentials", "Please enter valid email");
            // Setemail( text )
            return false;
        }
        SetLoading(true);

        const model = {

            FirstName: FirstName,
            LastName: LastName,
            Email: email,
            Password: password,
            confirmPassword: ConfirmPassword,

            AboutMySelf: About,
            ReferralId: ReferralId,
        };
        //console.log('res : ' + JSON.stringify(model));
        try {
            axios.post(BASE_URL + 'ApiAccount/Register ', { model: model })

                .then(response => {
                    //console.log(response.data)
                    SetLoading(false);
                    if (response.data.IsSuccess == 'Yes') {
                        Alert.alert('Congratulations!', 'You have successfully registered');
                        (async () => {

                            await AsyncStorage.setItem('Email', email);
                            await AsyncStorage.setItem('Password', password);
                            // await AsyncStorage.setItem('UserId', response.data.Data.Users_ID);

                        }

                        )();
                        // navigation.navigate('ProfileStack', { screen: 'UpdateProfile' })

                        login();
                    }
                    else {
                        SetLoading(false);
                        Alert.alert("", 'This Email/Username is already Exist.')
                    }

                }, (error) => {
                    SetLoading(false);
                    // console.log(error);
                });
        } catch (error) {
            // handle error
            SetLoading(false);
            Alert.alert("Internal Server Error", error.message)

        }
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ScrollView style={{ padding: 10 }}>

                <View >
                    {/* <Image style={{ height: 25, width: 100, alignSelf: 'flex-start' }} source={require('../Icons/logo.png')}></Image> */}
                    <Text style={{ textAlign: 'justify', fontWeight: '100', color: 'grey', fontSize: 12 }}>

                    <Icon color='green' size={20} name='ios-checkmark-sharp' /> If you have any comments or questions about our Privacy Policy, feel free to contact us.{'\n'}{'\n'}
                    <Icon color='green' size={20} name='ios-checkmark-sharp' /> Book your charity clothing collection here,{'\n'}{'\n'}
                    <Icon color='green' size={20} name='ios-checkmark-sharp' /> We will accommodate your clothing pick up request for your chosen day, and our Operator will contact you over the phone or by email to confirm your booking,{'\n'}{'\n'}
                    <Icon color='green' size={20} name='ios-checkmark-sharp' /> We will collect Your clothing donations from your home or work address,
                    </Text>

                </View>
               
            </ScrollView>
        </SafeAreaView>
    );
}

export default PrivacyPolicy;
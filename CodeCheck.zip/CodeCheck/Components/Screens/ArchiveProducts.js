// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Button, Card, Title, Paragraph } from 'react-native-paper';
import Icon from "react-native-vector-icons/Ionicons";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ListItem, Avatar } from 'react-native-elements';
import styles from '../Common/CommonStyles';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId, adUnitId } from '../Common/IDs';

import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);
/////////////////////////////////////////////////////////////

function WhatsNew() {
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [isLoading, SetLoading] = useState(false);
    const users = [
        {
            Title: 'Lord & Taylor to relaunch online, with help from RTW Retailwinds',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://etimg.etb2bimg.com/thumb/high-level-meet-to-discuss-e-commerce-policy-on-saturday-size-419850-updated-2021-03-12t09-38-07z/81465546.cms?width=362&height=240',
            Price:'Price range :  Rs.10,000 - Rs. 50,000'
        },
        {
            Title: 'didas aims for DTC to be 50% of sales by 2025',
            Subtitle: 'A new four-year strategy is predicated on doubling e-commerce sales, building up an athleisure offering and refocusing on women, among other things.',
            uri: 'https://www.aseanbriefing.com/news/wp-content/uploads/2018/07/ASEAN-Briefing-Thailands-E-commerce-Landscape-Latest-Trends-and-Opportunities-002.jpg',
            Price:'Price range :  Rs.1,000 - Rs. 5,000'

        },
        {
            Title: 'GameStop taps former Chewy execs to lead transformation group',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxAPDw0NDQ0NDQ0NDQ0ODQ0NDQ8NDQ0NFREWFhURExUYHCggGBolGxMVIT0hJzU3Oi4uFx8/ODUsNygtOisBCgoKDg0OGhAQGjceHx0tKy0tKzUrLTUtLi03NzYtKystKzc3KzcrKy0tKysrLTcrNy0tKystLTc3NDgtLSsrN//AABEIAOEA4QMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAQIDBQYHBP/EAEAQAQABAwIBBwYLBgcAAAAAAAABAgMRBBIGBRMhMUFRYSJxgZGhsgcjMjNSYnOxwcLRJEJjcqLwNFN0k6PS4f/EABgBAQEBAQEAAAAAAAAAAAAAAAAEAgED/8QAHxEBAAEEAgMBAAAAAAAAAAAAAAECAzEyEVESISJB/9oADAMBAAIRAxEAPwD3EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHzco35ot1VR146PP2R+HpBF7lCzRO2u7TFXdnOPP3PooriqIqpmKonqmJzEvj0/J9q3RmummasZuXaojMz2znshz17iXT6a5XFjdeoqjpoojbRFfZVEz6erwcmqIy7FMzh144+jjqn9/TVUx3xcifyt7yZy7Y1HRRVtr+hX0T6O9yK6Z/Wpt1RmGzAaYAAAAAAAAAAAAAAAAAAAAAAGs5auY5mmf3r1mJ/3aP0ls3McXarZNFOfK+LqoiOmZq3TiPZ7AW4h1s13J08T5FuIquR9OuYzFM+ERifT4OOtaeaqq8Rmd1UzM9VNMT1z6+rxba3qKrlVy5Xt3111TVtztznGIz2dBNMWdFevRjnL+qm3TPhETj1eXKefqr2pj5p9Of5Yjm7Vc0VxF3bM0ZmMzPhT2uK0HGWp012I1dudu7orpom3dpx+9HZXHmdtTTEdPbPTMz01VT4z2sGu0Nu/RVbvUU101d8dMeMT2SedOODwqzy9S4a5Vp1els6iiqK4rp+VT1VT3to8y+BimvTzynydXM1W7F2zqNPVP+XeiqJj128+eZ73pr3jCecgDrgAAAAAAAAAAAAAAAAAAAA8x445QmjU6yuOuxZpot+EzTTET665enPK/hM0U06qqZnFvW2cbp6qblMRT+WifTIL8PVZ09ievNq3OZ6c5phm5TvfEWbXZF+/V6cU/wDaXz8PUzTp7FNUYqptW4qjumKYiYU11XlY7q6/uoTdqunzgMPR0/wf0Rz2qqx0zasRM98RVX+rt3EcAz8df+yp9lX/AK7dTb1SXNpAG2AAAAAAAAAAAAAAAAAAAABoOKuSKNVzMXombNNVXOTT0VUxMRiqJ7OpvwHmmksxa3WqKpqotVV26aqvlVU0ziKp8ZiHwav5dX89Xu0Nvqv8Rqv9Rf8AflqdVHlVfaV+7bTdqumJASw9HTcBz8fd+x/NH6u5cJwJP7Tcj+BV79Du1NvVLd2AG3mAAAAAAAAAAAAAAAAAAAAAA8713+J1X2933ml1PztyMzjMzjPRnojPsj1N3yn0arVfa1NJqfna/wC+5JVlZThBJKJcadNwHH7RcnusT7a6f0d04bgL5+99jHvw7lRb1S3dgB6PMAAAAAAAAAAAAAAAAAADKMgkRkyDz3lro1mqj+JE+uimWk1XztX99je8QxjW6nx5uf8AipaHVfOz6PuSV5WUYhAgZadVwBHxuonutUR66p/R27jPg/p8rUz9WzHtqdmqt6pbuwA28wAAAAAAAAAEZEAJRlGTIJyZRlGQWMq5RkF8oUybgXyZY9xuBxHFEY1tz61u1P8ATj8HO6ufjfRH3S6Xi6P2umfpaej2V1w5nWfOR5o+5LXsrt6oAYbdp8H9Pkamr69un1UzP4uscxwHTjT3Z+lfn2UUumyqo1hJc2lYViUtsLCISAAAAAAAACMIwsAphDIgGNWWXBtBhmUZZpoVm2DDNSJqZJtKVWpBTejnEVW5Ya4kHO8YU/GaevvouUT6JiY96XK6yfLjzU/e7PiDTzdszERmu3MXKI75jOafTEz6cOG1FeZifD2wmux7VWp9Moxc/T25j0TP3HPZxFETVMziOjrnzdbzej0TgynGkpn6Vy7P9WPwb6Gu5D0s2dPYtVfKptxv/nnpq9sy2UTHespjiEdU8zK0LQpvjvRzsd7rLIlh56GSirMZBYAAAAAAAFNyN7HlGQZN5vYpVyDNziOdYVZBn55HPsCswD6J1Cs6qHzzCNoMlWrjuYa9V9VPNkWQfDfrmrqplz/KXDNd6qa6KqbdUzmc0zO6e+el2NFiGam05McuxPGHnMcG6ntu28eFE/q2vJXDdyxVvzurjqmYjo83c7amheKIciiIdmuZaCmm/HbK0Td7ZlvZtwrNmGmWmiuvtyvFdTZzp47lJ08A+GKqn025nDJFhk5sFIuT3yvF2rvNidoLRenwWi94Me1O0GWLseKYrhhwnAM26O8YcAKyhbACqMLYMAphGGTBgGPajay4NoMWxOxl2m0GLYtFDJEJiAVppWiFohIIhYSAABgwkBXBhYBTabVgFNphcBTBhbBgFcIXwAxGGTYbAUwL7DYCmDC+w2gpgwvtNoK4ML7TaCuDC20wCIhKcGAAASAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//2Q=='
           , Price:'Price range :  Rs.2,000 - Rs. 5,000'
        
        },
        {
            Title: 'Why Nordstrom has gone all-in on DTC brands',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_omS2xw4RY_KnAWupqw7qD02aDWL8gS0FJg&usqp=CAU',
            Price:'Price range :  Rs.1,000 - Rs. 5,000'

        },
        {
            Title: 'Lord & Taylor to relaunch online, with help from RTW Retailwinds',
            Subtitle: 'The Saadia Group bought the 200-year-old department store and its owner, rental site Le Tote, for $12 million at an October bankruptcy auction.',
            uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSInj2iJzDxIsKUyIPza72jqvh0bi2kI2t2NQ&usqp=CAU',
            Price:'Price range :  Rs.1,000 - Rs. 5,000'

        }

    ]
    useEffect(() => {

        const unsubscribe = navigation.addListener('focus', () => {
            SetLoading(true);
            // DisplayAds();
            var url = BASE_URL + "ApiCommon/GetWhatsNewList";
            axios.get(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
        });
        return unsubscribe;

    }, [navigation])
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    const ItemView = ({ item, index }) => {
        return (
            // Flat List Item   onPress={() => navigation.navigate("WhatsNewDetail", { Id: item.WhatsNewId })}
            <ListItem containerStyle={{ borderRadius: 10, paddingVertical: 5, marginVertical: 5 }} underlayColor='white' bottomDivider key={index}>
                <Avatar size={60} source={{ uri: item.uri }} />
                <ListItem.Content>
                    {/* <ListItem.Title>{item.UserName}</ListItem.Title> */}
                    <ListItem.Title style={{ fontSize: 14 }}>{item.Title}</ListItem.Title>
                    <View style={{ flexDirection: 'row' }}>
                        <ListItem.Subtitle style={{ fontSize: 12,paddingTop:5 ,flex:1}}>{item.Price}</ListItem.Subtitle>
                        {/* <Icon color='grey' style={{paddingHorizontal:10}} size={20} name='ios-reader' /> */}
                        <Icon color='grey' style={{paddingHorizontal:10}} size={20} name='bookmark-outline' />
                    </View>
                </ListItem.Content>
                {/* <ListItem.Chevron /> */}
            </ListItem>

        );
    };

    return (
        <SafeAreaView style={{ flex: 1, padding: 5 }}>
            <ScrollView>
                {/* <BannerAd
                    unitId={bannerAdUnitId}
                    size={BannerAdSize.ADAPTIVE_BANNER}
                    requestOptions={{
                        requestNonPersonalizedAdsOnly: true,
                    }}
                /> */}
                <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
                <FlatList
                    data={users}
                    keyExtractor={(item, index) => index.toString()}     //has to be unique   
                    renderItem={ItemView} //method to render the data in the way you want using styling u need
                />
            </ScrollView>
        </SafeAreaView>
    );
}

export default WhatsNew;
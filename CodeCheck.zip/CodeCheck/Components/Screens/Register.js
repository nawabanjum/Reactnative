// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, TextInput, ImageBackground, TouchableOpacity } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, CheckBox } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId } from '../Common/IDs';
import styles from '../Common/CommonStyles';

import { Picker } from '@react-native-picker/picker';
import DateTimePicker from '@react-native-community/datetimepicker';
////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function Register() {
    const [email, Setemail] = useState('');
    const [FirstName, SetFirstName] = useState('');
    const [LastName, SetLastName] = useState('');

    const [password, Setpassword] = useState('');
    const [ConfirmPassword, SetConfirmPassword] = useState('');
    const [About, SetAbout] = useState('');
    const [ReferralId, SetReferralId] = useState('');
    const [isLoading, SetLoading] = useState(false);

    const [Checked, setChecked] = useState(false);
    const [SelectedPreference, SetSelectedPreference] = useState();
    ////////////////////date

    const [date, setDate] = useState(new Date());
    const [dateIn, setdateIn] = useState(new Date());
    const [dateOut, setDateOut] = useState(new Date());
    const [showDate, setshowDate] = useState(false);
    const [showIn, setshowIn] = useState(false);
    const [showOut, setshowOut] = useState(false);

    const image = { uri: "https://i.pinimg.com/originals/3c/24/46/3c24462450c2a902bf7e18f3d9aada81.jpg" };

    const navigation = useNavigation();

    function SaveReferral(text) {
        if (text == undefined || text == '') {
            // Alert.alert("Amount must be greater then or equal to zero");
            return false;
        }
        const NON_DIGIT = /^[0-9]+$/;

        NewRefferral = parseFloat(text.toString().replace(NON_DIGIT, ''));
        SetReferralId(NewRefferral)
    }

    ////////////////////////////////////DAte piker


    const onChangeDate = (event, selectedValue) => {
        const currentDate = selectedValue || new Date();
        setshowDate(Platform.OS === 'ios');

        setDate(currentDate);

        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const onChangeIn = (event, selectedValue) => {
        const selectedTime = selectedValue || new Date();
        setshowIn(Platform.OS === 'ios');
        setdateIn(selectedTime);
        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const onChangeOut = (event, selectedValue) => {
        const selectedTime = selectedValue || new Date();
        setshowOut(Platform.OS === 'ios');
        setDateOut(selectedTime)
        setshowOut(false)
        setshowIn(false)
        setshowDate(false)
    };
    const showDatepicker = () => {
        setshowDate(true)
        setshowOut(false)
        setshowIn(false)
    };
    const showTimepickerIn = () => {
        setshowIn(true)
        setshowDate(false)
        setshowOut(false)
    };
    const showTimepickerOut = () => {
        setshowOut(true)
        setshowDate(false)
        setshowIn(false)
    };


    function FormatTime(time) {
        // Alert.alert(time.getHours()+":"+time.getMinutes());
        return time.getHours() + ":" + time.getMinutes();
    }
    const formatDate = (date) => {
        return ` ${date.getDate()}/${date.getMonth() +
            1}/${date.getFullYear()} `;
    };
    const InTimeFormat = (time) => {
        return ` ${time.getHours()}:${time.getMinutes()}`;
    };
    const OutTimeFormat = (time) => {
        return ` ${time.getHours()}:${time.getMinutes()}`;
    };


    //////////////////

    function login() {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(email) === false) {
            Alert.alert("Invalid credentials", "Email is Not Valid");
            // Setemail( text )
            return false;
        }

        SetLoading(true);
        try {
            // console.log('res : ' + email + password);

            const response = axios.post(
                BASE_URL + "ApiAccount/UserLogin?Email=" + email + "&Password=" + password
            ).then((response) => {
                SetLoading(false);
                if (response.data.Data === undefined || response.data.Data == null) {
                    Alert.alert("Invalid credentials", "Your Email and Password Not Exist! ")
                }
                else {


                    global.LoginDetail = response.data.Data;
                    // console.log(response.data);
                    (async () => {

                        await AsyncStorage.setItem('Logged_UserId', JSON.stringify(response.data.Data.Users_ID));

                    }

                    )();
                    navigation.navigate('Home');
                }
            }).catch((error) => {
                Alert.alert("Internal Server Error", error.message)
            }).then(function () {

            });



        } catch (error) {
            // handle error

            Alert.alert("Internal Server Error", error.message)
            isLoading(false);

        }
    }
    function submit() {
        if (password != ConfirmPassword) {
            Alert.alert("", "Your Password does not match!")
            return false;
        } let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(email) === false) {
            Alert.alert("", "Please enter valid email");
            // Setemail( text )
            return false;
        }
        SetLoading(true);

        const model = {

            FirstName: FirstName,
            LastName: LastName,
            Email: email,
            Password: password,
            confirmPassword: ConfirmPassword,

            AboutMySelf: About,
            ReferralId: ReferralId,
        };
        //console.log('res : ' + JSON.stringify(model));
        try {
            axios.post(BASE_URL + 'ApiAccount/Register ', { model: model })

                .then(response => {
                    //console.log(response.data)
                    SetLoading(false);
                    if (response.data.IsSuccess == 'Yes') {
                        Alert.alert('Congratulations!', 'You have successfully registered');
                        (async () => {

                            await AsyncStorage.setItem('Email', email);
                            await AsyncStorage.setItem('Password', password);
                            // await AsyncStorage.setItem('UserId', response.data.Data.Users_ID);

                        }

                        )();
                        // navigation.navigate('ProfileStack', { screen: 'UpdateProfile' })

                        login();
                    }
                    else {
                        SetLoading(false);
                        Alert.alert("", 'This Email/Username is already Exist.')
                    }

                }, (error) => {
                    SetLoading(false);
                    // console.log(error);
                });
        } catch (error) {
            // handle error
            SetLoading(false);
            Alert.alert("Internal Server Error", error.message)

        }
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ScrollView style={{ padding: 15 }}>

                <View >
                    {/* <Image style={{ height: 25, width: 100, alignSelf: 'flex-start' }} source={require('../Icons/logo.png')}></Image> */}
                    <Text style={{ textAlign: 'center', paddingTop: 25, paddingBottom: 20, fontWeight: '100', color: 'grey', fontSize: 12 }}>We save your contact details for communication and logged in purpose ONLY, your contact details will remain confidential and will not share with any 3rd party.</Text>
                    <View>
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.HeadingsTitle}>Contact  Details</Text>

                            </View>
                        </ImageBackground>

                    </View>
                    <View style={{ flexDirection: 'row' }}>
                        <View style={{ flex: 1 }}>

                            <Text style={styles.labelStyle}>First Name </Text>
                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetFirstName(text)}
                                placeholder='First Name'

                            //value={value}
                            />
                        </View>
                        <View style={{ flex: 1, paddingLeft: 5 }}>
                            <Text style={styles.labelStyle}>Last Name </Text>

                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetLastName(text)}
                                placeholder='Last Name'

                            //value={value}
                            />

                        </View>
                    </View>
                    <Text style={styles.labelStyle}>Email </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text.trim())}
                        placeholder='Email'

                    //value={value}
                    />
                    <Text style={styles.labelStyle}>Phone </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setpassword(text.trim())}
                        placeholder='Phone'
                        secureTextEntry={true}
                    //value={value}
                    />
                    <Text style={styles.labelStyle}>Password </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => SetConfirmPassword(text.trim())}
                        placeholder='Password'
                        secureTextEntry={true}
                    //value={value}
                    />
                    <View style={styles.labelStyle}>
                        <ImageBackground source={image} style={styles.HeadingBackgroundImage}>
                            <View style={{ flexDirection: 'row' }}>
                                <Text style={styles.HeadingsTitle}>Address Details</Text>

                            </View>
                        </ImageBackground>

                    </View>
                    {/* <Text style={{ padding: 10 }}>Referral Id </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => SetReferralId(text.replace(/[^0-9]/g, ''))}
                        placeholder='Referral Id'
                        numeric
                        keyboardType='numeric'
                    //value={value}
                    /> */}
                     <View style={{ flexDirection: 'row' }}>
                        <View style={{ flex: 1 }}>

                            <Text style={styles.labelStyle}>Country </Text>
                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetFirstName(text)}
                                placeholder='Country'

                            //value={value}
                            >Pakistan</TextInput>
                        </View>
                        <View style={{ flex: 1, paddingLeft: 5 }}>
                            <Text style={styles.labelStyle}>Province </Text>

                            <TextInput
                                style={styles.TextInput}
                                onChangeText={(text) => SetLastName(text)}
                                placeholder='Province'

                            //value={value}
                            >Punjab</TextInput>

                        </View>
                    </View>
                    <Text style={styles.labelStyle}>City </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text.trim())}
                        placeholder='City'

                    //value={value}
                    />
                    <Text style={styles.labelStyle}>Address </Text>
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text.trim())}
                        placeholder='Address'

                    //value={value}
                    />
                    <View style={{ flexDirection: 'row' ,margin:10,borderColor:'grey',borderWidth:0.3,borderRadius:5 }}>
                        <CheckBox
                            //title='Display my Name as Donur'
                            //sty={{fontSize:20}}
                            checked={Checked}
                            onPress={() => { setChecked(!Checked) }}
                            style={{ padding: 0 }}
                            size={25}
                        />
                        <View style={{ flexDirection: 'column',marginVertical:10 }}>
                            <Text style={[styles.labelStyle,{margin:0,textAlign:'center'}]}>Display my Name as Donur</Text>
                            <Text style={[styles.labelStyle,{margin:0,fontSize:8}]}>Note: (if you will un check this, your name will be hidden)</Text>
                        </View>

                    </View>
                   
                    {/*                     
                    <Input placeholder="About me"
                        onChangeText={(text) => SetAbout(text)}
                    /> */}
                    <View style={{ flexDirection: 'row', marginVertical: 10, marginBottom: 20 }}>
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="Agree & Join"
                            titleStyle={{ fontSize: 12 }}
                            type="solid"
                            onPress={() => submit()}
                        />
                        <Button
                            containerStyle={{ flex: 1, margin: 5 }}
                            title="Cancel"
                            titleStyle={{ fontSize: 12, color: 'grey' }}
                            type="outline"
                            onPress={() => navigation.navigate("HomeStack", { screen: 'Home' })}
                        />

                    </View>
                    {/* <Button containerStyle={{ borderRadius: 20, height: 40, marginTop: 10 }} onPress={() => submit()}
                        title="Agree & Join"
                    // disabled={(FirstName == '' || LastName == '' || email == '' || password == '' || ConfirmPassword == '') ? true : false}

                    /> */}
                    <Text style={{ paddingTop: 10, textAlign: 'center',fontSize:12 }}>If you have already account on Help,</Text>
                    <Text style={{ marginBottom: 30, paddingTop: 10, textAlign: 'center',fontSize:12 }}>click here to   <Text onPress={() => navigation.navigate('Login')} style={{ color: '#2088dd', fontWeight: 'bold', fontSize: 14 }}>Sign in</Text></Text>

                    {/* <Button buttonStyle={{ marginTop: 20, backgroundColor: 'red' }}
                        title="Back" onPress={() => navigation.goBack()}
                    /> */}
                </View>
            </ScrollView>
        </SafeAreaView>
    );
}

export default Register;
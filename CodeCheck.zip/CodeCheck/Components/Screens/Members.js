// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, ActivityIndicator, Alert } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import { Card, Title, Paragraph } from 'react-native-paper';
import Icon from "react-native-vector-icons/AntDesign";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { ListItem, Avatar,Button } from 'react-native-elements';
import styles from '../Common/CommonStyles';
import { BASE_URL } from '../Common/Urls';
import { bannerAdUnitId,adUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize, InterstitialAd, AdEventType
} from '@react-native-firebase/admob';

const interstitial = InterstitialAd.createForAdRequest(
    adUnitId,
    {
        requestNonPersonalizedAdsOnly: true,
        keywords: ['fashion', 'clothing'],
    }
);

function Members() {
    const navigation = useNavigation();
    const [Data, setData] = useState([]);
    const [isLoading, SetLoading] = useState(false);

    useEffect(() => {

        SetLoading(true);
        const unsubscribe = navigation.addListener('focus', () => {
            SetLoading(true);
            DisplayAds();
            var url = BASE_URL + "ApiCommon/GetUsers";
            axios.get(
                url
            )
                .then(response => {
                    SetLoading(false);
                    if (response.data == null) {
                        Alert.alert("No Record Found ")
                    }
                    else {
                        SetLoading(false);
                        setData(response.data.Data)

                    }
                }).catch((error) => {
                    SetLoading(false);
                    Alert.alert("Internal Server Error", error.message)
                });
        });
        return unsubscribe;

    }, [navigation])

    const ItemView = ({ item, index }) => {
        return (
            // Flat List Item    
            <ListItem bottomDivider onPress={() => navigation.navigate("MembersProfile", { Id: item.Users_ID })} key={index}>
                <Avatar rounded size={50} source={{ uri: 'http://' + item.ProfilePhoto }} />
                <ListItem.Content>
                    <ListItem.Title>{item.FirstName} {item.LastName}</ListItem.Title>
                    <ListItem.Subtitle>Joining Date: {new Date(item.CreatedDate).getDate()}/{new Date(item.CreatedDate).getMonth() + 1}/{new Date(item.CreatedDate).getFullYear()}</ListItem.Subtitle>
                </ListItem.Content>
                <ListItem.Chevron color='black' />
            </ListItem>

        );
    };
    function DisplayAds() {
        const eventListener = interstitial.onAdEvent(type => {
            if (type === AdEventType.LOADED) {

                interstitial.show();
            }
        });

        // Start loading the interstitial straight away
        interstitial.load();

        // Unsubscribe from events on unmount
        return () => {
            eventListener();
        };
    }
    const Footer = () => {
        return (
            <Card>
                <Button buttonStyle={[styles.AddnewBtn, { alignSelf: 'center' }]}
                    titleStyle={{ fontSize: 12 }}
                    iconRight={true}
                    type='clear'
                    icon={
                        <Icon
                            name="sync"
                            size={14}
                            color="#2088dd"
                        />

                    } title="LOADING  " />
            </Card>
        )
    }
    return (
        <SafeAreaView style={{ flex: 1, padding: 4 }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <FlatList
                data={Data}
                keyExtractor={(item, index) => index.toString()}     //has to be unique   
                renderItem={ItemView} //method to render the data in the way you want using styling u need
                initialNumToRender={1}
                windowSize={1}
                ListFooterComponent={Footer}
            />
        </SafeAreaView>
    );
}

export default Members;
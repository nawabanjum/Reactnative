// In App.js in a new project

import * as React from 'react';
import { Component, useState, useEffect } from "react";
import { View, Text, FlatList, SafeAreaView, Image, Alert, Linking, TextInput, ActivityIndicator } from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import Icon from "react-native-vector-icons/FontAwesome5";
import { NavigationContainer, useNavigation } from '@react-navigation/native';
import axios from 'axios';
import { Input, Button, SocialIcon } from 'react-native-elements';
import AsyncStorage from '@react-native-community/async-storage';
import { BASE_URL } from '../Common/Urls';
//import { TextInput } from 'react-native-paper';
import styles from '../Common/CommonStyles';
import { bannerAdUnitId } from '../Common/IDs';

////Ads
import {
    TestIds,
    BannerAd,
    BannerAdSize,
} from '@react-native-firebase/admob';
/////////////////////////////////////////////////////////////
function SignIn() {
    const [email, Setemail] = useState('');
    const [password, Setpassword] = useState('');
    const [isLoading, SetLoading] = useState(false);
    const [hidePass, setHidePass] = useState(true);
    const [isLogin, SetLogin] = useState(false);
    const navigation = useNavigation();


    useEffect(() => {
        // send HTTP request

        (async () => {


            try {

                let vPincode = await AsyncStorage.getItem('Email')
                let vPassword = await AsyncStorage.getItem('Password')
                if (vPincode != null && vPassword != null) {
                    login(vPincode, vPassword)
                }
            } catch (error) {
                // Error retrieving data

            }

        })();

    }, [])
    //    const validate = (text) => {
    //         console.log(text);
    //         let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    //         if (reg.test(text) === false) {
    //           console.log("Email is Not Correct");
    //          // Setemail( text )
    //           return false;
    //         }
    //         else {
    //           Setemail( text)
    //           console.log("Email is Correct");
    //         }
    //       }

    function login(Email, Password) {
        let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        if (reg.test(Email) === false) {
            Alert.alert("Invalid credentials", "Email is Not Valid");
            // Setemail( text )
            return false;
        }
        //console.log(Email, Password);

        SetLoading(true);
        try {

            const response = axios.post(
                BASE_URL + "ApiAccount/UserLogin?Email=" + Email + "&Password=" + Password
            ).then((response) => {
                SetLoading(false);
                if (response.data.Data === undefined || response.data.Data == null) {
                    Alert.alert("Invalid credentials", "Your Email and Password Not Exist! ")
                }
                else {

                    (async () => {

                        await AsyncStorage.setItem('Email', Email);
                        await AsyncStorage.setItem('Password', Password);
                        await AsyncStorage.setItem('Logged_UserId', JSON.stringify(response.data.Data.Users_ID));

                    }

                    )();

                    global.LoginDetail = response.data.Data;
                    //console.log(response.data.Data.Users_ID);
                    SetLogin(false)
                    navigation.navigate('Home');
                }
            }).catch((error) => {
                Alert.alert("Internal Server Error", error.message)
            }).then(function () {

            });



        } catch (error) {
            // handle error

            Alert.alert("Internal Server Error", error.message)
            isLoading(false);

        }
    }
    return (
        <SafeAreaView style={{ flex: 1, backgroundColor: 'white' }}>
            <ActivityIndicator style={styles.LoaderStyle} size="large" color='orange' animating={isLoading} />
            <ScrollView style={{ padding: 25 }}>
                <View>
                    {/* <Image style={{ marginLeft: 10, height: 30, width: 130, alignSelf: 'flex-start', marginBottom: 30 }} source={require('../Icons/logo.png')}></Image> */}
                    {/* <Text style={{ fontSize: 30, fontWeight: '300', paddingLeft: 10 }}>Sign in</Text> */}
                    <Text style={{ paddingTop: 5, color: 'black', paddingBottom: 20, paddingLeft: 10,textAlign:'center' }}>Please login to access dasbhoard.</Text>
                    {/* <Input
                        placeholder='Email'
                        leftIcon={<Icon name='user' size={24} color='black' />
                        } onChangeText={(text) => Setemail(text)}
                    /> */}
                    {/* <Input placeholder="Password" secureTextEntry={true}
                        leftIcon={<Icon name='lock' size={24} color='black' />}
                        onChangeText={(text) => Setpassword(text)}
                    /> */}
                    <TextInput
                        style={styles.TextInput}
                        onChangeText={(text) => Setemail(text.trim())}
                        placeholder='Email'

                    //value={value}
                    />
                    <View style={{flexDirection: 'row', borderWidth: 0.5,borderColor: 'grey',borderRadius:20,marginTop:10,height:40}}>
                    <TextInput
                        style={[ { flex: 1,backgroundColor: '#fff',color: '#424242',marginLeft:10,height:35,marginTop:2 }]}
                        secureTextEntry={hidePass ? true : false}
                        onChangeText={(text) => Setpassword(text.trim())}
                        placeholder='Password'

                    //value={value}
                    />
                    <Icon
                    style={{padding:10}}
                        name={hidePass ? 'eye' : 'eye-slash'}
                        size={15}
                        color="grey"
                        onPress={() => setHidePass(!hidePass)}
                    />
                    </View>
                    <Text style={{ color: '#2088dd', fontWeight: 'bold', paddingLeft: 10, paddingBottom: 20, paddingTop: 15 }} onPress={() => navigation.navigate('ForgotPassword')}>Forget Password?</Text>

                    <Button containerStyle={{ borderRadius: 20, height: 40 }} onPress={() => login(email, password)}
                        title="Sign in"
                        disabled={(email.trim() == '' || email == '' || password == '') ? true : false}
                    />
                    <Text style={{ paddingTop: 30, textAlign: 'center' }}>New to Help?  <Text onPress={() => navigation.navigate('Register')} style={{ color: '#2088dd', fontWeight: 'bold' }}>Join now</Text></Text>

                </View>

            </ScrollView>
        </SafeAreaView>
    );
}

export default SignIn;